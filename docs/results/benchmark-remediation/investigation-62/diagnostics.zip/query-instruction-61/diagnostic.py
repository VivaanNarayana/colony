"""Single optional BGE query-prefix configuration, frozen score-only comparison."""

import ast
import hashlib
import json
import sys
import time
from pathlib import Path

BASE = Path.cwd()
DIRECTORY = Path(__file__).parent
PREFIX = "Represent this sentence for searching relevant passages: "
EXAMPLES = [
    ("What occurs after an aquarium feeder regains electrical power?",
     "After power returns, the aquarium feeder waits for the next scheduled feeding. It never dispenses extra food to make up for missed meals.",
     "Does an aquarium feeder dispense missed meals when electricity returns?",
     "Can an aquarium feeder identify fish diseases?"),
    ("Who may open the freight lift service panel?",
     "Only certified maintenance technicians may open the freight lift service panel. Possession of its physical key does not authorize any other worker to open it.",
     "May a janitor with a key open the freight lift service panel?",
     "Does the freight lift service panel insure damaged cargo?"),
    ("How quickly is weather balloon position reported?",
     "The weather balloon sends one position update every forty-five seconds. It keeps that rate throughout ascent and descent.",
     "How much time passes between weather balloon position updates?",
     "Which cipher encrypts weather balloon position updates?"),
    ("What happens when an invoice credit memo is approved?",
     "Approving an invoice credit memo reduces the customer's outstanding balance. It does not send money to a payment card; that requires a separate refund request.",
     "Does approval of an invoice credit memo automatically refund the card?",
     "Does approval of an invoice credit memo reveal a customer's password?"),
    ("How long does a garden irrigation override persist?",
     "A garden irrigation override lasts two hours. It then ends and the stored watering schedule resumes without an operator action.",
     "Will garden irrigation follow its programmed schedule three hours after an override begins?",
     "Will a garden irrigation override detect fertilizer contamination?"),
    ("When can the film camera back be opened?",
     "Keep the film camera back latched until the exposed roll has been completely rewound. Opening it before rewinding ruins the exposed frames.",
     "May the film camera be opened before its exposed roll is rewound?",
     "Does the film camera encode satellite coordinates in its photographs?"),
    ("Who may use a municipal bicycle subscription?",
     "The municipal bicycle subscription is personal to its registered rider. A companion must buy separate access and cannot ride using that subscription.",
     "Can a friend borrow a municipal bicycle subscription?",
     "Can a municipal bicycle subscription unlock a private garage?"),
    ("What happens when the same luggage tag is scanned again?",
     "Repeated scans of the luggage tag within one trip are ignored. They preserve the original tracking record rather than adding another record or deleting the existing one.",
     "A traveler has already checked a bag and its luggage tag was read successfully at the first conveyor. Later on the same trip, another operator reads that very same tag again without changing the bag or starting a new trip. The traveler wants to keep the first tracking entry available and is concerned about repeated reads. Will this second luggage tag scan erase the original tracking record?",
     "A traveler has already checked a bag and its luggage tag was read successfully at the first conveyor. Later on the same trip, another operator reads that very same tag again without changing the bag or starting a new trip. The traveler wants to contact a person whose telephone details were never entered into the tracking system. Will this second luggage tag scan discover the owner's private phone number?"),
]


def freeze(name, value):
    data = (json.dumps(value,indent=2)+"\n").encode()
    (DIRECTORY / f"{name}.json").write_bytes(data)
    digest = hashlib.sha256(data).hexdigest()
    (DIRECTORY / f"{name}.sha256").write_text(digest+"\n")
    return digest


def prepare():
    rows = []
    for index,(saved,answer,positive,negative) in enumerate(EXAMPLES,1):
        for supported,question in [(True,positive),(False,negative)]:
            rows.append(dict(id=f"I{index:02d}-{'positive' if supported else 'negative'}",origin="fresh-preregistered",
                             expected_supported=supported,saved_question=saved,content=answer,question=question))
    design = dict(prefix=PREFIX,incoming_query_only=True,stored_questions="Existing raw query_embed vectors; no prefix",
                  stored_passages="Existing raw passage(saved_question,answer) bytes; no prefix",CE="Same raw incoming query and original answer/saved-question controls",
                  thresholds="Existing .55 dense, .65/.70 saved-question cosine, .60 fused relevance and all existing semantic/bypass rules; no top12 changes",
                  rejection="Any newly accepted-positive loss/new unsupported eligible pass or exact red still eligible rejects; no variant tuning",
                  limits="Score-only candidate eligibility, not Store admission or candidate displacement; 512-token embedding limit remains unchanged; prefix consumes budget",
                  official_card="https://huggingface.co/BAAI/bge-small-en-v1.5")
    fresh = freeze("fresh-inputs",dict(design=design,rows=rows))
    cases = json.loads((BASE / "work/floor-calibration-56/calibration-cases.json").read_text())
    labels = {r["id"]:r for r in json.loads((BASE / "work/floor-calibration-56/calibration-labels.json").read_text())}
    for case in cases:
        if case["id"] in {"C03","C06","C16"}:
            record = case["records"][0]
            rows.append(dict(id=case["id"],origin="known-nonindependent",expected_supported=labels[case["id"]]["positive"],
                             saved_question=record["question"],content=record["answer"],question=case["question"]))
    node = next(node for node in ast.parse((BASE / "tests/test_saved_wording_regression.py").read_text()).body
                if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=="CASES" for t in node.targets))
    wording = ast.literal_eval(node.value)
    for index,(saved,positive,negative,concise,explanatory) in enumerate(wording,1):
        for name,answer in [("concise",concise),("explanatory",explanatory)]:
            rows.append(dict(id=f"known-wording-{index}-{name}",origin="known-wording-nonindependent",expected_supported=True,
                             saved_question=saved,content=answer,question=positive))
        if index==2:
            rows.append(dict(id="exact-red-lifetime",origin="known-nonindependent",expected_supported=False,
                             saved_question=saved,content=explanatory,question=negative))
    combined = freeze("inputs",dict(design=design,fresh_sha256=fresh,rows=rows))
    manifest = dict(fresh_sha256=fresh,inputs_sha256=combined,fresh=16,known=len(rows)-16,
                    script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                    retrieval_sha256=hashlib.sha256((BASE / "src/colony/retrieval.py").read_bytes()).hexdigest(),model_changes=False,
                    official_card="https://huggingface.co/BAAI/bge-small-en-v1.5",frozen_before_scores=True)
    freeze("manifest",manifest)
    print(json.dumps(manifest))


def measure():
    import numpy as np

    from colony.retrieval import (
        embed,
        fused_score,
        local_term_support,
        models,
        passage,
        procedural_text,
        rank,
        requires_procedure,
        terms,
    )

    data = (DIRECTORY / "inputs.json").read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    assert digest == (DIRECTORY / "inputs.sha256").read_text().strip()
    cost = dict(embedding_requests=0,embedding_calls=0,cache_hits=0,rank_calls=0,ce_pairs=0,ce_unique_pairs=0,provider_calls=0)
    cache,embedding_log = {},[]

    def vector(text,query=False):
        cost["embedding_requests"] += 1
        key = (text,query)
        if key not in cache:
            cache[key] = embed(text,query=query)
            cost["embedding_calls"] += 1
            embedding_log.append(dict(text=text,mode="query" if query else "passage",sha256=hashlib.sha256(cache[key]).hexdigest()))
        else:
            cost["cache_hits"] += 1
        return cache[key]

    def cosine(a,b):
        a,b = np.frombuffer(a,np.float32),np.frombuffer(b,np.float32)
        return float(a@b/(np.linalg.norm(a)*np.linalg.norm(b)))

    embedding,_ = models()
    engine = embedding.model

    def token_info(text):
        encoding = engine.tokenize([text])[0]
        end = max(end for start,end in encoding.offsets)
        return dict(tokens=len(encoding.ids),last_original_character=end,chars=len(text),fully_visible=end==len(text))

    rows = []
    started = time.perf_counter()
    for case in json.loads(data)["rows"]:
        query,saved,answer = case["question"],case["saved_question"],case["content"]
        raw = vector(query,True)
        instructed = vector(PREFIX+query,True)
        saved_vector = vector(saved,True)
        answer_vector = vector(passage(saved,answer))
        documents = [answer[:4000],saved]
        full,control = rank(query,documents)
        cost["rank_calls"] += 1
        cost["ce_pairs"] += 2
        cost["ce_unique_pairs"] += len(set(documents))
        literal = local_term_support(terms(query),answer[:4000])
        exact = query.strip().casefold()==saved.strip().casefold()
        procedure = requires_procedure(query)
        semantic = literal or exact or procedure or full>max(0,control)
        modes = {}
        for name,qvector in [("raw",raw),("instructed",instructed)]:
            qcos,acos = cosine(qvector,saved_vector),cosine(qvector,answer_vector)
            relevance = fused_score(max(qcos,acos),full)
            eligible = max(qcos,acos)>=.55 and (qcos >= (.70 if procedure else .65) or exact)
            eligible = eligible and (not procedure or procedural_text(answer) or exact) and (relevance>=.60 or exact)
            modes[name] = dict(question_cosine=qcos,answer_cosine=acos,relevance=relevance,
                               eligibility=eligible,eligible_guard=eligible and semantic)
        row = dict(**case,full_answer_logit=full,saved_question_logit=control,literal_support=literal,exact=exact,
                   procedure=procedure,unchanged_semantic_guard=semantic,raw=modes["raw"],instructed=modes["instructed"],
                   raw_query_tokens=token_info(query),instructed_query_tokens=token_info(PREFIX+query),
                   supported_loss=case["expected_supported"] and modes["raw"]["eligible_guard"] and not modes["instructed"]["eligible_guard"],
                   new_unsupported_eligible=not case["expected_supported"] and not modes["raw"]["eligible_guard"] and modes["instructed"]["eligible_guard"],
                   remaining_unsupported_eligible=not case["expected_supported"] and modes["instructed"]["eligible_guard"])
        rows.append(row)
        print(json.dumps({k:row[k] for k in ["id","expected_supported","raw","instructed","supported_loss","new_unsupported_eligible","remaining_unsupported_eligible"]}))
    cost["elapsed_seconds"] = time.perf_counter()-started
    summary = dict(cases=len(rows),supported_losses=sum(r["supported_loss"] for r in rows),
                   new_unsupported_eligible=sum(r["new_unsupported_eligible"] for r in rows),
                   remaining_unsupported_eligible=sum(r["remaining_unsupported_eligible"] for r in rows),
                   known_red_still_eligible=next(r["instructed"]["eligible_guard"] for r in rows if r["id"]=="exact-red-lifetime"))
    output = dict(inputs_sha256=digest,prefix=PREFIX,prefix_content_tokens=token_info(PREFIX.rstrip())["tokens"]-2,
                  actual_query_embed_implementation=engine.query_embed.__func__.__module__,
                  actual_passage_embed_implementation=engine.passage_embed.__func__.__module__,cost=cost,summary=summary,
                  rows=rows,embedding_log=embedding_log,truncation_risk="Prefix consumes input tokens under unchanged 512 limit; facts at a long query tail may be lost. No limit increase.")
    (DIRECTORY / "results.json").write_text(json.dumps(output,indent=2)+"\n")
    print(json.dumps(dict(summary=summary,cost=cost,prefix_content_tokens=output["prefix_content_tokens"])))


if __name__=="__main__":
    prepare() if sys.argv[1:]==["--prepare"] else measure()
