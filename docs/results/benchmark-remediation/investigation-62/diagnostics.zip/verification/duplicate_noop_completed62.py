"""One paired read-cost observation; no subjects, model calls or gate claim."""
import hashlib
import json
import subprocess
import time
import types
from pathlib import Path

import sqlite_vec

import colony.context as context
import colony.store as current
from colony.models import Grant, Scope, Trail
from colony.validation import snapshot

out = Path("work/duplicate-noop-completed-62")
out.mkdir(exist_ok=False)
old = types.ModuleType("before_duplicate_repair")
old_code = subprocess.check_output(["git", "show", "89809f6:src/colony/store.py"])
exec(compile(old_code, "89809f6:store.py", "exec"), old.__dict__)
vector = sqlite_vec.serialize_float32([1.0] + [0.0] * 383)
current.models = lambda: None
current.index_version = lambda: "read-cost-only-384-stub"
current.embed = lambda *args, **kwargs: vector
current.embed_passages = lambda texts: [vector for _ in texts]
repo = out / "private-runtime/repo"
repo.mkdir(parents=True)
sources = []
data = b"x" * 2_000_000
for index in range(8):
    ref = f"bounded-{index}.txt"
    (repo / ref).write_bytes(data)
    sources.append(snapshot(repo, ref))
store = current.Store(out / "private-runtime/data", repo)
trail = Trail(id="a" * 32, namespace="team", question="Source read cost fixture", content="Local fixture only", sources=sources)
grant = Grant(member_id="fixture", name="fixture", server="http://localhost", expires_at=4102444800, scopes=[Scope(namespace="team", push=True, pull=True)])
store.push(trail, grant)
reads = []
original = context.read_source
def counted(root, ref):
    reads.append(ref)
    return original(root, ref)
context.read_source = counted
def forbidden(texts):
    raise AssertionError("No inference is permitted during either measured duplicate")
current.embed_passages = forbidden
results = []
for label, method in [("before_repair", old.Store.push), ("repair_with_completion_state", current.Store.push)]:
    reads.clear()
    start = time.perf_counter()
    receipt = method(store, trail, grant)
    elapsed = time.perf_counter() - start
    assert receipt == {"id": trail.id, "stored": True, "duplicate": True}
    results.append({"label": label, "seconds": elapsed, "source_read_calls": len(reads), "bytes_in_source_files_read": len(reads) * len(data), "receipt": receipt})
report = {"kind": "Single paired descriptive mechanism observation; not native benchmark or statistical gate", "workers_idle": True,
          "input": {"files": 8, "each_bytes": len(data), "content_sha256": hashlib.sha256(data).hexdigest()},
          "before_commit": "89809f6e1fd09cb79b2c7e59baeda049bcddb4e0", "before_store_sha256": hashlib.sha256(old_code).hexdigest(),
          "candidate_store_sha256": hashlib.sha256(Path(current.__file__).read_bytes()).hexdigest(), "results": results,
          "model_calls": 0, "provider_calls": 0, "stub_disclosure": "Deterministic vectors seed SQL only. Actual bounded source reads/hash/decode/redaction run unchanged; both timed duplicate paths make0model calls.",
          "limits": "One warm-file-cache observation in fixed order, no CI/general latency claim. Private runtime/keys excluded from publication."}
(out / "report.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
print(json.dumps(report))
