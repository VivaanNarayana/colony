import hashlib
import json
import shutil
import subprocess
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path

root = Path.cwd()
work = root / 'work'
parent = root.parent
out = root / 'docs/results/benchmark-remediation/attempt-56'
assert not out.exists()
out.mkdir()
source = 'fec2c119d2964e99e01cf00239caab02625b34bb'
baseline = '6fa6826aa4c835001c0d2bc8f3bec838499e5b5d'
assert subprocess.check_output(['git','rev-parse','HEAD'], text=True).strip() == source
live = parent / 'benchmark-remediation-live-56-results'
runtime = parent / 'benchmark-remediation-live-56-runtime'
local = parent / 'benchmark-remediation-local-56-results'
report = json.loads((live / 'comparison.json').read_text(encoding='utf-8'))
assert sum(report['gate'].values()) == 3 and report['data_budget_verified']
assert int((work / 'analyzer-56.exit.txt').read_text(encoding='utf-8-sig')) == 1
assert not subprocess.check_output(['git','diff','3917fa1be692165976dbf67f3bd4dfbe34206497','--','scripts',*[f'docs/results/benchmark-remediation/attempt-{n}' for n in range(1,56)]])

def put(name, data):
    (out / name).write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8', newline='\n')

def cp(path, name):
    destination = out / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(path, destination)

sys.path.insert(0, str(root / 'scripts'))
from audit_lookup_local import audit_local
local_summary = json.loads((local / 'lookup-summary.json').read_text(encoding='utf-8'))
put('local-raw-audit.json', audit_local(local_summary, local))
for arm in ['main', 'feature']:
    for name in ['raw-measurements.jsonl','loaded-implementations.json','metadata.json','corpus-sha256.json','reviews.json']:
        cp(live / arm / name, arm + '/' + name)
for name in ['comparison.json','completed.json','protocol.json','model-policy-failures.jsonl']:
    cp(live / name, name)
cp(live / 'review-mapping.json', 'review-records.json')
for name in ['manual-review','frozen-labels','verification','preflight','required-gates']:
    cp(work / f'{name}-56.json', name + '.json')
cp(parent / 'benchmark-remediation-tool-audit-56.json','tool-audit.json')
cp(parent / 'benchmark-remediation-research-review-56.json','research-review.json')
cp(root / 'docs/results/benchmark-remediation/budget-allowance-3.json','usage-budget.json')
for path in local.iterdir():
    if path.is_file():
        cp(path, path.name)
for name in ['local-56.stdout.txt','local-56.exit.txt','live-56.stdout.txt','live-56.exit.txt','analyzer-56.stdout.txt','analyzer-56.stderr.txt','analyzer-56.exit.txt','wake-local-56.json','wake-live-56.json','full-retry-receipt-65.txt','full-retry-receipt-65.xml']:
    cp(work / name, name)
assert all(json.loads((work / f'wake-{kind}-56.json').read_text(encoding='utf-8'))['request_released'] for kind in ['local','live'])
put('raw-totals.json', {'all48_sessions_included': True, 'totals': report['arms']})
put('outcome.json', {
    'trial': 56, 'source': source, 'identical_runtime_source_commit': '75b4af31ee7556b931a387de6762014ac6f4b44a', 'baseline': baseline,
    'all_gates_passed': False, 'current_complete_eight_gate_verdict_available': True, 'gates_passed': 3, 'gates_total': 8,
    'gate_statuses': {'benchmarks/' + k: 'success' if v else 'failure' for k,v in report['gate'].items()},
    'blocking_gates': report['blocking_gates'], 'official_analyzer_invocations': 1, 'local_invocations': 1, 'native_invocations': 1,
    'native_sessions_completed': 48, 'native_gross_tokens': 2420629, 'cumulative_native50_through56_gross': 15497907,
    'all_outcomes_costs_retained': True, 'benchmark_or_session_restarts': 0, 'proof_repair': False,
    'tests_passed': 421, 'tests_failed': 1, 'tests_skipped': 1, 'ruff_passed': True,
    'usage': {'allowance': 3, 'baseline': 16, 'last_observed': 19, 'stop': 21, 'reset': 1793382050, 'shared': True, 'reporting_may_lag': True},
    'all_models_harness_and_gates_unchanged': True,
    'causal_limit': 'Combined runtime changes do not isolate causes; frozen corpus unchanged; wording/cache/sampling variability retained. No identical-runtime retry permitted.',
    'published_utc': datetime.now(timezone.utc).isoformat(),
})
put('code-hashes.json', {'source': source, 'sha256': {name: hashlib.sha256(subprocess.check_output(['git','show',f'{source}:{name}'])).hexdigest() for name in subprocess.check_output(['git','ls-tree','-r','--name-only',source,'--','src','scripts','tests'],text=True).splitlines()}})
rows = '\n'.join(f"|{key}|{report['arms']['main'][key]:,.3f}|{report['arms']['feature'][key]:,.3f}|" for key in ['tokens','uncached_input_plus_output','seconds','research_calls','tool_calls'])
(out / 'README.md').write_text(f'''# Trial 56: 3/8 strict gates pass; remediation unfinished

Measured **{source}**, identical runtime source to75b4af3, against freshly fetched main **{baseline}**. One fresh local comparison, one complete48-session native comparison and one unchanged official analyzer invocation after frozen quality labels. Human explicitly requested measurement of actual impact. All sessions, failures, attempted saves and costs remain; no identical-code retry, selective resampling, proof repair or main exemption.

The runtime now includes the actual-source-byte cap, matched Markdown fences/indexv10, targeted source-index recovery with a zero-read completion marker, and durable acknowledgment checks before deleting encrypted retry items. These are reviewed general fixes, documented in checkpoints57/59/62/66. They are not isolated in this comparison, and several paths are not exercised by this native workload. The source corpus remains frozen at6fa6826 in both arms. Saved-answer wording, model sampling and cache variation remain alternative explanations. **This run does not establish that the recent fixes caused the observed differences.**

## Strict results

Pass: loaded implementations, local lookup, live time. Fail: tests/lint, correctness, tool protocol, gross tokens and uncached tokens. The prior complete55 also passed3/8, but correctness passed then and live time failed; the passing set changed.

Feature live time is **8.50% lower**,95%reductionCI **+3.15% to+14.63%**. Gross tokens are **12.08% higher**,95%reductionCI **-25.03% to-0.87%**. Uncached tokens are **2.08% lower**, but95%reductionCI **-21.07% to+17.64%** crosses zero, so that gate fails. No confidence threshold changed.

|Metric|Main|Feature|
|---|---:|---:|
{rows}

Local117/117each; all234observations reconstructed by the unchanged raw audit. Warm lookup time is27.0754%lower,95%reductionCI+18.3674%to+37.5730%. This excludes setup/push/coldstart/concurrency. Repeated public-development comparisons are not independent production confirmation.

Premeasurement full suite: **421passed/1knownwrong-attribute false-hit failure/1existingWindows skip**; Ruff/whitespace pass. That failure is retained with no waiver. All models/weights remain unchanged; subjectgpt-6-luna/low and frozen harness/workload/order/prompts/rubric/oracles/relevance/confidence/context/research/token/time budgets are unchanged. Eight original strict checks under ruleset25440133 remain active, without bypass; PR3 remains draft/unmerged/noauto.

## Quality and protocol review

Coordinator reviewed all48 shuffled answers/packets and15research/save traces;41current excerpts were checked against exact frozen bytes, SHA256, source line and scrubbed prefix. Three newly displayed contexts are retained. Selected nonblind Astra review covered R03/R14/R21/R25/R29/R31/R33/R48; it was not independent blind grading of all48.

Core facts24/24both. Citations **19/24main,23/24feature**. FeatureR29 uses a named README heading anchor, which the unchanged citation oracle rejects. All five invalid main citations remain false. Do not repair links or exempt a plausible named anchor. Bare README references retain the same existing acceptance rule.

R21's initial README96 metadata remains irrelevant to the actual tool-name question; its final answer after research is sufficient. Feature useful hits16versus main19; research-free correct15versus18. Feature research calls fell30→22versus55, and stale2 now reuses a sufficient answer in one ask. These observations are not causal proof: generated saved wording differs. Metadata selection and wording sensitivity remain unresolved.

Protocol violations: mainR31/capture1 asks twice despite sufficient reads, retaining both calls/costs. FeatureR25/outage2 receives a relevant saved answer explicitly describing queued pushes, then reads client.py and saves. Its displayed source covers ask rather than push queuing, so do not claim current displayed text already proved the saved fact. Apply the original relevant-packet protocol calculation unchanged; do not relabel the packet to avoid failure. Actual new reads correctly precede the save. Neither currentR33norR48 researches/pushes; the initial review brief accidentally carried prior55 claims and was corrected before labels/analyzer. Motivation for extra reads is unobserved.

All15push attempts/16fingerprints match actual preceding new reads and frozen corpus bytes; all receipts report stored/queued. Main receipts3stored/3queued, finalDB6rows/3queue entries; queued receipts can overlap durableDBrows after lost responses. Feature9stored receipts/9rows/noqueue. **MainR03 explicitly sets tainted:false and stores false**; preserve this baseline finding separately from proof validity. All actual feature taints are true. Feature explicitfalse/offline enforcement remains test coverage, not exercised by this run. No taint safeguard was weakened.

Native gross2,420,629; cumulative50/51/53/54/55/56gross15,497,907;52native0. Every prior outcome/cost/label/manifest1–55 and checkpoints56–66 remains unchanged. Shared allowance3 baseline16%used, latest19%, stop21%; reset2026-10-30 17:40:50UTC. All coordinator/workers/reviews/subjects share it. Prior costs retained; reporting may lag. No reset/credit purchase/account switch/API-billing bypass.

Exact native events/prompts/answers/labels, pinned implementations and frozen corpus are archived in live-native.zip, excluding private databases/identity/storage/queue keys. Development.zip preserves preflight, review, audit scripts/logs and corrections. Public text normalizesLF; ZIP entries retain original bytes. All archives/manifests verified; no offline analyzer replay claimed. Wake requests were released. See [RESUME](../RESUME.txt). No further identical-runtime comparison is authorized.
''', encoding='utf-8', newline='\n')
with zipfile.ZipFile(out / 'live-native.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for path in sorted(live.rglob('*')):
        if path.is_file():
            archive.write(path, 'results/' + path.relative_to(live).as_posix())
    for arm, folder in [('main','main'),('feature','feat')]:
        for path in sorted((runtime / 'implementation' / arm).rglob('*.py')):
            archive.write(path,'implementation/' + arm + '/' + path.relative_to(runtime / 'implementation' / arm).as_posix())
        for path in sorted((runtime / folder / 'repo').rglob('*')):
            if path.is_file():
                archive.write(path,'corpus/' + arm + '/' + path.relative_to(runtime / folder / 'repo').as_posix())
with zipfile.ZipFile(out / 'development.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name in ['prepare_56.py','prepare_review56.py','inspect_56.py','freeze_labels_56.py','preflight-56.stdout.txt','review-prep-56.stdout.txt','tool-audit-56.stdout.txt','manual-review-56.json','checkpoint66-integrity.json','checkpoint66-verify.stdout.txt']:
        archive.write(work / name, name)
    archive.write(parent / 'benchmark-remediation-review-56-compact.txt','review-compact.txt')
for name in ['live-native.zip','development.zip']:
    with zipfile.ZipFile(out / name) as archive:
        assert archive.testzip() is None
        assert not any(n.endswith(('.db','.key','.pem','.enc')) or 'private-runtime' in n or 'identity.json' in n for n in archive.namelist())
for path in out.rglob('*'):
    if path.is_file() and path.suffix in {'.json','.jsonl','.txt','.md','.xml'}:
        path.write_text(path.read_text(encoding='utf-8-sig'), encoding='utf-8', newline='\n')
put('sha256.json',{path.relative_to(out).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(out.rglob('*')) if path.is_file() and path.name != 'sha256.json'})
resume = root / 'docs/results/benchmark-remediation/RESUME.txt'
resume.write_text(f'''ACTIVE ALLOWANCE3 — TRIAL56 COMPLETE, 3/8; TASK UNFINISHED.
Baseline16%used, latest19%, STOP21%; reset1793382050=2026-10-30 17:40:50UTC.
One shared5points; observed+3,2remain; priorcostsretained/reportingmaylag.
Measured {source}, runtimeequivalent75b4af3, freshmain{baseline}.
Read attempt56 README/comparison/manual-review/research-review/tool-audit/outcome.
One local+native48+officialanalysis, no retries/resampling/discards; allcostsretained.
PASS loaded/local/liveTIME; FAIL tests/correctness/protocol/gross/uncached.
Time8.50%lowerCI+3.15to+14.63; gross12.08%higher; uncached2.08%lowerCIcross0.
Core24/24both; citations19main/23feature, R29namedanchorinvalid underunchangedoracle.
MainR31twoasks;featureR25relevantcachedanswerthenread/push; sourceexcerptnotqueueproof.
All15pushes/16hashesactualprecedingnewreads. MainR03explicitfalsetaintretained.
Feature9stored/alltaintedtrue/0queue; main3storedreceipts3queued,DB6rows3queue.
Nativegross2420629; cumulative50through56gross15497907. Exact pinnedproofs retained.
Tests421pass1knownwrongattributefailure1skip;Ruffpass. Models/harness/gates unchanged.
No isolated causalclaim: corpusfrozen6fa, generatedwording/sampling/cachevary.
All1–55/checkpoints56–66immutable; PRdraft/unmerged/noauto. Workersidle/nobenchmarkactive.
Next needs meaningfulnew runtimefix before anycomparison; no identicalcoderetry.
Citationformat failure new; semanticfalsehit/metadata/wording/protocol/tokens unresolved.
Continue onlywhile sharedbudgetpermits; stopworkers/benchmark at21, retainpartialcosts,
updateexactcheckpoint andpause. No reset/credits/APIbilling/accountswitch bypass.

''' + resume.read_text(encoding='utf-8'), encoding='utf-8', newline='\n')
budget = root / 'docs/results/benchmark-remediation/budget-allowance-3.json'
record = json.loads(budget.read_text(encoding='utf-8'))
record.update(last_observed_weekly_used_percent=19, observed_increase_percentage_points=3, last_phase='Trial56 completed48, labels reviewed/frozen, officialanalyzer once:3/8; publication', last_observed_utc=datetime.now(timezone.utc).isoformat())
budget.write_text(json.dumps(record,indent=2) + '\n',encoding='utf-8',newline='\n')
print(json.dumps({'trial':56,'gates':report['gate'],'files':len(list(out.rglob('*'))),'native_gross':2420629}))
