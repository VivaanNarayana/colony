import hashlib
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path

from colony.security import scrub

results = Path('../benchmark-remediation-live-56-results')
runtime = Path('../benchmark-remediation-live-56-runtime')
work = Path('work')
records = json.loads((results / 'review-mapping.json').read_text(encoding='utf-8'))
assert len(records) == 48 and not (results / 'comparison.json').exists()
audit = json.loads(Path('../benchmark-remediation-tool-audit-56.json').read_text(encoding='utf-8'))
assert not audit['raw_trace_errors'] and audit['taint']['feature']['all_tainted']
labels = {arm: {} for arm in ['main', 'feature']}
checked = 0
for record in records:
    corpus = runtime / ('main' if record['arm'] == 'main' else 'feat') / 'repo'
    manifest = json.loads((results / record['arm'] / 'corpus-sha256.json').read_text(encoding='utf-8'))
    for packet in record['packets']:
        for read in packet.get('current_repository_reads', []):
            data = (corpus / read['path']).read_bytes()
            current = '\n'.join(scrub(data.decode('utf-8')).splitlines()[read['start_line'] - 1:])
            assert hashlib.sha256(data).hexdigest() == read['sha256'] == manifest[read['path']]
            assert current.startswith(read['content'])
            checked += 1
    labels[record['arm']][record['task_id'] + '.colony'] = {
        'correct': True,
        'citation_valid': record['citation_valid'],
        'relevant_asks': [False if record['review_id'] == 'R21' else bool(p.get('hit')) for p in record['packets']],
    }
invalid = [r['review_id'] for r in records if not r['citation_valid']]
assert invalid == ['R04', 'R07', 'R27', 'R29', 'R43', 'R47']
frozen = {}
for arm, items in labels.items():
    assert len(items) == 24
    path = results / arm / 'reviews.json'
    assert not path.exists()
    path.write_text(json.dumps(items, indent=2) + '\n', encoding='utf-8')
    frozen[arm + '/reviews.json'] = hashlib.sha256(path.read_bytes()).hexdigest()
(work / 'frozen-labels-56.json').write_text(json.dumps(frozen, indent=2) + '\n', encoding='utf-8')
shutil.copyfile(work / 'verification-56.json', results / 'verification.json')
traces = json.loads(Path('../benchmark-remediation-research-review-56.json').read_text(encoding='utf-8'))
pushes = [op for trace in traces for op in trace['ops'] if op['tool'] == 'push']
fingerprints = sum(len(op['arguments'].get('sources', [])) for op in pushes)
review = {
    'role': 'Coordinator reviewed all48 shuffled answers/packets and15 research/save traces. Selected nonblind Astra review is separate; not all48 independently blind graded.',
    'answers_reviewed': 48,
    'novel_current_contexts': 3,
    'source_contexts_byte_hash_line_scrub_checked': checked,
    'core_facts_correct': {arm: sum(x['correct'] for x in items.values()) for arm, items in labels.items()},
    'valid_citations': {arm: sum(x['citation_valid'] for x in items.values()) for arm, items in labels.items()},
    'incorrect_core_fact_review_ids': [],
    'invalid_citation_review_ids': invalid,
    'relevant_packet_exceptions': [{'id': 'R21', 'arm': 'feature', 'task': 'mcp-2', 'relevant': False, 'reason': 'Initial README96 metadata lacks requested tool names; final answer after research is sufficient.'}],
    'push_attempts': len(pushes),
    'file_fingerprints': fingerprints,
    'all_attempted_proofs_match_actual_preceding_new_reads': True,
    'schema_rejections': 0,
    'taint': audit['taint'],
    'selected_independent_review': {'model': 'GPT-6 Astra High', 'ids': ['R03','R14','R21','R25','R29','R31','R33','R48'], 'summary': 'Core facts and R21 irrelevance confirmed; retain R29 citation failure, R31 two asks, main R03 false taint. R25 saved answer relevant although displayed source covers ask rather than queue. No causal/runtime benefit claim.'},
    'qualifications': [
        'R29 named anchor is rejected by unchanged citation oracle; no correction or exemption. R37 bare README reference remains accepted under that same oracle.',
        'R25 saved answer is relevant to offline push queuing; do not relabel it irrelevant to avoid protocol failure. Current displayed source does not itself prove push queuing. Subsequent actual read and push retained; motivation unobserved.',
        'R31 has two sufficient ask packets and no research/push. Retain both calls and costs, with no all-family taint/scrub requirement invented for the capture-content question.',
        'Initial review brief accidentally carried prior55 R33/R48 research claims; current56 traces show neither researched/pushed. Corrected before labels/analyzer. Derived fingerprint count below supersedes preliminary estimated17 in review brief.',
        'Main R03 explicitly requests tainted:false and stores false; feature all actual taints true. Do not exempt main or confuse proof validity with taint.',
        'Changed-file questions require fingerprint mechanism, not every optional assertion edge case. Non-Python symbol checks remain unverified, not universally stale.',
        'Source corpus stays frozen at6fa6826 for both arms. Runtime repairs do not change that corpus; subject-generated saved wording and sampling/cache variation may explain outcome differences. No isolated causal improvement established.',
    ],
    'rubric_unchanged': True,
    'labels_frozen_before_analyzer': True,
    'frozen_utc': datetime.now(timezone.utc).isoformat(),
}
(work / 'manual-review-56.json').write_text(json.dumps(review, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: review[k] for k in ['source_contexts_byte_hash_line_scrub_checked','core_facts_correct','valid_citations','push_attempts','file_fingerprints']}))
