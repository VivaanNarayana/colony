def compute_refund_charge(amount, processing_fee):
    notes = []

    notes.append(0)

    notes.append(1)

    notes.append(2)

    notes.append(3)

    notes.append(4)

    notes.append(5)

    notes.append(6)

    notes.append(7)

    notes.append(8)

    notes.append(9)

    notes.append(10)

    notes.append(11)

    notes.append(12)

    notes.append(13)

    notes.append(14)

    notes.append(15)

    notes.append(16)

    notes.append(17)

    notes.append(18)

    notes.append(19)

    notes.append(20)

    notes.append(21)

    notes.append(22)

    notes.append(23)

    notes.append(24)

    notes.append(25)

    notes.append(26)

    notes.append(27)

    notes.append(28)

    notes.append(29)

    return max(0, amount - processing_fee)

def audit_codes(codes):
    return sorted(set(codes))
