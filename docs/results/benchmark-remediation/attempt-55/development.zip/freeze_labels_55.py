import hashlib,json,shutil
from pathlib import Path
from datetime import datetime,timezone
from colony.security import scrub
p=Path('../benchmark-remediation-live-55-results');runtime=Path('../benchmark-remediation-live-55-runtime');w=Path('work')
records=json.loads((p/'review-mapping.json').read_text());assert len(records)==48 and not(p/'comparison.json').exists()
audit=json.loads(Path('../benchmark-remediation-tool-audit-55.json').read_text());assert not audit['raw_trace_errors']
labels={a:{} for a in ['main','feature']};checks=0
for r in records:
 corpus=runtime/('main' if r['arm']=='main' else 'feat')/'repo';manifest=json.loads((p/r['arm']/'corpus-sha256.json').read_text())
 for packet in r['packets']:
  for e in packet.get('current_repository_reads',[]):
   data=(corpus/e['path']).read_bytes();current='\n'.join(scrub(data.decode()).splitlines()[e['start_line']-1:])
   assert hashlib.sha256(data).hexdigest()==e['sha256']==manifest[e['path']]
   assert current.startswith(e['content']);checks+=1
 labels[r['arm']][r['task_id']+'.colony']=dict(correct=True,citation_valid=r['citation_valid'],relevant_asks=[False if r['review_id']=='R21' else bool(packet.get('hit')) for packet in r['packets']])
assert [r['review_id'] for r in records if not r['citation_valid']]==['R01','R10','R11','R27','R31','R35','R37','R43','R47']
frozen={}
for arm,items in labels.items():
 assert len(items)==24
 f=p/arm/'reviews.json';f.write_text(json.dumps(items,indent=2)+'\n',encoding='utf-8');frozen[arm+'/reviews.json']=hashlib.sha256(f.read_bytes()).hexdigest()
(w/'frozen-labels-55.json').write_text(json.dumps(frozen,indent=2)+'\n',encoding='utf-8');shutil.copyfile(w/'verification-55.json',p/'verification.json')
rs=json.loads(Path('../benchmark-remediation-research-review-55.json').read_text());pushes=[o for r in rs for o in r['ops'] if o['tool']=='push']
proofs=sum(len(o['arguments'].get('sources',[])) for o in pushes)
manual=dict(role='Coordinator reviewed all48 shuffled answers/current packets and17 research/save traces. Bounded selected nonblind Astra review separate; not all48 independently blind graded.',answers_reviewed=48,novel_current_contexts=0,source_contexts_byte_hash_line_scrub_checked=checks,core_facts_correct={a:sum(r['correct'] for r in items.values()) for a,items in labels.items()},valid_citations={a:sum(r['citation_valid'] for r in items.values()) for a,items in labels.items()},incorrect_core_fact_review_ids=[],invalid_citation_review_ids=[r['review_id'] for r in records if not r['citation_valid']],relevant_packet_exceptions=[dict(id='R21',arm='feature',task='mcp-2',relevant=False,reason='README96 receipt metadata does not name the requested tools.')],push_attempts=len(pushes),file_fingerprints=proofs,all_attempted_proofs_match_actual_preceding_new_reads=True,schema_rejections=0,taint=dict(main_stored=7,main_queued=2,feature_stored=10,feature_queued=0,all_actual_true=True,feature_explicit_false_native_cases=0,feature_offline_native_cases=0,limit='Explicitfalse/offline feature enforcement remains unchanged test coverage, not native exercise.'),qualifications=['R21 final ask/push names sufficient for actual question; do not invent full-signature requirement. Initial metadata remains irrelevant.','R27 and R37 absolute targets remain invalid despite correct commands. All nine invalid main citations retained.','R28 states question-specific outage behavior correctly; do not require every family clause in each answer.','R26 matching hash description omits optional assertions; requested fingerprint mechanism correct, not exhaustive validation specification.','R48 performed new server.py research before push; no claim packet alone supported every final fact.','Source freshness patch catches observed contradictions during existing reads, not atomic filesystem snapshots; benchmark has no injected race.'],rubric_unchanged=True,labels_frozen_before_analyzer=True,frozen_utc=datetime.now(timezone.utc).isoformat())
(w/'manual-review-55.json').write_text(json.dumps(manual,indent=2)+'\n',encoding='utf-8');print(json.dumps(manual,indent=2))
