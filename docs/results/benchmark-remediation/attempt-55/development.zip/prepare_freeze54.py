from pathlib import Path

p=Path('work/freeze_labels_53.py').read_text(encoding='utf-8').replace('-53','-54')
p=p.replace("assert audit['raw_trace_errors']==[] and all(v['all_tainted'] for v in audit['taint'].values())", "assert audit['raw_trace_errors']==[['main','install-1','attempted push fingerprint does not match preceding read'],['main','install-1','push fingerprint does not match preceding read']]\nassert all(v['all_tainted'] for v in audit['taint'].values())")
p=p.replace("==['R06']","==[]").replace("==['R07','R10','R15','R27','R31','R35']","==['R01','R04','R09','R11','R28','R31','R32','R35','R43']")
p=p.replace('one novel source excerpt and15research/save traces','zero novel source excerpts and17research/save traces').replace('novel_current_contexts=1','novel_current_contexts=0').replace('push_attempts=15','push_attempts=17').replace('all_attempted_proofs_match_actual_preceding_new_reads=True','all_attempted_proofs_match_actual_preceding_new_reads=False').replace('main_stored=6,main_queued=3','main_stored=8,main_queued=5')
needle="(work/'manual-review-54.json').write_text"
update="""manual.update(
 integrity_violation=dict(id='R42',arm='main',task='install-1',actual_push_attempts=1,reported_audit_messages=2,ref='README.md',format_and_frozen_hash_match=True,preceding_new_research_reads=0,ask_hash_only=True,result='queued=true',status='Inadmissible temporal proof; do not exempt main, repair, inject research or retry.'),
 valid_fingerprint_provenance_count=18,invalid_fingerprint_provenance_count=1,
 rejected_proofs=0,rejected_proofs_definition='No schema rejection; independent provenance audit rejects one actual attempt.',
 review_qualifications=['R21 names ask/push with roles, sufficient for actual question/frozen expected; do not invent full signature requirement. Initial metadata still irrelevant.', 'R26 supplies requested SHA256 mismatch mechanism; statement about matching hashes is simplified and omits optional assertions, so no exhaustive-validation claim.', 'R37 matches server command rubric; do not newly require full init/setup recipe.', 'Capture/outage use historical question-specific facts, not every family-level clause in every answer.', 'MainR42 invalid provenance retained even though valid64hash matches actual frozen file and queued receipt. Quality labels do not establish a passing integrity gate.'],
 mcp2='Four research calls:two reads/two searches(oneempty),then valid storedpush; metadata initially irrelevant.',
 stale2='Miss;three research calls(two searches/oneempty,one read),then valid storedpush;91145gross,five totaltools includingask/push.',
 scope3='Miss;two research calls(one search/one read),then valid storedpush.',
 role='Primarycoordinator reviewed all48shuffled answers/currentpackets,zero newexcerptbytes and17research/save traces including invalid mainreusepush. Selected bounded nonblind Astra review; not all48 independently blind graded.',
 expected_integrity_outcome='Unchanged officialanalyzer expected to reject maininstall1 proof before complete eight-gate verdict; preserve error, no mainexemption.'
)
"""
assert needle in p
p=p.replace(needle,update+needle)
p=p.replace('usedPercent=10','usedPercent=11')
Path('work/freeze_labels_54.py').write_text(p,encoding='utf-8')
print('Prepared quality labels with explicit main proof failure; no analyzer change.')
