import asyncio,copy,importlib.util,json,subprocess,sys
from pathlib import Path
from types import SimpleNamespace
import colony.mcp

saved=json.loads(Path('work/mcp-policy-54-before.json').read_text(encoding='utf-8'))
oldpath=Path('work/mcp_policy_before54.py')
oldpath.write_bytes(subprocess.check_output(['git','show','68fb205551c8f38148304adb5fa1bfd7fb22907c:src/colony/mcp.py']))
spec=importlib.util.spec_from_file_location('colony_mcp_before54',oldpath)
old=importlib.util.module_from_spec(spec);sys.modules[spec.name]=old;spec.loader.exec_module(old)
colony.mcp.Client=lambda home:SimpleNamespace()
server=colony.mcp.create_mcp(Path('.'))
tools=[tool.model_dump() for tool in asyncio.run(server.list_tools())]
assert tools==saved['tools']
assert server.instructions[:512]==saved['instructions'][:512]
assert len(server.instructions.encode('utf-8'))==1705
packet=dict(hit=True,match_kind='answer',status='validated',namespace='ops',content='Archive retention is17days.',sources=[dict(ref='handbook.md',content_hash='a'*64)],evidence=[dict(ref='handbook.md',line=4,text='Archive retention is17days.')],tainted=True,age_flag=False,id='audit',producer_id='producer')
ask_cases=[dict(hit=False,reason='no_relevant_trail'),{**packet,'status':'stale','evidence':[]},packet,{**packet,'match_kind':'evidence'}]
push_cases=[dict(id='audit',stored=True,duplicate=False),dict(id='audit',stored=False,queued=True),dict(id='audit',stored=True,queued=True),dict(id='audit',stored=False,queued=False,error='denied')]
receipts=[]
for case in ask_cases:
 values=[]
 for module in [old,colony.mcp]:
  module.Client=lambda home:SimpleNamespace(ask=lambda *a,**kw:copy.deepcopy(case))
  values.append(asyncio.run(module.create_mcp(Path('.')).call_tool('ask',dict(question='Archive retention?',namespace='ops')))[0].text)
 assert values[0]==values[1]
 receipts.append(dict(operation='ask',before=json.loads(values[0]),after=json.loads(values[1]),equal=True))
for case in push_cases:
 values=[]
 for module in [old,colony.mcp]:
  module.Client=lambda home:SimpleNamespace(push=lambda trail:copy.deepcopy(case))
  values.append(asyncio.run(module.create_mcp(Path('.')).call_tool('push',dict(namespace='ops',question='Archive retention?',content='17days.',sources=[dict(ref='handbook.md',content_hash='a'*64)],tainted=False)))[0].text)
 assert values[0]==values[1]
 receipts.append(dict(operation='push',before=json.loads(values[0]),after=json.loads(values[1]),equal=True))
report=dict(role='SDK mechanism comparison, not subject adherence or new-read temporal provenance proof',before_instruction_bytes=saved['instruction_bytes'],after_instruction_bytes=1705,bytes_removed=saved['instruction_bytes']-1705,reduction=(saved['instruction_bytes']-1705)/saved['instruction_bytes'],first512bytes_identical=True,serialized_tools_and_schemas_identical=True,representative_receipts=receipts,all_receipts_byte_identical=True,models_clients_requests=False,baseline_source='68fb205551c8f38148304adb5fa1bfd7fb22907c')
Path('work/mcp-policy-54-diff.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='representative_receipts'}))
