import hashlib,json,os,platform,subprocess,xml.etree.ElementTree as ET
from pathlib import Path
from datetime import datetime,timezone
w=Path('work');root=Path.cwd();parent=root.parent
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();baseline=subprocess.check_output(['git','rev-parse','origin/main'],text=True).strip()
assert source=='8380724d8ed678b01cf2f76265ec441626574cec'
assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='feat/benchmark-independent-evaluation'
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'])
assert not subprocess.check_output(['git','diff','d615580826efaac2969db8e445cd94c63f51b529','--','scripts',*[f'docs/results/benchmark-remediation/attempt-{i}' for i in range(1,55)]])
for kind in ['local','live']:
 for suffix in ['runtime','results']:assert not (parent/f'benchmark-remediation-{kind}-55-{suffix}').exists()
def put(name,obj):(w/name).write_text(json.dumps(obj,indent=2)+'\n',encoding='utf-8')
frozen=json.loads(Path('docs/results/benchmark-remediation/attempt-49/harness-hashes.json').read_text())['sha256']
for name,digest in frozen.items():assert hashlib.sha256(subprocess.check_output(['git','show',f'{source}:scripts/{name}'])).hexdigest()==digest
models=json.loads(Path('docs/results/benchmark-remediation/attempt-49/model-hashes.json').read_text())['models']
modelroot=Path('C:/Users/b3vel/Documents/Codex/2026-10-19/colony-summary-what-it-is-colony/work/colony-models')
for role,info in models.items():
 folder='embed' if role=='embedding' else 'rank'
 assert Path(os.environ['COLONY_EMBED_MODEL_DIR' if folder=='embed' else 'COLONY_RANK_MODEL_DIR']).resolve()==(modelroot/folder).resolve()
 for name,digest in info['files'].items():assert hashlib.sha256((modelroot/folder/name).read_bytes()).hexdigest()==digest
rules=json.loads(subprocess.check_output(['gh','api','repos/VivaanNarayana/colony/rulesets/25440133']))
required=next(r['parameters'] for r in rules['rules'] if r['type']=='required_status_checks')
assert len(required['required_status_checks'])==8 and required['strict_required_status_checks_policy']
assert rules['enforcement']=='active' and not rules['bypass_actors'] and rules['current_user_can_bypass']=='never'
put('required-gates-55.json',rules)
pr=json.loads(subprocess.check_output(['gh','pr','view','3','--json','isDraft,state,mergedAt,autoMergeRequest,headRefName']))
assert pr['isDraft'] and pr['state']=='OPEN' and pr['mergedAt'] is None and pr['autoMergeRequest'] is None
put('pr-preflight-55.json',pr)
suite=ET.parse(w/'full-55.xml').getroot().find('testsuite');a={k:float(v) if k=='time' else int(v) for k,v in suite.attrib.items() if k in ['tests','failures','errors','skipped','time']}
assert a['tests']==358 and a['failures']==1 and a['errors']==0 and a['skipped']==1
v=dict(commit=source,tests_passed=356,tests_failed=1,tests_skipped=1,pytest_seconds=a['time'],pytest_exit_code=1,ruff_passed=True,ruff_exit_code=0,diff_check_passed=True,platform=platform.platform(),known_failure='Unchanged explanatory session-expiry/deletion-permission false hit; no waiver.')
put('verification-55.json',v)
put('preflight-55.json',dict(trial=55,source=source,baseline=baseline,prepared_utc=datetime.now(timezone.utc).isoformat(),meaningful_runtime_changes=['Propagate observed context source-read contradictions into stale checks/status; discard partial context and continue alternatives. No extra source reads.'],tests=v,harness_sha256=frozen,models=models,all_models_unchanged=True,workers_idle_during_measurement=True,no_retries=True,local=dict(seed=20261021,variants=3,repetitions=3),live=dict(sessions=48,model='gpt-6-luna',reasoning='low',research_operations=6,per_session_seconds=240,aggregate_tokens=8000000),usage=dict(allowance=2,baseline=22,last_observed=23,stop=30,reset=1793294233),all_gates_blocking=True,all_eight_success_impossible_with_known_test_failure=True))
print(json.dumps(dict(source=source,baseline=baseline,verification=v,harness_models_verified=True)))
