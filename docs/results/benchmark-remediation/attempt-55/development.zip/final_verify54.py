import hashlib,json,subprocess
from pathlib import Path

sha=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
root='docs/results/benchmark-remediation';out=root+'/attempt-54'
def blob(path):return subprocess.check_output(['git','show',f'{sha}:{path}'])
manifest=json.loads(blob(out+'/sha256.json'))
for name,value in manifest.items():assert hashlib.sha256(blob(out+'/'+name)).hexdigest()==value,name
assert not subprocess.check_output(['git','diff','156658ee5baca2eb7dff4562b4dc01ff2b48eb02','--','scripts',*[f'{root}/attempt-{i}' for i in range(1,50)]])
assert not subprocess.check_output(['git','diff','29cc34e397a3b9567add715272cda4be04df1235','--',*[f'{root}/attempt-{i}' for i in range(50,54)]])
assert not subprocess.check_output(['git','diff','7f1cb1015ef18afde2f5e0b4be981bf35725a6cc','--','src','tests'])
local=json.loads(blob(out+'/lookup-summary.json'))
for arm in ['main','feature']:
 proofs=json.loads(blob(out+'/'+arm+'/loaded-implementations.json'))
 assert proofs and all(p['source_sha256']==local['loaded_implementations'][arm]['source_sha256'] for p in proofs)
rules=json.loads(subprocess.check_output(['gh','api','repos/VivaanNarayana/colony/rulesets/25440133']))
required=next(r['parameters'] for r in rules['rules'] if r['type']=='required_status_checks')
assert len(required['required_status_checks'])==8 and required['strict_required_status_checks_policy'] and not rules['bypass_actors'] and rules['enforcement']=='active' and rules['current_user_can_bypass']=='never'
for rule in required['required_status_checks']:
 payload=Path('work/status-54.json')
 payload.write_text(json.dumps(dict(state='failure',context=rule['context'],description='Trial54 integrity rejected; no complete gate verdict',target_url=f'https://github.com/VivaanNarayana/colony/blob/{sha}/{out}/README.md')),encoding='utf-8')
 subprocess.run(['gh','api',f'repos/VivaanNarayana/colony/statuses/{sha}','--input',str(payload)],check=True,stdout=subprocess.DEVNULL)
pr=json.loads(subprocess.check_output(['gh','pr','view','3','--json','isDraft,state,mergedAt,autoMergeRequest,headRefOid,headRefName']))
assert pr['isDraft'] and pr['state']=='OPEN' and pr['mergedAt'] is None and pr['autoMergeRequest'] is None and pr['headRefOid']==sha and pr['headRefName']=='feat/benchmark-independent-evaluation'
report=dict(head=sha,public_manifest_entries=len(manifest),manifest_git_blobs_verified=True,historical1through53_and_harness_unchanged=True,tested_source_still_identical=True,both_local_native_loaded_sources_match=True,required_checks=8,strict=True,no_bypass=True,all_current_checks_conservatively_failure=True,complete_eight_gate_verdict=False,pr=pr)
Path('work/final-integrity-54.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report))
