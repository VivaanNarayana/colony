import asyncio,json
from pathlib import Path
from types import SimpleNamespace
import colony.mcp

colony.mcp.Client=lambda home:SimpleNamespace()
server=colony.mcp.create_mcp(Path('.'))
snapshot=dict(instructions=server.instructions,instruction_bytes=len(server.instructions.encode('utf-8')),tools=[tool.model_dump() for tool in asyncio.run(server.list_tools())],note='SDK snapshot only; no model/client requests. Does not establish client rendering or adherence.')
destination=Path('work/mcp-policy-54-before.json')
assert not destination.exists()
destination.write_text(json.dumps(snapshot,indent=2)+'\n',encoding='utf-8')
print(snapshot['instruction_bytes'])
