import hashlib,json,shutil,subprocess,zipfile
from pathlib import Path
root=Path.cwd();w=root/'work';parent=root.parent;out=root/'docs/results/benchmark-remediation/attempt-55'
assert not out.exists();out.mkdir()
source='8380724d8ed678b01cf2f76265ec441626574cec';baseline='6fa6826aa4c835001c0d2bc8f3bec838499e5b5d'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==source
live=parent/'benchmark-remediation-live-55-results';runtime=parent/'benchmark-remediation-live-55-runtime';local=parent/'benchmark-remediation-local-55-results'
def put(name,value):(out/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')
def cp(path,name):
 dst=out/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,dst)
r=json.loads((live/'comparison.json').read_text(encoding='utf-8'));assert sum(r['gate'].values())==3 and r['data_budget_verified']
assert int((w/'analyzer-55.exit.txt').read_text(encoding='utf-8-sig'))==1
for arm in ['main','feature']:
 for n in ['raw-measurements.jsonl','loaded-implementations.json','metadata.json','corpus-sha256.json','reviews.json']:cp(live/arm/n,arm+'/'+n)
for n in ['comparison.json','completed.json','protocol.json']:cp(live/n,n)
cp(live/'review-mapping.json','review-records.json')
for a,b in [('manual-review-55.json','manual-review.json'),('frozen-labels-55.json','frozen-labels.json'),('verification-55.json','verification.json'),('preflight-55.json','preflight.json'),('required-gates-55.json','required-gates.json'),('local-55-audit.json','local-raw-audit.json'),('investigation-55.json','investigation-review.json'),('selected-native-review-55.json','selected-native-review.json'),('protocol-55-detail.json','protocol-detail.json')]:cp(w/a,b)
cp(root/'docs/results/benchmark-remediation/budget-allowance-2.json','usage-budget.json')
cp(parent/'benchmark-remediation-tool-audit-55.json','tool-audit.json');cp(parent/'benchmark-remediation-research-review-55.json','research-review.json')
for f in local.iterdir():
 if f.is_file():cp(f,f.name)
for n in ['local-55.stdout.txt','local-55-awake.json','local-55.exit.txt','live-55.stdout.txt','live-55-awake.json','live-55.exit.txt','analyzer-55.stdout.txt','analyzer-55.stderr.txt','analyzer-55.exit.txt','full-55.xml','final-tests-55.txt','final-tests-55-confirmed.txt','display-freshness-before.txt','display-freshness-after.txt']:cp(w/n,n)
for kind in ['local','live']:assert json.loads((w/f'{kind}-55-awake.json').read_text(encoding='utf-8-sig'))['request_released']
put('raw-totals.json',dict(all48_sessions_included=True,totals=r['arms']))
put('outcome.json',dict(trial=55,source=source,baseline=baseline,all_gates_passed=False,current_complete_eight_gate_verdict_available=True,gates_passed=3,gates_total=8,gate_statuses={'benchmarks/'+k:'success' if v else 'failure' for k,v in r['gate'].items()},blocking_gates=r['blocking_gates'],official_analyzer_invocations=1,local_invocations=1,native_invocations=1,native_sessions_completed=48,native_gross_tokens=2680060,cumulative_native50_through55_gross=13077278,all_outcomes_and_costs_retained=True,benchmark_or_session_restarts=0,proof_repair=False,tests_passed=356,tests_failed=1,tests_skipped=1,ruff_passed=True,usage=dict(allowance=2,baseline=22,last_observed=23,stop=30,reset=1793294233),status='Published intermediate checkpoint; budgeted work continues. No identical-runtime retry.',all_models_harness_and_gates_unchanged=True))
put('code-hashes.json',dict(source=source,sha256={n:hashlib.sha256(subprocess.check_output(['git','show',f'{source}:{n}'])).hexdigest() for n in subprocess.check_output(['git','ls-tree','-r','--name-only',source,'--','src','scripts','tests'],text=True).splitlines()}))
loc=json.loads((local/'lookup-summary.json').read_text(encoding='utf-8'))
rows='\n'.join(f"|{k}|{r['arms']['main'][k]:,.3f}|{r['arms']['feature'][k]:,.3f}|" for k in ['tokens','uncached_input_plus_output','seconds','research_calls','tool_calls'])
(out/'README.md').write_text(f'''# Trial55 — 3/8 strict gates pass; remediation unfinished

Runtime `{source}` against freshly fetched main `{baseline}`. One fresh local comparison and one full48-session native comparison, followed by one unchanged official analyzer invocation after frozen quality labels. All outcomes and costs retained; no session resampling, identical-code retry, proof repair or main exemption. PR3 remains draft, unmerged, without auto-merge. All eight strict required checks under ruleset25440133 remain active without bypass.

## Change and validation

An existing context read can observe a file change or deletion after successful validation. Previously, the candidate could retain validated/reuse status despite absent or partial current context, and could hide a valid alternative. Strict context reads now propagate that observed contradiction: downgrade the affected source check/status, discard the candidate's entire evidence and continue alternatives. Global source discovery remains tolerant. No extra source reads, cached snapshots or atomic-filesystem guarantee were added. Matching empty/binary sources remain validated without fabricated excerpts; redaction, source paths, hashes, assertions, scopes and freshness limits stay enforced.

Before patch: six new regressions failed, three controls passed. Final expanded suite: **356passed, onefailed, oneexisting Windows skip**; Ruff on src/tests/scripts and whitespace pass. The existing explanatory expiry/deletion-permission false hit remains red. One initial full suite also exposed an instrumented test wrapper not forwarding the new strict option; its signature was corrected without changing assertions. That failed outcome is retained. AstraHigh reviewed the implementation before measurement, finding no blocker; this fixes an observed source-integrity inconsistency, not the known semantic false hit or native performance regressions.

All retrieval models/weights and the gpt-6-luna/low subject remain unchanged. No auxiliary model, scoring/admission cutoff, workload, prompt, rubric, context/research/token/time budget, harness or source/scope/authentication/proof rule changed. MCP forced taint including explicitfalse and encrypted offline queue/retry remain unchanged. No research_paths, fixture hints, answer templates, rejected relevance boosts or unsafe context compaction.

## Eight gates and costs

Pass: loaded implementations, local lookup, correctness. Fail: tests/lint gate due the retained test failure, tool protocol, gross tokens, uncached tokens and live time. Feature gross tokens **+22.46%**, uncached **+32.38%**; elapsed **+0.31%**, with reduction95%CI **−13.78% to +10.51%**, crossing zero. Gross reductionCI−35.79%to−9.14%; uncached reductionCI−57.84%to−10.03%. No isolated native benefit is established by this run.

|Metric|Main|Feature|
|---|---:|---:|
{rows}

Local117/117each;234raw observations audited. Feature warm lookup time{100*loc['lookup_time_reduction']:.6f}%lower;95%reductionCI+{100*loc['latency_reduction_95pct'][0]:.6f}%to+{100*loc['latency_reduction_95pct'][1]:.6f}%. Warm public-development lookup excludes setup/push/coldstart/concurrency; repeated comparisons are not independent production confirmation.

## Quality, protocol and proof review

Coordinator reviewed all48 shuffled answers/current packets,41 current excerpts against exact frozen bytes/hash/line/redacted prefixes, and17 research/save traces. No new excerpt byte sequences versus history. Selected nonblind Astra review covered R21/R14/R27/R37/R28, not all48 independent blind grading. Core facts24/24both; citations15/24main and24/24feature. All nine invalid main targets remain false, including absolute R27/R37 paths. Initial R21 README96 receipt metadata remains irrelevant; final ask/push names answer the actual question after research. No newly required full signatures or all-family clauses. R14's changed-fingerprint fact is correct; non-Python symbol checks remain unverified, so do not generalize every unsupported symbol check as stale.

Every new-research session saved. All17 actual push attempts,22 fingerprints match actual preceding new reads and frozen corpus bytes; every receipt reports stored/queued. Main seven rows/two encrypted queue entries; feature ten rows/no queue. All actual taints true. Feature explicitfalse/offline handling remains unchanged test coverage, not native exercise here.

Tool protocol still fails: mainR33/scope1 and featureR48/scope1 each received a relevant validated packet, then performed one new server.py read and pushed. The unchanged gate expects zero pushes for relevant reuse. The new reads require saves under the existing research policy; eliminating unnecessary reads is still unresolved. Frozen labels and analyzer outcomes are retained without relabeling or rerun. These are unnecessary research/save sequences, not malformed proof or omitted-save cases. Initial metadata and wording-sensitive misses continue: feature mcp2 three research calls then valid save; stale2 four research calls then save (127209gross,six tools).

Native55gross2,680,060; cumulative50/51/53/54/55gross13,077,278;52native0. All historical failures, attempted saves, costs, labels and manifests1–54 remain byte-unchanged. No credits/reset/account switch/API billing. Fresh allowance2 was explicitly authorized22%to30%; latest observed23%, onepoint increase, reset2026-10-29 17:17:13UTC. Prior allowance/costs remain preserved. Reporting may lag; this is not a hard billing cap. Read usage before new phases; stop at30%, retain incomplete work and update RESUME.

Exact original native events/answers/prompts/labels, separately pinned implementations and frozen corpus are archived in live-native.zip; private databases/identity/queue keys excluded. Development.zip retains all scratch investigations, failed tests and supplemental errors, including a Unicode-decoding diagnostic failure. Public text usesLF; ZIP entries retain original bytes. sha256.json covers all other files. ZIP integrity verified; no offline analyzer replay claimed. Reversible wake requests released.
''',encoding='utf-8',newline='\n')
with zipfile.ZipFile(out/'development.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in sorted(w.rglob('*')):
  if f.is_file() and '__pycache__' not in f.parts:z.write(f,f.relative_to(w).as_posix())
with zipfile.ZipFile(out/'live-native.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in sorted(live.rglob('*')):
  if f.is_file():z.write(f,'results/'+f.relative_to(live).as_posix())
 for arm,folder in [('main','main'),('feature','feat')]:
  for f in sorted((runtime/'implementation'/arm).rglob('*.py')):z.write(f,'implementation/'+arm+'/'+f.relative_to(runtime/'implementation'/arm).as_posix())
  for f in sorted((runtime/folder/'repo').rglob('*')):
   if f.is_file():z.write(f,'corpus/'+arm+'/'+f.relative_to(runtime/folder/'repo').as_posix())
for n in ['development.zip','live-native.zip']:
 with zipfile.ZipFile(out/n) as z:assert z.testzip() is None
for f in out.rglob('*'):
 if f.is_file() and f.suffix in {'.json','.jsonl','.txt','.md','.xml'}:f.write_text(f.read_text(encoding='utf-8-sig'),encoding='utf-8',newline='\n')
put('sha256.json',{f.relative_to(out).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(out.rglob('*')) if f.is_file() and f.name!='sha256.json'})
assert not subprocess.check_output(['git','diff','d615580826efaac2969db8e445cd94c63f51b529','--','scripts',*[f'docs/results/benchmark-remediation/attempt-{i}' for i in range(1,55)]])
print(json.dumps(dict(directory=str(out),files=len(list(out.rglob('*'))),gates=r['gate'])))
