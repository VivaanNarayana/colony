import hashlib,json,shutil,subprocess,zipfile
from pathlib import Path
root=Path.cwd();w=root/'work';parent=root.parent;out=root/'docs/results/benchmark-remediation/attempt-54'
assert not out.exists();out.mkdir()
source='7f1cb1015ef18afde2f5e0b4be981bf35725a6cc';baseline='6fa6826aa4c835001c0d2bc8f3bec838499e5b5d'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==source
live=parent/'benchmark-remediation-live-54-results';runtime=parent/'benchmark-remediation-live-54-runtime';local=parent/'benchmark-remediation-local-54-results'
comparison=json.loads((live/'comparison.json').read_text(encoding='utf-8'))
assert comparison['blocking_gates']==['evidence_integrity'] and 'gate' not in comparison
assert int((w/'analyzer-54.exit.txt').read_text(encoding='utf-8-sig'))==1
def put(name,value):(out/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')
def cp(path,name):
 dst=out/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,dst)
totals={}
for arm in ['main','feature']:
 rows=[json.loads(line) for line in (live/arm/'raw-measurements.jsonl').read_text(encoding='utf-8').splitlines()]
 assert len(rows)==24
 totals[arm]={key:sum(row[key] for row in rows) for key in ['tokens','seconds','tool_calls','ask_calls']}
 totals[arm]['uncached_input_plus_output']=sum(row['tokens']-row['usage']['cached_input_tokens'] for row in rows)
 totals[arm]['research_calls']=sum(sum(e.get('type')=='item.completed' and e.get('item',{}).get('type')=='mcp_tool_call' and e['item'].get('server')=='repository' for e in [json.loads(line) for line in (live/arm/(row['task_id']+'.colony.events.jsonl')).read_text(encoding='utf-8').splitlines()]) for row in rows)
 for name in ['raw-measurements.jsonl','loaded-implementations.json','metadata.json','corpus-sha256.json','reviews.json']:cp(live/arm/name,arm+'/'+name)
assert sum(v['tokens'] for v in totals.values())==2671504
put('raw-totals.json',dict(descriptive_only=True,not_a_gate_verdict=True,all48_sessions_and_costs_included=True,totals=totals))
for src,name in [(live/'comparison.json','comparison.json'),(live/'completed.json','completed.json'),(live/'protocol.json','protocol.json'),(live/'review-mapping.json','review-records.json'),(w/'manual-review-54.json','manual-review.json'),(w/'frozen-labels-54.json','frozen-labels.json'),(w/'verification-54.json','verification.json'),(w/'preflight-54.json','preflight.json'),(w/'required-gates-54.json','required-gates.json'),(w/'local-54-audit.json','local-raw-audit.json'),(w/'independent-review-54.json','implementation-review.json'),(w/'mcp-policy-54-diff.json','sdk-policy-comparison.json'),(w/'usage-budget.json','usage-budget.json'),(w/'usage-samples.jsonl','usage-samples.jsonl'),(parent/'benchmark-remediation-tool-audit-54.json','tool-audit.json'),(parent/'benchmark-remediation-research-review-54.json','research-review.json')]:cp(src,name)
for file in local.iterdir():
 if file.is_file():cp(file,file.name)
for name in ['local-54.stdout.txt','local-54-awake.json','local-54.exit.txt','live-54.stdout.txt','live-54-awake.json','live-54.exit.txt','analyzer-54.stdout.txt','analyzer-54.stderr.txt','analyzer-54.exit.txt','full-54.stdout.txt','full-54.xml','full-54.exit.txt','full-54-awake.json','ruff-54.stdout.txt','ruff-54.exit.txt']:cp(w/name,name)
for kind in ['local','live','full']:assert json.loads((w/f'{kind}-54-awake.json').read_text(encoding='utf-8-sig'))['request_released']
review=dict(role='Bounded selected nonblind AstraHigh read-only native review; not all48 blind grading',findings=['R42 one mainpush without newresearch; valid64corpushash/queuedreceipt cannot establish temporalprovenance. Twoauditmessages refer to same actualattempt. No mainexemption/repair/retry.','Main15/24/feature24/24citationlabels confirmed.','R21 names ask/push with roles, sufficient for question/frozen expected. Do not invent fullsignature requirement; initialmetadata stillirrelevant.','R26 supplies hash-mismatch mechanism, not exhaustive optionalassertions explanation.','R37 satisfies servecommand rubric; do not require newinit/setuprecipe.'],analyzer_expectation='Expected integrity rejection before complete8gate verdict; no passing gates inferred.',tests_or_analyzer_run_by_reviewer=False)
put('selected-native-review.json',review)
put('outcome.json',dict(trial=54,source=source,baseline=baseline,status='Native completed; official evaluation rejected evidence integrity',all_gates_passed=False,current_complete_eight_gate_verdict_available=False,gates_passed=None,gates_total=8,blocking_integrity_error=comparison['integrity_error'],official_analyzer_invocations=1,analyzer_exit_code=1,local_invocations=1,native_invocations=1,native_sessions_completed=48,native_gross_tokens=2671504,total_task_native_gross_50_51_53_54=10397218,benchmark_retries=0,subject_resampling=0,all_attempts_and_costs_retained=True,proof_repair=False,main_exemption=False,tests_passed=340,tests_failed=1,tests_skipped=1,ruff_passed=True,models_harness_and_gates_unchanged=True,usage=dict(baseline=5,last_observed=12,stop=13,observed_increase=7,reset=1793294233),task='Unfinished; near stopping threshold, no newbenchmarkphase; publication/checkpoint finalization remains.'))
put('code-hashes.json',dict(source=source,basis='Committed Git blobs; final-source tests preceded measurement, loaded-source proofs retained.',sha256={name:hashlib.sha256(subprocess.check_output(['git','show',f'{source}:{name}'])).hexdigest() for name in subprocess.check_output(['git','ls-tree','-r','--name-only',source,'--','src','scripts','tests'],text=True).splitlines()}))
loc=json.loads((out/'lookup-summary.json').read_text(encoding='utf-8'));a,b=totals['main'],totals['feature']
table='\n'.join(f"|{key}|{a[key]:,.3f}|{b[key]:,.3f}|" for key in ['tokens','uncached_input_plus_output','seconds','tool_calls','research_calls'])
(out/'README.md').write_text(f'''# Trial54 — evidence-integrity rejection; no complete eight-gate verdict

Runtime `{source}` against freshly fetched/rechecked main `{baseline}`. Exactly one local invocation and one48-session native invocation completed. The unchanged official analyzer ran once after labels were frozen, exit1: **main/install-1.colony: push fingerprint does not match an actual source read**. It did not produce the complete eight-gate verdict. No passing gates are inferred or carried from earlier runtimes. Latest completed eight-gate comparison remains53,3/8, on a distinct source. All eight original strict required checks under ruleset25440133 remain active, no bypass/main exemption. PR3 stays draft/unmerged/noauto-merge.

## The retained invalid attempt

Main install1/R42 reused a sufficient current ask result, then pushed without ANY new repository research in that session. Its actual64lowercasehex README fingerprint matches frozen bytes, but came from ask and has no actual preceding new-read proof. The push returned queued=true. Neither correct file identity nor a queued receipt establishes admissible research provenance. This is ONE actual invalid push; two supplemental audit messages describe that same attempt. Do not call the hash malformed, truncate/repair it, inject a read afterward, discard the session, exempt main or retry this source. The archived invalidattempt and all costs remain unchanged.

Across17pushattempts/19attachedfingerprints,18fingerprints have actual preceding successful new reads and one does not. All17receipts indicate stored/queued success; no schema rejection occurred. Main has eight pushreceipts(three stored/five queued), feature nine stored. Storage audit has eightmainrows/five encryptedqueueentries and ninefeaturerows/no featurequeue. All actual taints are true. Feature explicitfalse/offline enforcement is covered by unchanged tests, not exercised natively here. Core/citation labels cannot cure integrity failure or establish a gate pass.

## Runtime change and validation

Only initialized MCP policy is deduplicated:2291to1705UTF8bytes,586bytes/25.58%removed. The first512bytes remain identical. SDK comparison proves unchanged serialized tools/schemas and eight representative receipts; it does not prove model adherence, temporalproofs or native savings. ProtocolSolHigh proposal and AstraHigh review map every unique obligation: askfirst/sourceinstructionsdata; save-before-answer after any newresearch with originalquestion/namespace; exact same-new-read paircopy, all64lowerhex/verbatim/no invent/retype/shorten/reconstruct; nonerror stored/queuedconfirmation, conflictingflags/rejectedsaves/reportfailure; sufficientreuse onlywithoutnewresearch and without confirmationreads/push evenfornewquestions; everyrequestedfact, missing/contradictory/miss/nonvalidatedresearch and configuredtoolattempts; concise supportedanswer, actual supportingfingerprints, search/askhashdisqualification; no repeatedrejectedarguments/rereadmerelysave; relative/verbatimcitations and requiredsteps/conditions/exceptions; servertaint.

No tool descriptions, schemas, receiptbehavior, runtimeproofguards, forcedtaint, queue/retry, authentication/scope/freshness/source safeguards, retrievalmodels/scores/cutoffs or frozenharness/prompts/workload/rubric/model/context/research/time/token budgets changed. No sourcecontextcompaction, task/path/keywordhints, answer templates, research_paths or rejected relevance boosts were added. The matching-version CLI cap remains512KiB, not512characters; important-first placement is a recommendation, not truncation evidence. Earlier safe request I/O changes remain, without isolated native-benefit claims.

Final-source suite **340passed, onefailed, oneexisting Windows skip**; Ruff on src/tests/scripts and whitespace pass. The real explanatory session-expiry/deletion-permission falsehit remains blocking, not waived/xfail. Wording assertions changed only where equivalent obligations were demonstrated; malformedproof/no-research/failure/taint negative coverage remains. Focused88pass and representativeSDK equivalence are supplementary. All workers were idle during both measurements; no subject/harness/model change or nesteddelegation occurred.

## Reviewed quality and descriptive costs

The coordinator reviewed all48 shuffled answers/currentpackets and17research/save traces; no new current excerpt byte sequences appeared versus retained history. Displayed bytes/lines/scrubbed prefixes, frozen filehashes and research search/read results were checked. Astra performed bounded selected nonblind review, including the invalid attempt and quality edge cases, not independent blind grading of all48. Corefacts24/24both; validcitations15/24main,24/24feature. Main invalidtargetsR01,R04,R09,R11,R28,R31,R32,R35,R43 stayfalse. FeatureR21 names ask/push withroles, sufficient for its actualquestion/frozenexpected; requiring fullsignatures would change grading. Its initial README96 metadata lacks the requested names and stays irrelevant. R26 states requested SHA256mismatch mechanism but omits optionalassertions; no exhaustive-validation claim. R37 satisfies the server-command rubric; no newly required initrecipe. Question-specific capture/outage grading remains unchanged.

Feature mcp2 performs four research calls(two reads/two searches including oneempty), then saves. Stale2 misses, performs three research calls(two searches/oneempty,one read), then saves:91145gross/five tools. Serve2 uses all six researchcalls before saving. Scope3 uses two before saving. All unnecessary/empty searches, pushes, queue behavior, cache variation and elapsedtime are counted.

Local117/117each,234raw observationsaudited; feature time{100*loc['lookup_time_reduction']:.6f}%lower with95%reduction interval+{100*loc['latency_reduction_95pct'][0]:.6f}%to+{100*loc['latency_reduction_95pct'][1]:.6f}%. This warm public workload excludes setup/push/coldstart/concurrency. It does not establish policy or native savings.

These are descriptive full-run totals, **not a passing performance comparison or replacement gate verdict**. No confidence requirement was relaxed and no interval/pass was invented after rejected official analysis.

|Metric|Main|Feature|
|---|---:|---:|
{table}

Native54gross2,671,504; task-native50+51+53+54gross10,397,218(52native0), plus all development/review cost in observed sharedusage. No outcome/session was restarted, discarded, repaired, resampled or selected as best. Trial50 malformed-save integrity failure,52startupfailure and all earlier costs/labels/manifests remain immutable. This run does not establish isolated benefits of policy shortening, HTTP pooling or redundant-work removal.

## Budget and exact checkpoint

Weekly baseline5%, latestobserved12%, stoppingthreshold13%; sevenobservedpoints consumed across coordinator/allworkers/subjects/development and conservatively shared external activity. Reset2026-10-29 17:17:13UTC does not renew the taskallowance. No reset/credits/API billing/account switch. Reporting lag/inflightcalls prevent a hard billingcap. No new benchmark phase with oneobservedpoint left; preserve headroom for publication/finalreport and read usage before any remaining work. Task remains unfinished. Exact state is in RESUME.txt; latestcomplete53 remains3/8, while54has no complete verdict. Do not retry54 unchanged, waive main, remove the redtest or add/change retrievalmodels.

Exact original native events/answers/prompts/packets/labels, implementationexports and frozen corpus are in live-native.zip. Development.zip retains policy snapshots, obligationmapping, SDKcomparison, tests, rejected investigations and errors. PrivateDBs/identity/queuekeys excluded. ZIPmember integrity verified, no offline analyzer replay claimed. Public text normalizesLF; archives retain exact originalbytes. sha256.json covers every other file. Attempts1–53 and all harnessfiles remain byte-unchanged. Wake requests released; persistentpowersettings unchanged.
''',encoding='utf-8',newline='\n')
with zipfile.ZipFile(out/'development.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for file in sorted(w.rglob('*')):
  if file.is_file() and '__pycache__' not in file.parts:z.write(file,file.relative_to(w).as_posix())
with zipfile.ZipFile(out/'live-native.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for file in sorted(live.rglob('*')):
  if file.is_file():z.write(file,'results/'+file.relative_to(live).as_posix())
 for arm,folder in [('main','main'),('feature','feat')]:
  for file in sorted((runtime/'implementation'/arm).rglob('*.py')):z.write(file,'implementation/'+arm+'/'+file.relative_to(runtime/'implementation'/arm).as_posix())
  for file in sorted((runtime/folder/'repo').rglob('*')):
   if file.is_file():z.write(file,'corpus/'+arm+'/'+file.relative_to(runtime/folder/'repo').as_posix())
for name in ['development.zip','live-native.zip']:
 with zipfile.ZipFile(out/name) as z:assert z.testzip() is None
for file in out.rglob('*'):
 if file.is_file() and file.suffix in {'.json','.jsonl','.txt','.md','.xml'}:file.write_text(file.read_text(encoding='utf-8-sig'),encoding='utf-8',newline='\n')
put('sha256.json',{file.relative_to(out).as_posix():hashlib.sha256(file.read_bytes()).hexdigest() for file in sorted(out.rglob('*')) if file.is_file() and file.name!='sha256.json'})
assert not subprocess.check_output(['git','diff','29cc34e397a3b9567add715272cda4be04df1235','--','scripts',*[f'docs/results/benchmark-remediation/attempt-{i}' for i in range(1,54)]])
resume=root/'docs/results/benchmark-remediation/RESUME.txt';old=resume.read_text(encoding='utf-8')
resume.write_text('''BUDGETED REMEDIATION — TRIAL54 INTEGRITY CHECKPOINT; NEAR STOPPING THRESHOLD.
Baseline5%, latest12%, STOP13%; observed7points; reset1793294233. Readusagebeforeanywork.
Allretrievalmodels unchanged. Subjects gpt-6-luna/low. PR3draft/unmerged/noautomerge.
Runtime7f1cb1015ef18afde2f5e0b4be981bf35725a6cc;mainfresh6fa6826aa4c835001c0d2bc8f3bec838499e5b5d.
Read attempt-54/README.md/comparison.json/manual-review.json/research-review.json/
tool-audit.json/outcome.json/selected-native-review.json/sdk-policy-comparison.json.
One local+one48native complete2671504gross;officialanalyzeronceafterlabelsfrozenexit1
EVIDENCE_INTEGRITY main/install1: pushhashfromaskwithoutANYprecedingnewresearchread.
Real64corpushash+queuedreceipt doesNOTqualify. ONEactualinvalidpush/twoauditmessages.
No repair/readinjection/retry/mainexemption. NO COMPLETE8GATEVERDICT for54; do notcarry
priorgreens. Latestcomplete53=3/8 ondistinctsource. All8strict25440133stillrequired.
Final340pass/1fail/1Windows skip,Ruff/whitespacepass; realwrong-attributeredtestretained.
Core24/24both,citations15/24main24/24feature(question-specificfrozenrubric). R21ask/push
names sufficient; don'trequirefullsignatures. InitialREADME96metadatairrelevant.
17pushes/19fingerprints,18validnewreadprovenance/1invalidmainreuseproof; allactualtainttrue.
Main8storedrows5queueentries;feature9rows0queue/noexplicitfalsecase. Unchangedtestsonly
providefeatureoffline/falsecoverage. Source/auth/scope/freshness/proof/queueguardssame.
Runtimeinitdedup2291to1705bytes(25.58%); first512/tools/schemas/8SDKreceiptsidentical.
No nativecausalbenefitproven. CLIcap512KiBnot512characters, no truncationclaim.
Local117/117both35.89%lower/positiveCI. Rawmain/featuregross1233904/1437600,
uncached171120/183584,seconds254.06/236.78,research21/31; DESCRIPTIVE notgateverdict.
Tasknative50+51+53+54gross10397218,52native0; allcosts/failures retained. No modelsadded.
NEXT: finalizebudgetpublication, readusage; no newbenchmarkwith1pointobservedheadroom.
At13stopallworker/modelphases, retainpartialresults and pauseexactcheckpoint. Allworkers
currentlyidle/no activenative. Do not retry54unchanged, exemptmain, waive redtest orreset.
Futureauthorizedremediationmustpreserveconsumedallowanceandfindmeaningfulgeneralruntime
fixbeforefreshcomparison. Wrongattribute falsehit, wordingsensitivity/metadata andnative
token/timegatesstillunresolved. Priorfailedheuristicsarenotapprovedfallbacks.
Earliercheckpoints belowpreservedhistory. Noautomaticjob. Taskunfinished.

'''+old,encoding='utf-8',newline='\n')
for rel,link in [('docs/results/benchmark-remediation/README.md','attempt-54/README.md'),('docs/benchmark-audit.md','results/benchmark-remediation/attempt-54/README.md'),('docs/results/benchmark-remediation/optional-runtime-removal.md','attempt-54/README.md')]:
 p=root/rel;old=p.read_text(encoding='utf-8');first,rest=old.split('\n',1)
 p.write_text(first+'\n\nLatest [trial54]('+link+') is an evidence-integrity rejection: main pushed askhash without newresearch. No complete8gateverdict; latestcomplete53=3/8.340pass/1fail/1skip;48sessions/allcostsretained. Weeklybaseline5%,observed12%,stop13%; nearbudgetstop/no newbenchmark, PR3draft.\n\n'+rest,encoding='utf-8',newline='\n')
print(json.dumps(dict(out=str(out),native_tokens=2671504,task_native_tokens=10397218,complete_gate_verdict=False,totals=totals),indent=2))
