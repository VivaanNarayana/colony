import hashlib,json,shutil,subprocess
from datetime import datetime,timezone
from pathlib import Path

root=Path.cwd();base=root/'docs/results/benchmark-remediation';now=datetime.now(timezone.utc).isoformat()
report=dict(status='Paused conservatively to preserve shared usage headroom; unfinished',baseline_weekly_used_percent=5,last_observed_weekly_used_percent=12,observed_increase_percentage_points=7,stopping_threshold_weekly_used_percent=13,threshold_observed=False,reported_percentage_point_headroom=1,reason='Reserve remaining reported point for usage-report lag, any accounting still in flight and final reporting; no new runtime/model/benchmark phase.',weekly_window_minutes=10080,resets_at=1793294233,resets_utc='2026-10-29 17:17:13 UTC',natural_reset_does_not_renew_allowance=True,no_credits_resets_or_api_billing=True,measurement_lag_can_overshoot=True,at_utc=now,branch='feat/benchmark-independent-evaluation',runtime='7f1cb1015ef18afde2f5e0b4be981bf35725a6cc',evidence_commit='9cf60d34136d3dede5a929d581730ce44f7efb1a',baseline_main='6fa6826aa4c835001c0d2bc8f3bec838499e5b5d',latest_trial=54,latest_complete_eight_gate_trial=53,latest_complete_gates_passed=3,current_complete_eight_gate_verdict=False,final_tests=dict(passed=340,failed=1,skipped=1,ruff=True),native_subject_tokens_this_task=10397218,all_costs_and_failures_retained=True,all_three_workers_idle=True,active_benchmark=False,unresolved=['Saved-answer wording sensitivity and wrong-attribute false hit','Current-source metadata selected instead of requested facts','Native gross/uncached/time improvement requirements','Trial54 main install1 proof from ask without preceding newread invalidates official analysis'],resume_checkpoint='Read RESUME.txt top and attempt54 README/comparison/manual-review/research-review/tool-audit. No identical-source benchmark retry. All models/guardrails/eight strict gates fixed. Reconcile original5% baseline/13% threshold and observed7point consumption before any future authorized work; stop if threshold already reached. Find a meaningful general runtime fix before another comparison; no approved pending retrieval patch.',pr=dict(number=3,draft=True,merged=False,auto_merge=False))
text='''PAUSED CONSERVATIVELY FOR SHARED USAGE HEADROOM — TASK UNFINISHED.
Startingweekly5%, lastobserved12%, increase7percentagepoints; hardstoppingthreshold13%.
13%HASNOTYETBEENOBSERVED. One reportedpoint reserved for accountinglag/inflightcosts
and finalreport; do not claim full8point allowanceconsumed or allgatespassed.
All3workersidle, noactivebenchmark, noautomaticjob. No furthermodel/runtime/benchmark
phase started after thischeckpoint. Naturalresetdoesnotrenew consumedallowance.
Reset1793294233=2026-10-29 17:17:13UTC. Noresetcredits/APIbilling/accountswitch used.
Usageisobserved/coarse/lagged, nothardbillingcap. Read reliableusagebeforefuturework;
preserveoriginal5%baseline/13%threshold and alreadyobserved7pointsconsumption.

EXACT RESUME: runtime7f1cb1015ef18afde2f5e0b4be981bf35725a6cc, evidencecommit9cf60d3,
main6fa6826aa4c835001c0d2bc8f3bec838499e5b5d, branchfeat/benchmark-independent-evaluation.
Read attempt-54/README.md,comparison.json,manual-review.json,research-review.json,
tool-audit.json,outcome.json,implementation-review.json,selected-native-review.json,
sdk-policy-comparison.json and budget-checkpoint.json. No pendingapprovedretrievalfix.
Trial54local+48nativecomplete; analyzeronceEVIDENCE_INTEGRITY: maininstall1usedaskhash
withoutprecedingnewresearch. Actual64hash/queuedreceipt doesn'tqualify. No mainexemption,
repair, injectedread, discardedcost, resampling oridentical-coderetry. No complete8gate
verdict for54; latestcomplete53=3/8 ondistinctruntime. Eightstrictchecksallrequired,
currentheadconservativelyfailure; nevercarryhistoricalgreensonto unprovenruntime.
Final340pass/1fail/1existingWindows skip; Ruff/whitespacepass. Wrong-attributeexpiry/
deletionpermissionredtestretained. Modelsunchanged/noauxmodel, subjectgpt-6-luna/low.
Core24/24both,citations15/24main24/24feature54reviewed; qualitylabelsdon'tcureproofviolation.
Tasknative50+51+53+54gross10397218,52native0; alldevelopment/reviewcostscountedaccountwide.
RESIDUAL: falsehit/wordingmisses, irrelevantmetadata and nativeperformance remainunsolved.
Any futurecomparisonneedsmeaningfulgeneralruntimechange, appropriatefinaltests/review,
freshmain, unchangedharness/model/budgets and actualnewreadproofs; neverretry54unchanged.
PR3draft/unmerged/noautomerge; history1-54/manifestsimmutable. Earliercheckpointbelow.

'''
p=base/'RESUME.txt';p.write_text(text+p.read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
(base/'budget-checkpoint.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
for rel,link in [('docs/results/benchmark-remediation/README.md','RESUME.txt'),('docs/benchmark-audit.md','results/benchmark-remediation/RESUME.txt'),('docs/results/benchmark-remediation/optional-runtime-removal.md','RESUME.txt')]:
 p=root/rel;old=p.read_text(encoding='utf-8');first,rest=old.split('\n',1)
 p.write_text(first+'\n\n[Paused checkpoint]('+link+'): observedweekly5%to12%(+7points), threshold13%notyetobserved; remainingreportedpointreservedforlag/finalreport. Unfinished. Trial54integrityrejection/no completeverdict; latestcomplete53=3/8. Allmodels/gatesfixed,PR3draft/unmerged.\n\n'+rest,encoding='utf-8',newline='\n')
evidence=base/'checkpoint-finalization';assert not evidence.exists();evidence.mkdir()
for name in ['final-integrity-54.json','final-verify-54.stdout.txt','final-verify-54.exit.txt','usage-samples.jsonl']:shutil.copyfile(root/'work'/name,evidence/name)
(evidence/'sha256.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in evidence.iterdir() if p.is_file()},indent=2)+'\n',encoding='utf-8',newline='\n')
assert not subprocess.check_output(['git','diff','9cf60d34136d3dede5a929d581730ce44f7efb1a','--','src','tests','scripts',*[str(Path('docs/results/benchmark-remediation')/f'attempt-{i}') for i in range(1,55)]])
body=(root/'work/pr-body-54.md').read_text(encoding='utf-8')
body+='\n\n**Paused conservatively for shared-budget headroom:** baseline5%, lastobserved12%, +7points. Threshold13%notyetobserved; one reportedpointreservedforaccountinglag/finalreport. Noactiveworkers/benchmark orfurther runtime/modelphase. Taskunfinished; futureworkmust reconcileoriginalbudget, notresetallowance. See RESUME.txt and budget-checkpoint.json on currentbranch.\n'
(root/'work/pr-body-final.md').write_text(body,encoding='utf-8')
print(json.dumps(report))
