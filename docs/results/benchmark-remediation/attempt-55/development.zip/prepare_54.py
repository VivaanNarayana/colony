import hashlib,json,os,platform,subprocess,sys,xml.etree.ElementTree as ET
from datetime import datetime,timezone
from pathlib import Path
root=Path.cwd(); work=root/'work'; parent=root.parent
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
baseline=subprocess.check_output(['git','rev-parse','origin/main'],text=True).strip()
assert source=='7f1cb1015ef18afde2f5e0b4be981bf35725a6cc'
assert baseline=='6fa6826aa4c835001c0d2bc8f3bec838499e5b5d'
assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='feat/benchmark-independent-evaluation'
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'])
assert not subprocess.check_output(['git','diff','29cc34e397a3b9567add715272cda4be04df1235','--','scripts',*[f'docs/results/benchmark-remediation/attempt-{i}' for i in range(1,54)]])
for kind in ['local','live']:
 for suffix in ['runtime','results']:
  assert not (parent/f'benchmark-remediation-{kind}-54-{suffix}').exists()
def put(name,obj):
 (work/name).write_text(json.dumps(obj,indent=2)+'\n',encoding='utf-8')
frozen=json.loads((root/'docs/results/benchmark-remediation/attempt-49/harness-hashes.json').read_text())['sha256']
for name,value in frozen.items():
 assert hashlib.sha256(subprocess.check_output(['git','show',f'{source}:scripts/{name}'])).hexdigest()==value
modelinfo=json.loads((root/'docs/results/benchmark-remediation/attempt-49/model-hashes.json').read_text())['models']
modelroot=Path('C:/Users/b3vel/Documents/Codex/2026-10-19/colony-summary-what-it-is-colony/work/colony-models')
assert Path(os.environ['COLONY_EMBED_MODEL_DIR']).resolve()==(modelroot/'embed').resolve()
assert Path(os.environ['COLONY_RANK_MODEL_DIR']).resolve()==(modelroot/'rank').resolve()
for role,info in modelinfo.items():
 for name,value in info['files'].items():
  assert hashlib.sha256((modelroot/('embed' if role=='embedding' else 'rank')/name).read_bytes()).hexdigest()==value
rules=json.loads(subprocess.check_output(['gh','api','repos/VivaanNarayana/colony/rulesets/25440133']))
required=next(r['parameters'] for r in rules['rules'] if r['type']=='required_status_checks')
assert len(required['required_status_checks'])==8 and required['strict_required_status_checks_policy']
assert rules['enforcement']=='active' and not rules['bypass_actors'] and rules['current_user_can_bypass']=='never'
put('required-gates-54.json',rules)
pr=json.loads(subprocess.check_output(['gh','pr','view','3','--json','isDraft,state,mergedAt,autoMergeRequest,headRefName,headRefOid']))
assert pr['isDraft'] and pr['state']=='OPEN' and pr['mergedAt'] is None and pr['autoMergeRequest'] is None
put('pr-preflight-54.json',pr)
suite=ET.parse(work/'full-54.xml').getroot().find('testsuite')
a={k:float(v) if k=='time' else int(v) for k,v in suite.attrib.items() if k in ['tests','failures','errors','skipped','time']}
assert a['tests']==342 and a['failures']==1 and a['errors']==0 and a['skipped']==1
verification=dict(commit=source,tests_passed=340,tests_failed=1,tests_skipped=1,pytest_seconds=a['time'],pytest_exit_code=1,ruff_passed=True,ruff_exit_code=0,diff_check_passed=True,platform=platform.platform(),scope='Final-source full suite. One preexisting newly exposed wrong-attribute false hit retained as blocking; no waiver.',known_failure='tests/test_saved_wording_regression.py explanatory login-session unsupported deletion attribute')
put('verification-54.json',verification)
put('preflight-54.json',dict(trial=54,source=source,baseline=baseline,prepared_utc=datetime.now(timezone.utc).isoformat(),meaningful_runtime_changes=['Initialization dedup2291to1705UTF8bytes with all unique obligations and first512bytes unchanged; SDK tools/schema/eightreceipts identical'],known_test_failure=True,tests=verification,harness_sha256=frozen,models=modelinfo,all_models_unchanged=True,workers_idle_during_measurement=True,no_retries=True,local=dict(seed=20261021,variants=3,repetitions=3),live=dict(sessions=48,model='gpt-6-luna',reasoning='low',research_operations=6,per_session_seconds=240,aggregate_tokens=8000000),usage=dict(baseline=5,last_observed=11,stop=13,reset=1793294233),all_gates_blocking=True,all_eight_success_impossible_with_known_test_failure=True))
print(json.dumps(dict(source=source,baseline=baseline,tests=verification,harness_models_verified=True),indent=2))
