"""Predeclared fresh polar controls; compare uncalibrated query logits once."""

import hashlib
import json
import re
import sys
from pathlib import Path

BASE = Path.cwd()
DIRECTORY = BASE / "work/retrieval-50"
SPECIFICATIONS = [
    (
        "How does a maintenance window affect notifications?",
        "Alerts are collected during planned downtime. Every collected alert is delivered once the window closes.",
        "Do maintenance periods discard queued notifications?",
        "Can maintenance notifications disclose a recipient's home address?",
    ),
    (
        "Which printing actions are available to operators?",
        "Operators can submit print jobs. Only supervisors may purge queued documents.",
        "Can ordinary operators cancel waiting print jobs?",
        "Can print operators change another employee's salary?",
    ),
    (
        "How long are laboratory specimens held?",
        "Specimens have a ninety-day holding period. At its end technicians destroy them.",
        "Are specimens still available after ninety days?",
        "Can stored specimens identify the person who collected them?",
    ),
    (
        "When are unpaid room reservations released?",
        "An unpaid booking is held until midnight on its creation date. The room then returns to the public inventory.",
        "Do unpaid reservations expire automatically?",
        "Can unpaid reservations charge a debit card without consent?",
    ),
    (
        "How does the sensor handle loss of external power?",
        "The sensor switches to its battery when external power disappears. It continues transmitting readings until the battery is empty.",
        "Can the sensor keep reporting after mains power fails?",
        "Can the sensor send payments after mains power fails?",
    ),
    (
        "When can library loans be extended?",
        "Members can extend a loan once. An outstanding hold prevents any extension.",
        "Can library loans be renewed while someone else is waiting?",
        "Can library loans reveal the previous borrower's phone number?",
    ),
    (
        "What tickets are required for child visitors?",
        "Visitors under five enter at no charge. They still need a complimentary admission pass.",
        "Are children admitted without a ticket?",
        "Can children's tickets authorize access to the conservation laboratory?",
    ),
    (
        "Which channel layouts can the audio encoder read?",
        "Inputs may contain either one or two channels. More than two channels are rejected.",
        "Does the audio encoder accept stereo recordings?",
        "Does the audio encoder prove who owns a recording?",
    ),
    (
        "What is the warranty coverage period?",
        "The coverage period is two years from purchase. Requests received after this interval are declined.",
        "Can warranty claims be submitted after coverage ends?",
        "Can a warranty claim reveal a purchaser's credit-card number?",
    ),
    (
        "What scheduling access do trainees have?",
        "Trainees may review planning drafts. Editing the live timetable is restricted to coordinators.",
        "Can trainees change a published schedule?",
        "Can trainees alter a customer's authentication settings?",
    ),
    (
        "How long does a transfer ticket remain valid?",
        "Each transfer expires one hour after it is issued. Expired transfers cannot be validated at a gate.",
        "Will a transfer ticket work after sixty minutes?",
        "Will a transfer ticket permit carrying hazardous freight?",
    ),
    (
        "How does inventory reservation work for orders?",
        "Stock is held when an order is accepted. Canceling that order returns every held unit to the available pool.",
        "Do canceled orders release reserved inventory?",
        "Do canceled orders erase customers' transaction histories?",
    ),
]


def prepare():
    cases = []
    for index, (saved, answer, positive, negative) in enumerate(SPECIFICATIONS):
        for supported, question in [(True, positive), (False, negative)]:
            cases.append(dict(origin="fresh-predeclared-polar", pair=index + 1,
                              saved_question=saved, content=answer, question=question,
                              expected_supported=supported))
    payload = (json.dumps(cases, indent=2) + "\n").encode()
    (DIRECTORY / "polar-topic-fresh-inputs.json").write_bytes(payload)
    digest = hashlib.sha256(payload).hexdigest()
    (DIRECTORY / "polar-topic-fresh-inputs.sha256").write_text(digest + "\n", encoding="utf-8")
    print(json.dumps(dict(cases=len(cases), positives=12, negatives=12, sha256=digest,
                         prepared_before_model_measurement=True)))


def measure():
    payload = (DIRECTORY / "polar-topic-fresh-inputs.json").read_bytes()
    digest = hashlib.sha256(payload).hexdigest()
    assert digest == (DIRECTORY / "polar-topic-fresh-inputs.sha256").read_text().strip()
    sys.path.insert(0, str(BASE.parent / "benchmark-remediation-live-49-runtime/implementation/feature/src"))
    from colony.retrieval import STOP_WORDS, local_term_support, rank, requires_procedure, terms
    old = json.loads((DIRECTORY / "predicate-diagnostic-v2.json").read_text(encoding="utf-8"))
    fresh = json.loads(payload)
    rows = []
    auxiliaries = set("can could do does did is are was were will would should has have may must".split())
    for case in old + fresh:
        question, saved, content = case["question"], case["saved_question"], case["content"]
        full, control = rank(question, [content[:4000], saved])
        literal = local_term_support(terms(question), content[:4000])
        exact = question.strip().casefold() == saved.strip().casefold()
        procedure = requires_procedure(question)
        tokens = re.findall(r"[A-Za-z][A-Za-z0-9'-]*", question)
        polar = bool(tokens) and tokens[0].casefold() in auxiliaries
        topic_terms = terms(saved)
        selected = [token for token in tokens if token.casefold() not in STOP_WORDS
                    and terms(token) & topic_terms]
        topic = " ".join(selected)
        proper = bool(terms(topic)) and terms(topic) < terms(question)
        original = exact or procedure or literal or full > max(0.0, control)
        apply = polar and proper and original and not (exact or procedure or literal)
        topic_score = rank(topic, [content[:4000]])[0] if apply else None
        revised = original and (not apply or full > topic_score)
        row = dict(case)
        row.update(
            original_scores=[full, control], literal_support=literal,
            polar=polar, procedure=procedure, exact=exact, topic_query=topic,
            proper_overlap=proper, guard_applied=apply, topic_score=topic_score,
            original_gate=original, revised_gate=revised,
            new_legitimate_miss=case["expected_supported"] and original and not revised,
            remaining_false_hit=not case["expected_supported"] and revised,
        )
        rows.append(row)
    output = dict(fresh_inputs_sha256=digest, fresh_count=len(fresh), old_count=len(old),
                  caveat="Outcome-motivated narrowing; cross-query logits are not calibrated.", rows=rows)
    (DIRECTORY / "polar-topic-fresh-diagnostic.json").write_text(json.dumps(output, indent=2) + "\n", encoding="utf-8")
    for row in rows:
        if row["guard_applied"] or row["remaining_false_hit"]:
            print(json.dumps(row))
    print(json.dumps(dict(cases=len(rows),
                         new_legitimate_misses=sum(row["new_legitimate_miss"] for row in rows),
                         remaining_false_hits=sum(row["remaining_false_hit"] for row in rows))))


if __name__ == "__main__":
    prepare() if sys.argv[1:] == ["--prepare"] else measure()
