"""Recall-only parent/child semantic alternative; no production changes."""

import hashlib
import json
import re
import sys
from pathlib import Path

BASE = Path.cwd()
DIRECTORY = BASE / "work/retrieval-50"
SPECIFICATIONS = [
    (
        "How do I configure a backup replicator?",
        "Which storage regions does the backup replicator use?",
        "The replicator polls for completed bundles. Logging rotates daily. Replicas are written to us-east-1 and eu-west-1.",
        "The replicator polls for completed bundles. Region metadata records opaque identifiers. Configured storage regions are listed elsewhere.",
    ),
    (
        "How do reservations expire?",
        "Can a reservation be renewed after expiry?",
        "Reservations last ten minutes. Renewals are permitted only before that deadline. Expired reservations cannot be renewed.",
        "Reservations last ten minutes. The phrase renewal after expiry is an index tag. This document does not specify whether an expired reservation can be renewed.",
    ),
    (
        "How do peer connections select a protocol?",
        "Can remote peers use protocol version two?",
        "Connection counters are sampled once a minute. Version two is accepted only for localhost. Remote connections require version three.",
        "Connection counters are sampled once a minute. Remote peer compatibility reports use JSON. Supported protocol versions are listed in a separate catalog.",
    ),
    (
        "How does laboratory dataset intake work?",
        "How many datasets may a laboratory upload per day?",
        "The intake service validates submitted manifests. Audit records remain for a month. Daily dataset uploads are limited to eight per laboratory.",
        "The intake service validates submitted manifests. Daily dataset upload limits appear in observation metadata. The number of permitted uploads is not stated here.",
    ),
]


def prepare():
    rows = []
    for index, (saved, question, positive, negative) in enumerate(SPECIFICATIONS):
        for supported, content in [(True, positive), (False, negative)]:
            rows.append(dict(origin="fresh-parent-child-control", pair=index + 1,
                             saved_question=saved, question=question, content=content,
                             expected_supported=supported))
    payload = (json.dumps(rows, indent=2) + "\n").encode()
    (DIRECTORY / "parent-child-fresh-inputs.json").write_bytes(payload)
    digest = hashlib.sha256(payload).hexdigest()
    (DIRECTORY / "parent-child-fresh-inputs.sha256").write_text(digest + "\n", encoding="utf-8")
    print(json.dumps(dict(cases=8, supported=4, unsupported=4, sha256=digest,
                         prepared_before_model_readout=True)))


def measure():
    import numpy as np
    sys.path.insert(0, str(BASE.parent / "benchmark-remediation-live-49-runtime/implementation/feature/src"))
    from colony.retrieval import embed, fused_score, local_term_support, passage, rank, requires_procedure, terms
    payload = (DIRECTORY / "parent-child-fresh-inputs.json").read_bytes()
    digest = hashlib.sha256(payload).hexdigest()
    assert digest == (DIRECTORY / "parent-child-fresh-inputs.sha256").read_text().strip()
    old = json.loads((DIRECTORY / "predicate-diagnostic-v2.json").read_text(encoding="utf-8"))
    prior_fresh = json.loads((DIRECTORY / "polar-topic-fresh-inputs.json").read_text(encoding="utf-8"))

    def cosine(left, right):
        left, right = np.frombuffer(left, np.float32), np.frombuffer(right, np.float32)
        return float(left @ right / (np.linalg.norm(left) * np.linalg.norm(right)))

    rows = []
    for case in old + prior_fresh + json.loads(payload):
        question, saved, content = case["question"], case["saved_question"], case["content"]
        query = embed(question, query=True)
        qcos = cosine(query, embed(saved, query=True))
        acos = cosine(query, embed(passage(saved, content)))
        sentences = re.split(r"(?<=[.!?])\s+", content[:4000])
        scores = rank(question, [content[:4000], saved, *sentences])
        full, control = scores[:2]
        child_scores = scores[2:]
        relevance = fused_score(max(qcos, acos), full)
        procedure = requires_procedure(question)
        exact = question.strip().casefold() == saved.strip().casefold()
        literal = local_term_support(terms(question), content[:4000])
        basic = max(qcos, acos) >= .55 and (qcos >= (.70 if procedure else .65) or exact)
        basic = basic and (relevance >= .60 or exact)
        original_support = exact or procedure or literal or full > max(0.0, control)
        child_support = any(score > max(0.0, control) for score in child_scores)
        original = basic and original_support
        revised = basic and (original_support or child_support)
        row = dict(case)
        row.update(
            question_cosine=qcos, parent_passage_cosine=acos, parent_relevance=relevance,
            original_dense_question_relevance_pass=basic,
            full_score=full, saved_question_control_score=control, literal_support=literal,
            exact=exact, procedure=procedure, sentences=sentences, sentence_scores=child_scores,
            child_scores_above_existing_control=[score > max(0.0, control) for score in child_scores],
            original_support_gate=original_support, child_support_gate=child_support,
            original_admitted=original, hypothetical_admitted=revised,
            new_supported_admission=case["expected_supported"] and not original and revised,
            new_unsupported_admission=not case["expected_supported"] and not original and revised,
            remaining_false_hit=not case["expected_supported"] and revised,
            source_guards="Held fixed as eligible; no change to scope/freshness/hash validation. This isolates model admission.",
            caveat="Parent content and evidence remain whole; max over children is a multiple-opportunity support heuristic.",
        )
        rows.append(row)
    (DIRECTORY / "parent-child-diagnostic.json").write_text(
        json.dumps(dict(fresh_inputs_sha256=digest, rows=rows), indent=2) + "\n", encoding="utf-8"
    )
    for row in rows:
        if row["new_supported_admission"] or row["new_unsupported_admission"] or row["origin"] == "retained-target":
            print(json.dumps({key: row[key] for key in [
                "origin", "question", "expected_supported", "question_cosine", "parent_relevance",
                "full_score", "saved_question_control_score", "sentences", "sentence_scores",
                "original_admitted", "hypothetical_admitted", "new_unsupported_admission",
            ]}))
    print(json.dumps(dict(cases=len(rows),
                         new_supported=sum(row["new_supported_admission"] for row in rows),
                         new_unsupported=sum(row["new_unsupported_admission"] for row in rows),
                         remaining_false_hits=sum(row["remaining_false_hit"] for row in rows))))


if __name__ == "__main__":
    prepare() if sys.argv[1:] == ["--prepare"] else measure()
