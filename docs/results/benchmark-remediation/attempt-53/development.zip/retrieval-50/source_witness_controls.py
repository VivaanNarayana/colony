"""Preregistered current-source witness controls; no retrieval implementation changes."""

import hashlib
import json
import sys
import tempfile
from pathlib import Path

BASE = Path.cwd()
DIRECTORY = BASE / "work/retrieval-50"
SPECIFICATIONS = [
    (
        "How do I link a client to the job dispatcher?",
        "Add a service entry to the client configuration and select its home directory. "
        "The available operations are poll() and schedule(job).",
        "Which operations does the job dispatcher provide?",
        "# Job dispatcher\n\nAdd a service entry and choose a client home.\n\nOperations: `poll()` and `schedule(job)`.\n",
        "# Job dispatcher\n\nAdd a service entry and choose a client home.\n\n"
        "The dispatcher exposes operation metadata in receipts. The receipts describe formatting and validation; operation definitions are documented elsewhere.\n",
    ),
    (
        "How do I attach a waveform exporter?",
        "Connect the exporter through TCP and select an output directory. Its available formats are FLAC and WAV.",
        "Which formats can the waveform exporter produce?",
        "# Waveform exporter\n\nConnect through TCP and select an output directory.\n\nFormats: Vorbis and AAC. These replace the formerly supported FLAC and WAV outputs.\n",
        "# Waveform exporter\n\nConnect through TCP and select an output directory.\n\n"
        "Format receipts contain validation flags and diagnostic identifiers. Supported output definitions are listed in a separate catalog.\n",
    ),
    (
        "How is a ticket cache configured?",
        "Configure the cache directory and its credentials. Entries have a thirty-second lifetime.",
        "What happens when a ticket cache entry expires?",
        "# Ticket cache\n\nConfigure a cache directory and credentials.\n\nAn expired entry is removed and the next request fetches a replacement from the issuer.\n",
        "# Ticket cache\n\nConfigure a cache directory and credentials.\n\n"
        "Ticket cache expiry metadata records observation times. This document does not describe behavior after expiry.\n",
    ),
    (
        "How do I run artifact verification?",
        "Run the package checker during publication. It compares each archive checksum with the manifest.",
        "What happens when artifact verification finds a different checksum?",
        "# Artifact verification\n\nRun the package checker during publication.\n\nA checksum mismatch rejects publication and returns a nonzero exit status.\n",
        "# Artifact verification\n\nRun the package checker during publication.\n\n"
        "The manifest displays checksum algorithm names. Mismatch handling is not specified in this document.\n",
    ),
    (
        "How are telemetry batches buffered?",
        "Telemetry batches are retained in a local spool for four hours before removal.",
        "Which encryption algorithm protects telemetry batches?",
        "# Telemetry batches\n\nBatches remain in the local spool for four hours.\n\nThe spool encrypts batch contents with AES-256-GCM.\n",
        "# Telemetry batches\n\nBatches remain in the local spool for four hours.\n\n"
        "Encryption receipts contain telemetry batch identifiers. The algorithm is unspecified; these receipts provide validation metadata only.\n",
    ),
    (
        "How do I start the camera bridge?",
        "Start the bridge service after choosing the input feed and its output directory. It supports image export.",
        "Which image formats does the camera bridge export?",
        "# Camera bridge\n\nStart the bridge after selecting an input feed.\n\nImage formats: BMP and JPEG.\n",
        "# Camera bridge\n\nStart the bridge after selecting an input feed.\n\n"
        "Image format metadata contains width, height and timing identifiers. This metadata describes receipts rather than supported image formats.\n",
    ),
]


def prepare():
    cases = []
    for index, (saved, answer, question, sufficient, insufficient) in enumerate(SPECIFICATIONS):
        for expected, source in [(True, sufficient), (False, insufficient)]:
            cases.append(dict(pair=index + 1, saved_question=saved, content=answer,
                              question=question, source_text=source, expected_sufficient=expected))
    payload = (json.dumps(cases, indent=2) + "\n").encode()
    (DIRECTORY / "source-witness-control-inputs.json").write_bytes(payload)
    digest = hashlib.sha256(payload).hexdigest()
    (DIRECTORY / "source-witness-control-inputs.sha256").write_text(digest + "\n", encoding="utf-8")
    print(json.dumps(dict(cases=len(cases), supported=6, unsupported=6, sha256=digest,
                         prepared_before_control_readout=True)))


def measure():
    import numpy as np
    sys.path.insert(0, str(BASE.parent / "benchmark-remediation-live-49-runtime/implementation/feature/src"))
    from colony.context import excerpts
    from colony.retrieval import embed, fused_score, local_term_support, passage, rank, terms
    from colony.validation import snapshot, validate
    payload = (DIRECTORY / "source-witness-control-inputs.json").read_bytes()
    digest = hashlib.sha256(payload).hexdigest()
    assert digest == (DIRECTORY / "source-witness-control-inputs.sha256").read_text().strip()

    def cosine(left, right):
        left, right = np.frombuffer(left, np.float32), np.frombuffer(right, np.float32)
        return float(left @ right / (np.linalg.norm(left) * np.linalg.norm(right)))

    rows = []
    for case in json.loads(payload):
        question, saved, content = case["question"], case["saved_question"], case["content"]
        query = embed(question, query=True)
        qcos = cosine(query, embed(saved, query=True))
        acos = cosine(query, embed(passage(saved, content)))
        full, control = rank(question, [content[:4000], saved])
        relevance = fused_score(max(qcos, acos), full)
        literal = local_term_support(terms(question), content[:4000])
        original_guard = max(qcos, acos) >= .55 and qcos >= .65 and relevance >= .60
        negative_above_control = control < full <= 0
        candidate = original_guard and negative_above_control and not literal
        with tempfile.TemporaryDirectory(prefix="colony-source-witness-") as temp:
            root = Path(temp)
            (root / "guide.md").write_text(case["source_text"], encoding="utf-8")
            sources = [snapshot(root, "guide.md")]
            status, checks = validate(root, sources)
            selected = excerpts(root, sources, question, claims=content)
            scores = rank(question, [row["text"] for row in selected])
            witness = any(score > max(0, control) for score in scores)
            accepted = candidate and status == "validated" and witness
            rows.append(dict(
                **case, query_question_cosine=qcos, query_answer_cosine=acos,
                relevance=relevance, full_score=full, control_score=control,
                literal_support=literal, original_dense_question_relevance_pass=original_guard,
                negative_above_control=negative_above_control, candidate_eligible=candidate,
                status=status, checks=checks, selected=[dict(**row, score=score) for row, score in zip(selected, scores)],
                strict_source_witness=witness, hypothetical_evidence_return=accepted,
                insufficient_evidence_return=accepted and not case["expected_sufficient"],
            ))
    (DIRECTORY / "source-witness-controls.json").write_text(json.dumps(dict(input_sha256=digest, rows=rows), indent=2) + "\n", encoding="utf-8")
    for row in rows:
        print(json.dumps({key: row[key] for key in [
            "pair", "expected_sufficient", "query_question_cosine", "query_answer_cosine",
            "relevance", "full_score", "control_score", "literal_support",
            "candidate_eligible", "strict_source_witness", "hypothetical_evidence_return",
            "insufficient_evidence_return",
        ]}))


if __name__ == "__main__":
    prepare() if sys.argv[1:] == ["--prepare"] else measure()
