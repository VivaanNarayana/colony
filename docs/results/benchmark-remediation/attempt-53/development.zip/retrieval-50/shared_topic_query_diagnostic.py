"""Cross-query logit comparison diagnostic, not calibrated answer support."""

import json
import re
import sys
from pathlib import Path

BASE = Path.cwd()
sys.path.insert(0, str(BASE.parent / "benchmark-remediation-live-49-runtime/implementation/feature/src"))

from colony.retrieval import STOP_WORDS, rank, terms  # noqa: E402


def main():
    directory = BASE / "work/retrieval-50"
    cases = json.loads((directory / "predicate-diagnostic-v2.json").read_text(encoding="utf-8"))
    assert len(cases) == 39
    rows = []
    for case in cases:
        query_terms = terms(case["question"])
        saved_terms = terms(case["saved_question"])
        tokens = re.findall(r"[A-Za-z][A-Za-z0-9'-]*", case["question"])
        selected = [token for token in tokens if token.casefold() not in STOP_WORDS
                    and terms(token) & saved_terms]
        topic = " ".join(selected)
        overlap = terms(topic)
        proper = bool(overlap) and overlap < query_terms
        topic_score = rank(topic, [case["content"][:4000]])[0] if proper else None
        original, control = case["original_scores"]
        old = case["old_gate"]
        applied = proper and not case["literal_support"] and old
        new = old and (not applied or original > topic_score)
        rows.append(dict(
            **case, original_query_terms=sorted(query_terms), saved_terms=sorted(saved_terms),
            shared_incoming_tokens=selected, topic_query=topic, topic_terms=sorted(overlap),
            proper_overlap=proper, topic_query_answer_score=topic_score,
            original_query_answer_score=original, original_query_control_score=control,
            extra_guard_applied=applied,
            original_score_above_topic_score=original > topic_score if proper else None,
            hypothetical_gate=new,
            new_legitimate_miss=case["expected_supported"] and old and not new,
            remaining_false_hit=not case["expected_supported"] and new,
            caveat="Cross-query logits are not calibrated; no runtime admission changes.",
        ))
    (directory / "shared-topic-query-diagnostic.json").write_text(json.dumps(rows, indent=2) + "\n", encoding="utf-8")
    for row in rows:
        print(json.dumps({key: row[key] for key in [
            "question", "expected_supported", "literal_support", "topic_query",
            "proper_overlap", "original_query_answer_score", "topic_query_answer_score",
            "extra_guard_applied", "old_gate", "hypothetical_gate",
            "new_legitimate_miss", "remaining_false_hit",
        ]}))
    print(json.dumps(dict(
        cases=len(rows), new_legitimate_misses=sum(row["new_legitimate_miss"] for row in rows),
        remaining_false_hits=sum(row["remaining_false_hit"] for row in rows),
        recommendation="Reject if any new legitimate miss or remaining false hit; no tuning.",
    )))


if __name__ == "__main__":
    main()
