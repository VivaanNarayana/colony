"""Dependent contextual-child recall probe; stop if neither retained target works."""

import hashlib
import json
import re
import sys
from pathlib import Path

BASE = Path.cwd()
DIRECTORY = BASE / "work/retrieval-50"
sys.path.insert(0, str(BASE.parent / "benchmark-remediation-live-49-runtime/implementation/feature/src"))

from colony.retrieval import passage, rank  # noqa: E402


def main():
    payload = (DIRECTORY / "parent-child-diagnostic.json").read_bytes()
    input_hash = hashlib.sha256(payload).hexdigest()
    all_rows = json.loads(payload)["rows"]
    targets_only = sys.argv[1:] == ["--targets"]
    if not targets_only:
        prior = json.loads((DIRECTORY / "contextual-child-target-diagnostic.json").read_text(encoding="utf-8"))
        assert prior["input_hash"] == input_hash
        assert any(row["contextual_child_qualifies"] for row in prior["rows"])
    rows = []
    for case in all_rows:
        if targets_only and case["origin"] != "retained-target":
            continue
        sentences = re.split(r"(?<=[.!?])\s+", case["content"][:4000])
        contextual = [passage(case["saved_question"], sentence) for sentence in sentences]
        control = passage(case["saved_question"], "")
        scores = rank(case["question"], [*contextual, control])
        support = [score > max(0.0, scores[-1]) for score in scores[:-1]]
        child = any(support)
        revised = case["original_admitted"] or (
            case["original_dense_question_relevance_pass"] and child
        )
        row = dict(case)
        row.update(
            contextual_sentences=contextual, contextual_child_scores=scores[:-1],
            structured_control=control, structured_control_score=scores[-1],
            qualifying_contextual_children=support, contextual_child_qualifies=child,
            contextual_or_rescue_admitted=revised,
            new_supported_contextual_admission=case["expected_supported"] and not case["original_admitted"] and revised,
            new_unsupported_contextual_admission=not case["expected_supported"] and not case["original_admitted"] and revised,
            remaining_false_hit=not case["expected_supported"] and revised,
            output_policy="Parent answer and source context unchanged; no compaction or certification.",
        )
        rows.append(row)
    name = "contextual-child-target-diagnostic" if targets_only else "contextual-child-rescue-diagnostic"
    (DIRECTORY / f"{name}.json").write_text(json.dumps(dict(input_hash=input_hash, rows=rows), indent=2) + "\n", encoding="utf-8")
    for row in rows:
        if targets_only or row["new_supported_contextual_admission"] or row["new_unsupported_contextual_admission"]:
            print(json.dumps({key: row[key] for key in [
                "origin", "question", "expected_supported", "full_score", "saved_question_control_score",
                "sentences", "contextual_child_scores", "structured_control_score",
                "qualifying_contextual_children", "original_admitted", "contextual_or_rescue_admitted",
                "new_supported_contextual_admission", "new_unsupported_contextual_admission",
            ]}))
    print(json.dumps(dict(cases=len(rows),
                         new_supported=sum(row["new_supported_contextual_admission"] for row in rows),
                         new_unsupported=sum(row["new_unsupported_contextual_admission"] for row in rows))))


if __name__ == "__main__":
    main()
