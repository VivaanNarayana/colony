"""Additional contextual sentence filter; never rescues a rejected full answer."""

import hashlib
import json
import re
import sys
from pathlib import Path

BASE = Path.cwd()
DIRECTORY = BASE / "work/retrieval-50"
sys.path.insert(0, str(BASE.parent / "benchmark-remediation-live-49-runtime/implementation/feature/src"))

from colony.retrieval import local_term_support, passage, rank, requires_procedure, terms  # noqa: E402


def main():
    old = json.loads((DIRECTORY / "predicate-diagnostic-v2.json").read_text(encoding="utf-8"))
    payload = (DIRECTORY / "polar-topic-fresh-inputs.json").read_bytes()
    digest = hashlib.sha256(payload).hexdigest()
    assert digest == (DIRECTORY / "polar-topic-fresh-inputs.sha256").read_text().strip()
    fresh = json.loads(payload)
    assert len(old) == 39 and len(fresh) == 24
    rows = []
    for case in old + fresh:
        question, saved, content = case["question"], case["saved_question"], case["content"]
        full, control = rank(question, [content[:4000], saved])
        literal = local_term_support(terms(question), content[:4000])
        exact = question.strip().casefold() == saved.strip().casefold()
        procedure = requires_procedure(question)
        original = exact or procedure or literal or full > max(0.0, control)
        sentences = re.split(r"(?<=[.!?])\s+", content[:4000])
        apply = original and not (exact or literal or procedure) and len(sentences) > 1
        contextual = [passage(saved, sentence) for sentence in sentences]
        structured_control = passage(saved, "")
        scores = rank(question, [*contextual, structured_control]) if apply else []
        supports = [score > max(0.0, scores[-1]) for score in scores[:-1]] if apply else []
        revised = original and (not apply or any(supports))
        row = dict(case)
        row.update(
            full_answer_score=full, original_question_control_score=control,
            literal_support=literal, exact=exact, procedure=procedure,
            original_gate=original, sentences=sentences, additional_filter_applied=apply,
            contextual_sentences=contextual, contextual_sentence_scores=scores[:-1] if apply else None,
            structured_control=structured_control, structured_control_score=scores[-1] if apply else None,
            supporting_sentences=supports, revised_gate=revised,
            new_legitimate_miss=case["expected_supported"] and original and not revised,
            remaining_false_hit=not case["expected_supported"] and revised,
            caveat="In-sample diagnostic; unchanged full output, not evidence of general safety.",
        )
        rows.append(row)
    (DIRECTORY / "contextual-sentence-diagnostic.json").write_text(
        json.dumps(dict(fresh_inputs_sha256=digest, cases=rows), indent=2) + "\n", encoding="utf-8"
    )
    for row in rows:
        if row["additional_filter_applied"] or row["remaining_false_hit"]:
            print(json.dumps({key: row[key] for key in [
                "origin", "question", "expected_supported", "full_answer_score",
                "original_question_control_score", "sentences", "contextual_sentence_scores",
                "structured_control_score", "original_gate", "revised_gate",
                "new_legitimate_miss", "remaining_false_hit",
            ]}))
    print(json.dumps(dict(cases=len(rows),
                         applied=sum(row["additional_filter_applied"] for row in rows),
                         new_legitimate_misses=sum(row["new_legitimate_miss"] for row in rows),
                         remaining_false_hits=sum(row["remaining_false_hit"] for row in rows))))


if __name__ == "__main__":
    main()
