from pathlib import Path
s=Path('work/audit_local_50.py').read_text(encoding='utf-8-sig').replace('-50-','-51-').replace('-50.','-51.')
Path('work/audit_local_51.py').write_text(s,encoding='utf-8')
