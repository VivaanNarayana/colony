from pathlib import Path
s=Path('work/inspect_50.py').read_text(encoding='utf-8-sig').replace('-50-','-51-').replace('-50.','-51.')
Path('work/inspect_51.py').write_text(s,encoding='utf-8')
