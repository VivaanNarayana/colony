import json,hashlib
from pathlib import Path
root=Path.cwd();out=root/'docs/results/benchmark-remediation/attempt-51'
c=json.loads((out/'comparison.json').read_text(encoding='utf-8'));local=json.loads((out/'lookup-summary.json').read_text(encoding='utf-8'))
m,f=c['arms']['main'],c['arms']['feature'];ci=c['descriptive_family_bootstrap_reduction_95pct']
rows='\n'.join(f"| {label} | {m[key]:,.3f} | {f[key]:,.3f} | {100*c['observed_reductions'][key]:+.6f}% | {100*ci[key][0]:+.6f}% to {100*ci[key][1]:+.6f}% | Fail |" for key,label in [('tokens','Gross input+output'),('uncached_input_plus_output','Uncached input+output'),('seconds','Summed subject seconds')])
text=f'''# Trial51 — 3/8 gates pass; five remain blocking

Measured feature `8604fc883fc4f8a85cb58d6420713d1c18c6966e` against freshly fetched/rechecked main `6fa6826aa4c835001c0d2bc8f3bec838499e5b5d`. Exactly one local invocation and one48-session native invocation completed; no benchmark/session restart, resampling, best-of selection or proof repair occurred. The unchanged official analyzer ran once after labels were frozen, exit1.

**Pass:** loaded implementations, local lookup, tool protocol. **Fail:** tests/lint gate, correctness/citations, gross tokens, uncached tokens and live time. All eight original strict checks remain active under ruleset25440133, without bypass or main exemption. PR3 stays draft/unmerged/no auto-merge. Trial50's evidence-integrity failure remains unchanged and is not replaced by this result.

## Change and tests

This runtime moves the existing requirement to copy all64 lowercase hexadecimal characters verbatim from the same successful new read into initialization's first512 characters and the push-description prefix. Miss guidance includes it within425bytes. Full policy discourages repeating rejected arguments and rereading merely to retry a model-submitted save. This does not change legitimate encrypted offline queue/retry. Strict schema, actual-preceding-new-read proofs, server-enforced taint (including explicit false), authentication, scope and freshness remain unchanged; no hash is padded, normalized, recomputed or reconstructed. The bounded answer-prefix fix from50 remains.

Final suite: **325passed, onefailed, oneexisting Windows skip**; Ruff/whitespace pass. The unrelated explanatory session-expiry/deletion-permission false hit remains a real failing test, not xfailed or waived. Three new SDK contract tests cover early proof visibility, bounded miss guidance and repeated unrelated abbreviated-proof rejection before Client.push. Focused87pass is supplementary and does not replace the failed full-suite result. Contract tests cannot prove model adherence.

SolHigh protocol work and AstraHigh review found no weakening in the final patch; workers were idle throughout timed measurement. Existing retrieval models and all model snapshots remain unchanged; subjects stay gpt-6-luna/low. The512-character placement is demonstrated. Client truncation and isolated policy causality are unproven.

## Quality and protocol

The coordinator reviewed all48 shuffled answers/current packets and14 research/save traces. The independent reviewer checked selected quality/proof cases, not all48 blind. No novel current excerpt byte sequences appeared versus retained attempts24–50; actual displayed bytes/lines and original source hashes match the frozen corpus. Both arms answer24/24 core facts. Citations are16/24 main and23/24 feature under the unchanged rubric. Feature serve-2/R08 cites invalid `/README.md:9`; it remains false and blocks correctness. Eight main invalid targets also remain false.

Feature mcp-2 still gets irrelevant receipt metadata at README96; its relevance label remains false. It researches in three calls (two searches/one read) and pushes successfully. Feature scope-3 researches in four calls (two searches/two reads), then copies an actual64-character digest and stores successfully. These outcomes do not repair trial50's two malformed40-character attempts or establish an isolated causal improvement.

All14 push attempts succeed under the frozen receipt rule; all15 attached file fingerprints match actual preceding new reads and frozen bytes. Main has six push receipts (three stored/three queued); feature has eight, all stored. The supplemental audit finds six main stored rows/three encrypted queue entries and eight feature rows/no feature queue. All actual feature taints are true. Main outage-1/R28 explicitly supplies false and retains false in storage/queue; this additional deviation stays documented outside the unchanged taint-agnostic gate. No main exemption or new rubric is introduced. Feature explicit-false/offline paths are covered by unchanged tests, not exercised natively here.

R25's saved answer explains queueing, while its displayed client.py59 excerpt concerns ask transport. Its citation target is accepted under the frozen path/target rule; do not claim those displayed lines directly prove queue implementation. Capture/outage facts are graded against each actual question consistently with historical grading, not newly against every family-level clause. See manual-review.json for qualifications.

## Local and native measurements

Both local arms pass117/117 independent oracle checks, with all234 raw rows audited. Main takes{local['modes']['main']['seconds']:.15f}s, feature{local['modes']['feature']['seconds']:.15f}s: **{100*local['lookup_time_reduction']:.6f}% lower**,95% reduction interval +{100*local['latency_reduction_95pct'][0]:.6f}% to +{100*local['latency_reduction_95pct'][1]:.6f}%. Model inference counts remain99 versus27 reranked passages,108 versus90 query embeddings.

| Measurement | Main | Feature | Reduction | 95% reduction interval | Gate |
| --- | ---: | ---: | ---: | --- | --- |
{rows}

Gross tokens increase17.64%, uncached input+output27.93%, and summed time0.71%; time's interval crosses zero. None of the native performance gates passes. Feature makes26 research calls versus17 main, and has16 useful/research-free correct hits versus18 main. All empty searches, saves, cache variation and elapsed time remain counted. The two arms use the same unchanged harness, corpus, prompts, order, rubric and budgets. Full gross cost is2,489,169 tokens; combined task-native cost through50+51 is5,088,862. Raw tokens across development and subject models are not converted into a shared usage percentage or dollar charge.

Stale-2 reuses a differently worded preceding answer, as in50; this does not demonstrate the unchanged wording-sensitive retrieval mechanism has been repaired. No individual optimization's causal effect is isolated by these combined samples. Public development evidence and descriptive intervals do not establish held-out production savings.

## Retention and active checkpoint

The archives retain exact original native events/answers/prompts/packets/labels, pinned implementations/corpus, development diagnostics and all test/attempted-save failures. Private databases and queue credentials remain outside publication. Both ZIP member checks pass; no offline analyzer replay is claimed. Public text copies normalize line endings; exact raw bytes remain archived. sha256.json covers all other files. Attempts1–50, their labels, manifests and failed outcomes remain byte-unchanged. Temporary wake requests released; persistent power settings unchanged.

Additional fixed-model source/topic-query heuristics were investigated with retained negative controls. A polar-only topic-query variant was rejected after three legitimate misses in24 preregistered fresh cases; its63 total outcomes/input hashes and initial instrumentation failure are retained. No rejected heuristic or auxiliary model was integrated. A separate source-witness hypothesis is still read-only and unproven.

Shared weekly usage: baseline5%, latest7%, stop13%; observed increase2 percentage points, account-wide and possibly lagged. Reset2026-10-29 17:17:13UTC. This publication does not reset the allowance. Work remains active within the same8-point budget; RESUME.txt records the exact next checkpoint. No identical-runtime retry is allowed.
'''
(out/'README.md').write_text(text,encoding='utf-8',newline='\n')
p=root/'docs/results/benchmark-remediation/RESUME.txt';old=p.read_text(encoding='utf-8')
new='''ACTIVE BUDGETED REMEDIATION — TRIAL51 PUBLISHED CHECKPOINT, October22,2026 Pacific.
Task unfinished/active. Weekly baseline5%, latest7%, STOP13%; observed consumption2points.
Combined allowance covers coordinator,all3workers,subjects/reviews; no newallowance/reset.
Reset1793294233=2026-10-29 17:17:13UTC. Read usage before every further phase.
All retrieval models MUST remain unchanged per explicit user clarification.

Runtime/tested source8604fc883fc4f8a85cb58d6420713d1c18c6966e.
Mainfresh/rechecked6fa6826aa4c835001c0d2bc8f3bec838499e5b5d.
Read attempt-51/README.md/comparison.json/manual-review.json/research-review.json/tool-audit.json.
One local+one native invocation,48sessions,2489169gross; NO retry/restart/resampling.
Official unchangedanalyzeronce exit1:3/8 PASS (loaded,local,protocol);5 FAIL(test,
correctness/citations,gross,uncached,time). All8 strict remainrequired, no bypass/mainexemption.
Finalsuite325pass/1fail/1existingWindows skip,Ruff/whitespacepass. Redwrongattribute
sessionexpiry/deletionpermissions test persists untouched. Featurecorefacts24/24,
citations23/24 because R08 /README.md invalid; main24/24facts,16/24citations.
All14pushattempts/15fingerprints valid; feature8storedtrue taint, nooffline/explicitfalse
nativecase. MainR28 outagefalse taint remainsadditionalungateddeviation, no newrubric.

Safe protocolchange frontloads full64hex/verbatimcopy in init/toolprefix and missreceipt;
no repeatrejectedargs/rereadmerelytosave. Strictschema/taint/queue/runtime unchanged.
No proofrepair. Trial50 two malformed40charattempts+costs+integrityfailure stayimmutable.
Modeladherencecausalityunproven; do notclaim clienttruncation proven. MCPmetadatawrong
selection and savedwording sensitivity stillunresolved. Gross+17.64%,uncached+27.93%,
time+0.71% with CIcrossingzero. Local117/117both,23.71% lowertime/positiveCI.

EXACT NEXT CHECKPOINT: retrievalworker currently investigating read-only source-witness
hypothesis: existing claims-selected current source excerpts as independentpositive
question support for otherwise rejected authoredanswer; originaldense/question/relevance/
scope/freshness mustremain, return evidence not certifyanswer. No runtimepatchproven.
Require unrelated negatives/independentreview; prior46 broadsemanticfallback is rejected,
notallowed torestore. Topic-query and polar-only variants newly rejected on legitimate
misses; frozenfresh24-input hash/all63outcomes retained in51 development.zip.
Do not remove/xfail the redtest, change models, relax gates or retry identicalruntime.
All3workers usedtotal,no nesting; coordinator alone commits/push/PR/checks/benchmarks.
PR3 remainsdraft/unmerged/noautomerge. Task-native50+51gross5088862tokens, allcostsretained.

EARLIER CHECKPOINTS BELOW — preserved history; this activecheckpoint takes precedence.

'''
p.write_text(new+old,encoding='utf-8',newline='\n')
p=root/'docs/results/benchmark-remediation/README.md';old=p.read_text(encoding='utf-8');first,rest=old.split('\n',1)
p.write_text(first+'\n\nLatest: **[trial51](attempt-51/README.md) passes3/8** (loaded,local,protocol). Tests, correctness/citations and all3 native performance gates remain blocking. Full325pass/1fail/1skip; feature citation23/24. All proofs valid in51;50 integrity failure retained. Shared weekly baseline5%, observed7%, stop13%; remediation remains active. PR3 draft/unmerged.\n\n'+rest,encoding='utf-8',newline='\n')
for f in out.rglob('*'):
 if f.is_file() and f.suffix in {'.json','.jsonl','.txt','.md','.xml'}:f.write_text(f.read_text(encoding='utf-8-sig'),encoding='utf-8',newline='\n')
(out/'sha256.json').write_text(json.dumps({f.relative_to(out).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(out.rglob('*')) if f.is_file() and f.name!='sha256.json'},indent=2)+'\n',encoding='utf-8',newline='\n')
print('Trial51 report written; complete3/8 verdict retained.')
