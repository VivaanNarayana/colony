from pathlib import Path
s=Path('work/publish_50.py').read_text(encoding='utf-8-sig')
s=s.replace('full-50-final','full-51').replace('d5a8669a0f354a33bbdaca470c6f26fab230eacf','8604fc883fc4f8a85cb58d6420713d1c18c6966e')
s=s.replace('-50','-51')
s=s.replace("assert comparison['blocking_gates']==['evidence_integrity']","assert sum(comparison['gate'].values())==3 and comparison['data_budget_verified']")
s=s[:s.index("put('outcome.json'")]+'''put('outcome.json',dict(trial=51,source=source,baseline=baseline,all_gates_passed=False,current_complete_eight_gate_verdict_available=True,gates_passed=3,gates_total=8,gate_statuses={'benchmarks/'+k:'success' if v else 'failure' for k,v in comparison['gate'].items()},blocking_gates=comparison['blocking_gates'],analyzer_exit_code=1,official_analyzer_invocations=1,local_invocations=1,native_invocations=1,native_sessions_completed=48,native_gross_tokens=2489169,benchmark_or_subject_session_restarts=0,all_attempts_and_costs_retained=True,proof_repair=False,tests_passed=325,tests_failed=1,tests_skipped=1,ruff_passed=True,models_harness_and_gates_unchanged=True,usage=dict(baseline=5,last_observed=7,stop=13,observed_increase=2,reset=1793294233),status='Published intermediate checkpoint; authorized shared-budget remediation continues. No identical-runtime benchmark retry.',draft=True,merged=False,auto_merge=False))
print(json.dumps(dict(out=str(out),totals=totals,files=len(list(out.rglob('*')))),indent=2))
'''
Path('work/publish_51.py').write_text(s,encoding='utf-8')
