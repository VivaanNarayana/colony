from pathlib import Path
from types import SimpleNamespace
import colony.mcp
colony.mcp.Client=lambda home:SimpleNamespace(ask=lambda *a,**kw:{'hit':False})
s=colony.mcp.create_mcp(Path('work'))
import json
p=s.instructions[:512]
r=json.loads(s._tool_manager.get_tool('ask').fn('Who may export reports?','ops')[0].text)['research_guidance']
print(json.dumps(dict(prefix=p,prefix_length=len(p),miss_guidance=r,miss_bytes=len(r.encode()),push_prefix=s._tool_manager.get_tool('push').description[:512]),indent=2))
