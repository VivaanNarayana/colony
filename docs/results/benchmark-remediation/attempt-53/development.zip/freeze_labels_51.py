import json,hashlib,shutil
from datetime import datetime,timezone
from pathlib import Path
from colony.security import scrub
root=Path.cwd();w=root/'work';results=root.parent/'benchmark-remediation-live-51-results';runtime=root.parent/'benchmark-remediation-live-51-runtime'
records=json.loads((results/'review-mapping.json').read_text(encoding='utf-8'))
assert len(records)==48 and not (results/'comparison.json').exists()
audit=json.loads(Path('../benchmark-remediation-tool-audit-51.json').read_text(encoding='utf-8'))
assert audit['raw_trace_errors']==[] and audit['taint']['feature']['all_tainted']
labels={'main':{},'feature':{}};errors=[]
for r in records:
 corpus=runtime/('main' if r['arm']=='main' else 'feat')/'repo'
 manifest=json.loads((results/r['arm']/'corpus-sha256.json').read_text(encoding='utf-8'))
 for p in r['packets']:
  for e in p.get('current_repository_reads',[]):
   data=(corpus/e['path']).read_bytes(); whole='\n'.join(scrub(data.decode()).splitlines()[e['start_line']-1:])
   if hashlib.sha256(data).hexdigest()!=e['sha256'] or manifest[e['path']]!=e['sha256'] or not whole.startswith(e['content']):errors.append([r['review_id'],e['path']])
 labels[r['arm']][r['task_id']+'.colony']=dict(correct=True,citation_valid=r['citation_valid'],relevant_asks=[False if r['review_id']=='R21' else bool(p.get('hit')) for p in r['packets']])
assert not errors
for a,ls in labels.items():
 assert len(ls)==24
 (results/a/'reviews.json').write_text(json.dumps(ls,indent=2)+'\n',encoding='utf-8')
frozen={a+'/reviews.json':hashlib.sha256((results/a/'reviews.json').read_bytes()).hexdigest() for a in labels}
(w/'frozen-labels-51.json').write_text(json.dumps(frozen,indent=2)+'\n',encoding='utf-8')
shutil.copyfile(w/'verification-51.json',results/'verification.json')
manual=dict(role='Primary coordinator reviewed all48 shuffled answers/current packets and14 research/save traces; not independent blind grading. Astra reviewer checked selected quality/proof cases only.',answers_reviewed=48,novel_current_contexts=0,core_facts_correct={a:sum(r['correct'] for r in ls.values()) for a,ls in labels.items()},valid_citations={a:sum(r['citation_valid'] for r in ls.values()) for a,ls in labels.items()},incorrect_core_fact_review_ids=[],invalid_citation_review_ids=[r['review_id'] for r in records if not r['citation_valid']],relevant_packet_exceptions=[dict(id='R21',arm='feature',task='mcp-2',relevant=False,reason='Same validated receipt metadata at README96 lacks requested tool signatures; research remains necessary.')],source_bytes_searches_and_new_read_hashes_verified=True,push_attempts=14,file_fingerprints=15,all_attempted_proofs_match_actual_preceding_new_reads=True,rejected_proofs=0,taint=dict(feature_stored=8,feature_queued=0,feature_all_true=True,feature_explicit_false=0,main_stored=6,main_queued=3,main_all_true=False,main_ungated_deviation=dict(id='R28',task='outage-1',explicit_false=True,stored_taint=False,queued_taint=False),limit='No feature explicitfalse/offline case; unchanged tests cover those paths. Do not waive main or alter frozen taint-agnostic gate.'),review_qualifications=['R25 savedanswer explains queueing, but displayed client.py59 excerpt concerns ask transport. Its citation is accepted under frozen target/path standard; do not claim displayed lines directly prove queue implementation.','Capture/outage answers graded against question-specific facts consistent with historical rubric; no new requirement that every family-level clause occur in every answer.','R08 feature absolute /README.md citation remains invalid.'],mcp2='Three new research calls (two searches, one read) followed by valid stored push; same insufficient initial packet.',scope3='Four new research calls (two searches, two reads) followed by one valid64-character stored push; does not repair or erase trial50 malformed attempts.',rubric_unchanged=True,labels_frozen_before_analyzer=True,frozen_utc=datetime.now(timezone.utc).isoformat())
(w/'manual-review-51.json').write_text(json.dumps(manual,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(facts=manual['core_facts_correct'],citations=manual['valid_citations'],bad=manual['invalid_citation_review_ids'],frozen=frozen),indent=2))
