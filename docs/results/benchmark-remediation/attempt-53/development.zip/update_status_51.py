from pathlib import Path
import json,hashlib,subprocess
out='docs/results/benchmark-remediation/attempt-51';sha=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
manifest=json.loads(subprocess.check_output(['git','show',f'HEAD:{out}/sha256.json']))
for n,h in manifest.items():assert hashlib.sha256(subprocess.check_output(['git','show',f'HEAD:{out}/{n}'])).hexdigest()==h,n
c=json.loads(subprocess.check_output(['git','show',f'HEAD:{out}/comparison.json']))
assert sum(c['gate'].values())==3
rules=json.loads(subprocess.check_output(['gh','api','repos/VivaanNarayana/colony/rulesets/25440133']))
r=next(x['parameters'] for x in rules['rules'] if x['type']=='required_status_checks')
assert len(r['required_status_checks'])==8 and r['strict_required_status_checks_policy'] and not rules['bypass_actors'] and rules['enforcement']=='active'
assert {x['context'] for x in r['required_status_checks']}=={'benchmarks/'+k for k in c['gate']}
for k,v in c['gate'].items():
 payload=Path('work/status-51.json');payload.write_text(json.dumps(dict(state='success' if v else 'failure',context='benchmarks/'+k,description='Trial51: '+('pass' if v else 'blocking failure')+'; unchanged strict analyzer',target_url='https://github.com/VivaanNarayana/colony/blob/'+sha+'/'+out+'/README.md')),encoding='utf-8')
 subprocess.run(['gh','api',f'repos/VivaanNarayana/colony/statuses/{sha}','--input',str(payload)],check=True,stdout=subprocess.DEVNULL)
print(json.dumps(dict(public_manifest_verified=len(manifest),passes=3,failures=5,strict_required=8,head=sha)))
