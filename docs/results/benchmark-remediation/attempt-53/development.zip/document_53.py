import hashlib,json,subprocess,zipfile
from pathlib import Path
root=Path.cwd();w=root/'work';out=root/'docs/results/benchmark-remediation/attempt-53'
c=json.loads((out/'comparison.json').read_text(encoding='utf-8'));local=json.loads((out/'lookup-summary.json').read_text(encoding='utf-8'))
m,f=c['arms']['main'],c['arms']['feature'];ci=c['descriptive_family_bootstrap_reduction_95pct']
review=dict(development_model='GPT-6 Astra High',read_only=True,runtime_blockers=[],runtime_review=['Atomic completed LEFT JOIN snapshot before unchanged registration return; full member tuple and scope multiset preserved; absent/empty/duplicate scopes distinguished.','Mismatch rechecked under BEGIN IMMEDIATE before atomic update; authentication verified every request, endpoint authorization uses verified grant.','Prechange writer-contention failure retained; postchange unchanged registration succeeds while another writer holds slot; changed grant remains locked then succeeds after release.','Earlier conditional MCP policy, connection commit boundary and selected-source freshness/redaction reviewed in52.'],selected_native_review=['R06 feature invalid absolute target retained; main18/24/feature23/24 valid targets.','R01/N1 exact incomplete source prefix contains required queue/retry facts; not complete implementation.','R14 stale2 correct answer after five actual research operations and successful save, full cost retained.','R21 initial metadata irrelevant, later researched correctness does not retroactively change relevance.','R47 bare repository-relative source reference accepted by unchanged parser, not described as rendered hyperlink.','All15 actual pushes/19fingerprints independently scanned for strict format and equality with preceding successful new read same path; zero mismatches.'],limits=['Bounded selected nonblind review, not all48 independent blind grading.','No reviewer tests/analyzer/model subjects.','Stored/queued taint actualrows only; zero featurequeue/explicitfalse cases, unchanged tests cover them.','Writer avoidance applies unchanged path, not global lock freedom or proven native savings.'])
(w/'independent-review-53.json').write_text(json.dumps(review,indent=2)+'\n',encoding='utf-8')
(out/'independent-review.json').write_text(json.dumps(review,indent=2)+'\n',encoding='utf-8')
rows='\n'.join(f"| {label} | {m[key]:,.3f} | {f[key]:,.3f} | {100*c['observed_reductions'][key]:+.6f}% | {100*ci[key][0]:+.6f}% to {100*ci[key][1]:+.6f}% | Fail |" for key,label in [('tokens','Gross tokens'),('uncached_input_plus_output','Uncached tokens'),('seconds','Subject seconds')])
text=f'''# Trial53 — 3/8 pass; retrieval, citations and native performance remain blocking

Runtime `68fb205551c8f38148304adb5fa1bfd7fb22907c` versus freshly fetched/rechecked main `6fa6826aa4c835001c0d2bc8f3bec838499e5b5d`. One fresh local invocation and one48-session native invocation completed. The unchanged analyzer ran exactly once after labels were frozen, exit1. No restart, individual-session resampling, best-of selection or proof repair occurred. Trial52's startup failure remains incomplete and unchanged; this distinct source adds a demonstrated writer-contention fix, rather than merely correcting the prior environment.

**Pass:** loaded implementations, local lookup, tool protocol. **Fail:** tests/lint, correctness/citations, gross tokens, uncached tokens, live time. All eight original strict required checks remain active under ruleset25440133, without bypass/main exemption. PR3 remains draft/unmerged/noauto-merge.

## Changes and tests

The runtime retains52's consistent mixed research/reuse save precedence, relative citation priority, unchanged-membership DML avoidance, ask/fallback connection sharing with an explicit answer-validation commit, and stopping before unused excerpt rereads. This follow-up reads membership and scopes in one completed SQL snapshot before reserving SQLite's writer slot. Identical membership returns from that snapshot; changed grants acquire BEGIN IMMEDIATE, recheck and refresh atomically. Signature/expiry checks still run for every request and endpoint authorization uses that verified grant. Full member tuple and scope multiset are compared; absent members, zero scopes and duplicate scopes remain distinct. No authentication cache was introduced.

The new unrelated lock regression failed before the change with database-is-locked and passes afterward: unchanged registration works while a second connection owns the writer slot, while changed registration fails without mutation and succeeds after release. This demonstrates that narrower behavior, not global lock freedom, arbitrary concurrency correctness or native performance savings. Concurrency snapshots are sampled. Safe connection/transaction/source/redaction tests from52 remain. Models, scores, ranking cutoffs and all source/freshness/scope/proof safeguards are unchanged; subjects stay gpt-6-luna/low. Strict actual-preceding-new-read64hex proofs, forced MCP taint including explicitfalse and encrypted queue/retry remain covered. No hash is repaired, inferred or fabricated.

Final-source suite: **340passed, onefailed, oneexisting Windows skip**; Ruff on src/tests/scripts and whitespace pass. The real unrelated explanatory session-expiry answer falsely accepted for deletion permissions remains blocking, unchanged and not xfailed. Previous test/initialization failures and all rejected proposals stay archived. AstraHigh read-only review found no blocking implementation issue; final tests preceded measurement, and all workers were idle throughout both timed runs. Scripted policy tests do not establish model adherence.

The matching-version CLI audit in52 finds a512KiB namespace-description cap, NOT512characters. No client-truncation mechanism or isolated instruction-order/receipt causality is claimed. The runtime policy fixes concrete competing wording; its model-behavior effects are not isolated by this combined trial.

## Quality and proof audit

The coordinator reviewed all48 shuffled answers/current packets, one novel source excerpt and15research/save traces. The independent Astra reviewer checked selected difficult cases and all15push proofs, not all48 blind. Both arms answer24/24 core facts. Valid citations are18/24main and23/24feature. Feature R06/outage1 cites invalid `/README.md`; this remains false despite earlier relative-citation guidance and blocks correctness. Main R07,R10,R15,R27,R31,R35 invalid targets also remain false.

All15push attempts succeed under the frozen receipt rule. All19attached fingerprints have strict64lowercasehex format and match actual preceding successful reads from the same path and frozen source bytes. Main six receipts include three stored/three queued; feature nine are stored. Storage audit has six main rows/three encrypted queue entries and nine feature rows/no queuedfeature. Actual taint is true throughout both arms. No feature explicitfalse/offline native case occurs; unchanged tests cover those paths. Prior main false-taint deviations remain historical evidence, without changing the taint-agnostic gate or exempting main.

R21/featuremcp2 initially gets the same irrelevant validated receipt metadata at README96, missing tool signatures. It performs five research calls (four searches/two empty, one read), then correctly answers and stores. That later correctness does not upgrade initial relevance. R14/featurestale2 misses a sufficient preceding answer, performs five research calls (three searches/one empty, two reads), then saves correctly:151447gross tokens and seven tools including ask/push. Feature serve2 uses all six research calls (four searches/one empty, two reads) before a valid save; scope3 uses three research calls then a valid save. All costs remain counted.

R01/N1 is a new exact prefix of current client.py94 text. It includes queue encryption/return and retry-pending behavior but ends midstatement `sent +`, with complete_file:false. It supports the asked facts and is not represented as complete code. R47's bare bracketed relative source reference is accepted under the unchanged target parser; it is not a rendered hyperlink. Capture/outage answers retain the established question-specific rubric rather than newly requiring every family clause in every answer. All current displayed bytes/lines, scrubbed prefixes, search lines and fingerprints were checked against frozen corpus manifests. File identity still does not establish answer completeness.

## Measurements

Local117/117both,234raw rows audited. Main{local['modes']['main']['seconds']:.12f}s, feature{local['modes']['feature']['seconds']:.12f}s: **{100*local['lookup_time_reduction']:.6f}% lower** with95% reduction interval +{100*local['latency_reduction_95pct'][0]:.6f}% to +{100*local['latency_reduction_95pct'][1]:.6f}%. Inference counts remain99vs27reranked passages and108vs90query embeddings. This warm public workload excludes setup/push/coldstart/concurrency; no individual optimization's causal effect is isolated.

| Metric | Main | Feature | Reduction | 95% reduction interval | Gate |
| --- | ---: | ---: | ---: | --- | --- |
{rows}

Gross increases33.82%, uncached31.16%. Summed subject time is2.28% lower but its interval crosses zero; time does not pass. Research calls increase16to32; useful/research-free correct hits decrease18to15, with16feature rawhits including irrelevantmetadata. These native regressions remain unresolved. Frozen harness/configuration, question order, prompts, rubric, models, context/research/token/time budgets and loaded-source isolation remain unchanged between arms. No workload/path/keyword hints, answer templates or broad unsafe relevance fallback was added. No research_paths or rejected compaction was restored.

Native cost is2,636,852gross; combined task-native50+51+53 is7,725,714 (52native0), plus all development/review work counted by shared account usage. Counts are not converted to percentage or dollar estimates. Weekly baseline5%, latest observed10%, stop13%, reset2026-10-29 17:17:13UTC. Observed task-account increase5points includes shared external activity conservatively; a reset does not renew allowance, and reporting lag prevents a hard billing cap. No reset/credits/API billing/account switch was used.

## Retention and checkpoint

Exact native events, failed/empty searches, saves, answers, prompts, labels, loaded-source proofs, implementation exports and frozen corpus remain in live-native.zip. Development.zip includes test failures, prechange contention failure, rejected diagnostics and review/source audit evidence; private DB/identity/queue key files are excluded. Both ZIP integrity checks pass; no offline analyzer replay is claimed. Public text normalizesLF; exact original bytes remain archived. sha256.json covers every other published file. Attempts1–52 and all harness files remain byte-unchanged. Wake requests released; no persistent power changes.

Task remains active within shared budget, unfinished. Next: assess whether duplicated runtime MCP policy can be consolidated while preserving every existing obligation and strict guard. No new runtime proposal has been approved or measured. Do not retry53 unchanged or remove/waive the red test. All three workers already used/no nesting; coordinator alone commits/pushes/PR/checks/fullcomparisons.
'''
(out/'README.md').write_text(text,encoding='utf-8',newline='\n')
resume=root/'docs/results/benchmark-remediation/RESUME.txt';old=resume.read_text(encoding='utf-8')
resume.write_text('''ACTIVE BUDGETED REMEDIATION — TRIAL53 PUBLISHED CHECKPOINT.
Baseline5%, latest10%, STOP13%; observed5points consumed; reset1793294233.
Read reliableusagebeforeanyphase. Allretrievalmodels unchanged, subjects gpt-6-luna/low.
Runtime68fb205551c8f38148304adb5fa1bfd7fb22907c; mainfresh6fa6826aa4c835001c0d2bc8f3bec838499e5b5d.
Read attempt-53/README.md/comparison.json/manual-review.json/research-review.json/
tool-audit.json/independent-review.json. One local+one48sessionnative,2636852gross.
Officialanalyzeronceafterlabelsfrozen exit1:3/8PASS loaded/local/protocol;5FAILtests,
correctness/citations,gross,uncached,time. All8strict25440133required/no bypass/mainexemption.
Final340pass/1fail/1existingWindows skip,Ruff/whitespacepass. Redwrongattributesession
expiry/deletionpermissiontestpersists. Core24/24both,citations18/24main23/24feature:
featureR06/outage1absolute/README.md invalid. R21/mcp2initialmetadatairrelevant.
All15pushattempts/19fingerprintsvalidactualprecedingreads; allactualtainttruebotharms.
Feature9stored0queued/noexplicitfalsecase; unchangedtestsofflinefalsecoverageonly.
Research16main/32feature;usefulhits18/15. Gross+33.82%,uncached+31.16%;time2.28%
lowerbutCIcrosszero. Local117/117both,34.14%lower/positiveCI. No nativebenefitproven.
Writer-contentionregressionfailsbefore/passafter:unchangedregisterusesoneconsistent
memberLEFTJOINscopereadbeforewriterlock;changedgrantslock/recheck/refreshatomically.
Authentication/scope/freshness/source/proof/taint/queueretryunchanged; models/scoresfixed.
52failedbeforequeriesbecausemissingmodelenvretainedINCOMPLETE/no retry/native/analyzer.
Next: boundedreviewofduplicatedruntimeMCPpolicyconsolidation, preservingeveryexisting
obligation. No newpatchapproved/measured. Do not retry53identicalorweaken/remove redtest.
MatchingCLIcap512KiB,not512characters; no isolatedtruncation/receipt/policycausality.
Rejectedsource-witness/sentence/childdiagnosticsremainrejected,allinputs/resultsarchived.
All3workersused/no nesting,idleduringmeasurement;coordinatoralone commits/push/PR/checks.
Native50+51+53gross7725714;52native0,alldevelopmentcostsretainedinaccountobservations.
PR3draft/unmerged/noautomerge. Taskunfinished/active,noautomation. Earlierhistorybelow.

'''+old,encoding='utf-8',newline='\n')
for rel,link in [('docs/results/benchmark-remediation/README.md','attempt-53/README.md'),('docs/benchmark-audit.md','results/benchmark-remediation/attempt-53/README.md'),('docs/results/benchmark-remediation/optional-runtime-removal.md','attempt-53/README.md')]:
 p=root/rel;old=p.read_text(encoding='utf-8');first,rest=old.split('\n',1)
 p.write_text(first+'\n\nLatest: [trial53]('+link+') passes3/8; tests, citations and all3nativeperformancegates remain blocking. Local34.14%lower; gross+33.82%,uncached+31.16%,timeCIcrosszero.340pass/1fail/1skip. Failed52retainedincomplete. Sharedbaseline5%,observed10%,stop13%; active, allmodelsfrozen,PR3draft/unmerged.\n\n'+rest,encoding='utf-8',newline='\n')
with zipfile.ZipFile(out/'development.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for file in sorted(w.rglob('*')):
  if file.is_file() and '__pycache__' not in file.parts:z.write(file,file.relative_to(w).as_posix())
for name in ['development.zip','live-native.zip']:
 with zipfile.ZipFile(out/name) as z:assert z.testzip() is None
for file in out.rglob('*'):
 if file.is_file() and file.suffix in {'.json','.jsonl','.txt','.md','.xml'}:file.write_text(file.read_text(encoding='utf-8-sig'),encoding='utf-8',newline='\n')
(out/'sha256.json').write_text(json.dumps({file.relative_to(out).as_posix():hashlib.sha256(file.read_bytes()).hexdigest() for file in sorted(out.rglob('*')) if file.is_file() and file.name!='sha256.json'},indent=2)+'\n',encoding='utf-8',newline='\n')
assert not subprocess.check_output(['git','diff','cb5620ae647387530374cf5ca77f90a0abeb3f2a','--','scripts',*[f'docs/results/benchmark-remediation/attempt-{i}' for i in range(1,53)]])
print('Trial53 full3/8 evidence published, history1-52 and harness unchanged.')
