import hashlib
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path

from colony.security import scrub

root=Path.cwd();work=root/'work';results=root.parent/'benchmark-remediation-live-53-results';runtime=root.parent/'benchmark-remediation-live-53-runtime'
records=json.loads((results/'review-mapping.json').read_text(encoding='utf-8'))
assert len(records)==48 and not (results/'comparison.json').exists()
audit=json.loads(Path('../benchmark-remediation-tool-audit-53.json').read_text(encoding='utf-8'))
assert audit['raw_trace_errors']==[] and all(v['all_tainted'] for v in audit['taint'].values())
labels={'main':{},'feature':{}};errors=[]
for record in records:
 corpus=runtime/('main' if record['arm']=='main' else 'feat')/'repo'
 manifest=json.loads((results/record['arm']/'corpus-sha256.json').read_text(encoding='utf-8'))
 for packet in record['packets']:
  for e in packet.get('current_repository_reads',[]):
   data=(corpus/e['path']).read_bytes();current='\n'.join(scrub(data.decode()).splitlines()[e['start_line']-1:])
   if hashlib.sha256(data).hexdigest()!=e['sha256'] or manifest[e['path']]!=e['sha256'] or not current.startswith(e['content']):errors.append([record['review_id'],e['path']])
 labels[record['arm']][record['task_id']+'.colony']=dict(correct=True,citation_valid=record['citation_valid'],relevant_asks=[False if record['review_id']=='R21' else bool(packet.get('hit')) for packet in record['packets']])
assert not errors
assert [r['review_id'] for r in records if r['arm']=='feature' and not r['citation_valid']]==['R06']
assert [r['review_id'] for r in records if r['arm']=='main' and not r['citation_valid']]==['R07','R10','R15','R27','R31','R35']
for arm,items in labels.items():
 assert len(items)==24
 (results/arm/'reviews.json').write_text(json.dumps(items,indent=2)+'\n',encoding='utf-8')
frozen={arm+'/reviews.json':hashlib.sha256((results/arm/'reviews.json').read_bytes()).hexdigest() for arm in labels}
(work/'frozen-labels-53.json').write_text(json.dumps(frozen,indent=2)+'\n',encoding='utf-8')
shutil.copyfile(work/'verification-53.json',results/'verification.json')
manual=dict(role='Primary coordinator reviewed all48 shuffled answers/current packets,1novel excerpt and15research/save traces. Not independent blind grading; AstraHigh reviewed selected difficult cases only.',answers_reviewed=48,novel_current_contexts=1,core_facts_correct={arm:sum(r['correct'] for r in items.values()) for arm,items in labels.items()},valid_citations={arm:sum(r['citation_valid'] for r in items.values()) for arm,items in labels.items()},incorrect_core_fact_review_ids=[],invalid_citation_review_ids=[r['review_id'] for r in records if not r['citation_valid']],relevant_packet_exceptions=[dict(id='R21',arm='feature',task='mcp-2',relevant=False,reason='Same validated receipt metadata at README96 lacks requested tool signatures; new research necessary.')],source_bytes_searches_and_new_read_hashes_verified=True,push_attempts=15,file_fingerprints=19,all_attempted_proofs_match_actual_preceding_new_reads=True,rejected_proofs=0,taint=dict(feature_stored=9,feature_queued=0,feature_all_true=True,feature_explicit_false=0,main_stored=6,main_queued=3,main_all_true=True,limit='No feature explicitfalse/offline native case; unchanged tests cover those paths. Main earlier deviations retained in historical50/51; no main exemption/newrubric.'),review_qualifications=['R01 novel client.py94 excerpt contains queue encryption/retry logic and ends mid increment after pending/queue facts; partial excerpt not complete implementation. Byte/line/hash scrub checks pass.','R47 plain bracketed source path accepted under unchanged frozen citation parser; do not strengthen or weaken path/target standard or claim pinpoint line support.','Capture/outage answers graded against actual question-specific facts consistent with historical rubric, not every family-level clause in every answer.','Feature R06 absolute /README.md remains invalid, despite early citation guidance.'],mcp2='Five research calls (four searches including two empty,one read) then valid stored push; initial metadata packet remains irrelevant.',stale2='Miss;five research calls (three searches including one empty,two reads) then valid stored push;151447gross tokens, seven tools including ask/push.',serve2='Miss;six research calls (four searches including one empty,two reads) then valid stored push;research budget exhausted without omission of save.',scope3='Miss;three research calls (two searches including one empty,one read) followed by valid stored push.',rubric_unchanged=True,labels_frozen_before_analyzer=True,frozen_utc=datetime.now(timezone.utc).isoformat())
(work/'manual-review-53.json').write_text(json.dumps(manual,indent=2)+'\n',encoding='utf-8')
with (work/'usage-samples.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(dict(atUtc=datetime.now(timezone.utc).isoformat(),phase='after-trial53-native-and-manual-review',usedPercent=10,resetsAt=1793294233,threshold=13))+'\n')
print(json.dumps(dict(facts=manual['core_facts_correct'],citations=manual['valid_citations'],frozen=frozen),indent=2))
