import json
from datetime import datetime, timezone
from pathlib import Path

work = Path('work')
base = 'https://github.com/openai/codex/blob/51f97c6bca5500edbb986f6d9fe64fa2e63cbdd4/'
audit = {
 'audit': 'Matching-version regular MCP instruction delivery; read-only investigation',
 'cli_version': 'codex-cli 0.163.0-alpha.11.2',
 'retained_native_metadata_versions': ['trial50: same', 'trial51: same'],
 'matching_upstream_tag': 'rust-v0.163.0-alpha.11.2',
 'matching_upstream_commit': '51f97c6bca5500edbb986f6d9fe64fa2e63cbdd4',
 'sources': [
  {'url':base+'codex-rs/codex-mcp/src/rmcp_client.rs#L1026','finding':'Initialization instructions passed into tool conversion.'},
  {'url':base+'codex-rs/codex-mcp/src/rmcp_client.rs#L845','finding':'Regular MCP namespace_description receives full instructions.'},
  {'url':base+'codex-rs/core/src/tools/handlers/mcp.rs#L502','finding':'Description emitted in model-visible namespace.'},
  {'url':base+'codex-rs/core/src/tools/handlers/mcp.rs#L49','finding':'Namespace description cap 512*1024 bytes, NOT 512 characters.'},
  {'url':base+'codex-rs/tools/src/mcp_tool.rs#L11','finding':'Regular MCP descriptions unlimited here; separate agent-plugin limit1000bytes not expected for frozen benchmark configuration.'},
  {'url':base+'codex-rs/tools/src/tool_spec.rs#L82','finding':'Tool specification serialized into Responses API JSON.'},
  {'url':'https://developers.openai.com/plugins/build/mcp-server','finding':'Important instructions within512characters is a recommendation, not evidence this client truncates there.'},
 ],
 'limitations':['Installed binary reproducibility against public tag unverified.', 'Actual benchmark model-request payloads were not retained.', 'Matching-version pipeline supports expected instruction delivery but does not prove each rendering.', 'No isolated causal proof for shortened receipts, initialization ordering or missed/successful pushes.'],
 'runtime_conclusion':'Conditional wording ambiguity can be corrected generally; no512character client truncation mechanism is claimed.',
 'development_models':'Protocol Sol6.1 High; independent Astra High review; benchmark subject unchanged gpt-6-luna/low.',
}
(work/'cli-instruction-source-audit-52.json').write_text(json.dumps(audit,indent=2)+'\n',encoding='utf-8')
review = {
 'phase':52,'reviewer':'GPT-6 Astra High','read_only':True,'blockers':[],
 'reviewed':['MCP mixed reuse/research precedence','Store.register full tuple and scope multiset atomic no-op','Ask connection reuse explicit answer-stage commit','Excerpt display capacity before unused read','New membership/connection/capacity regressions'],
 'findings':['Per-request signature and expiry verification unchanged; endpoint scope checks use verified grant.', 'Duplicate scopes still fail atomically.', 'Fallback-stage rollback preserves committed answer validation.', 'Selected excerpts still hash-check and scrub; stale candidates do not consume slots.', 'No retrieval model, score, threshold or harness edits.'],
 'limitations':['No-op registration still acquires a writer lock; no contention reduction established.', 'Concurrency regression samples interleavings, not a formal proof.', 'SDK instruction tests cannot establish subject adherence.', 'Known unrelated wrong-attribute false hit remains a blocking red test.'],
 'measurement':'One fresh complete comparison admissible after final tests; causal performance benefit unproved.'
}
(work/'independent-review-52.json').write_text(json.dumps(review,indent=2)+'\n',encoding='utf-8')
with (work/'usage-samples.jsonl').open('a',encoding='utf-8') as f:
 f.write(json.dumps({'atUtc':datetime.now(timezone.utc).isoformat(),'phase':'post-phase52-implementation-and-independent-review','usedPercent':7,'resetsAt':1793294233,'threshold':13})+'\n')
print('Recorded source audit, bounded review and observed7% usage sample; no benchmark claim.')
