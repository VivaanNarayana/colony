import hashlib,json,subprocess
from pathlib import Path
sha=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
out='docs/results/benchmark-remediation/attempt-52'
manifest=json.loads(subprocess.check_output(['git','show',f'{sha}:{out}/sha256.json']))
for name,value in manifest.items():assert hashlib.sha256(subprocess.check_output(['git','show',f'{sha}:{out}/{name}'])).hexdigest()==value,name
rules=json.loads(subprocess.check_output(['gh','api','repos/VivaanNarayana/colony/rulesets/25440133']))
required=next(r['parameters'] for r in rules['rules'] if r['type']=='required_status_checks')
assert len(required['required_status_checks'])==8 and required['strict_required_status_checks_policy'] and not rules['bypass_actors'] and rules['enforcement']=='active'
for rule in required['required_status_checks']:
 data=dict(state='failure',context=rule['context'],description='Trial52 incomplete startup; no passing gate evidence',target_url=f'https://github.com/VivaanNarayana/colony/blob/{sha}/{out}/README.md')
 Path('work/status-52.json').write_text(json.dumps(data),encoding='utf-8')
 subprocess.run(['gh','api',f'repos/VivaanNarayana/colony/statuses/{sha}','--input','work/status-52.json'],check=True,stdout=subprocess.DEVNULL)
body='''The independent benchmark retains all eight original strict required checks under ruleset25440133, without bypass or main exemption. PR remains draft and unmerged.

Latest: [trial52 evidence](https://github.com/VivaanNarayana/colony/tree/feat/benchmark-independent-evaluation/docs/results/benchmark-remediation/attempt-52) records an incomplete local startup failure. The coordinator omitted explicit verified model-directory environment variables; default-cache tokenizer metadata was missing. Zero queries completed; no native52 or analyzer52 invocation. No identical-runtime retry, no passing gate verdict. Current-head checks conservatively remain failures, not carried-over successes.

Runtime e389235 makes mixed research/reuse save precedence consistent, prioritizes relative citations, avoids identical membership rewrites, shares ask/fallback connections while preserving transaction boundaries, and skips unused excerpt rereads. Final339passed/1failed/1existing Windows skip; lint passes. The real session-expiry/deletion-permissions false hit remains blocking. Independent review found no blocking patch issue, but performance benefit remains unmeasured. All retrieval models remain unchanged; subjects remain gpt-6-luna/low. Exact64-character new-read proof admission, forced MCP taint including explicit false, encrypted queue/retry, authentication, scope and freshness are unchanged.

The matching-version Codex CLI source audit finds a512KiB namespace cap, not512characters. Important-first placement is a documentation recommendation; truncation and isolated policy causality are unproved. All limitations and immutable primary links are archived.

Latest complete comparison: [trial51](https://github.com/VivaanNarayana/colony/tree/feat/benchmark-independent-evaluation/docs/results/benchmark-remediation/attempt-51),3/8 pass on its distinct runtime: loaded/local/protocol. Tests, correctness/citations, gross, uncached and time remain blocking. Gross+17.64%,uncached+27.93%; time interval crosses zero. Trial50 malformed saves/integrity failure and all historical costs remain retained unchanged. No retries/resampling/best-of selection/hash repair or benchmark-specific hints.

Shared weekly baseline5%, latest observed7%, stopping threshold13%, reset2026-10-29 17:17:13UTC. Combined observed increase2points includes workers/subjects/development, conservatively including other account activity. No reset/credits/API billing/account switch. Reporting lag means this is not a hard billing cap. Task remains active; exact checkpoint in RESUME.txt. Native50+51 gross5,088,862;52native0. Next investigate read-before-lock registration on unchanged grants, requiring meaningful demonstrated behavior and review before any new-source comparison.
'''
Path('work/pr-body-52.md').write_text(body,encoding='utf-8')
subprocess.run(['gh','pr','edit','3','--body-file','work/pr-body-52.md'],check=True)
pr=json.loads(subprocess.check_output(['gh','pr','view','3','--json','isDraft,state,mergedAt,autoMergeRequest,headRefOid']))
assert pr['isDraft'] and pr['state']=='OPEN' and pr['mergedAt'] is None and pr['autoMergeRequest'] is None and pr['headRefOid']==sha
print(json.dumps(dict(head=sha,manifest_entries=len(manifest),incomplete=True,all_checks_conservatively_failure=True,pr=pr)))
