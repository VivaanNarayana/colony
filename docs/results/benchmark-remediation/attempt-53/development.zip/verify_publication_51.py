from pathlib import Path
import zipfile,json,hashlib,subprocess
root=Path.cwd();out=root/'docs/results/benchmark-remediation/attempt-51';w=root/'work'
for rel,link in [('docs/benchmark-audit.md','results/benchmark-remediation/attempt-51/README.md'),('docs/results/benchmark-remediation/optional-runtime-removal.md','attempt-51/README.md')]:
 p=root/rel;old=p.read_text(encoding='utf-8');first,rest=old.split('\n',1)
 p.write_text(first+'\n\nLatest: [trial51]('+link+') passes3/8 (loaded,local,protocol); five gates remain blocking. Tests325pass/1fail/1skip; one feature citationinvalid; gross+17.64%,uncached+27.93%,timeCIcrosseszero. Full evidence/failedattempts retained, all8 strictchecksrequired. Shared weekly baseline5%,observed7%,stop13%; active remediation continues, PR3draft/unmerged.\n\n'+rest,encoding='utf-8',newline='\n')
with zipfile.ZipFile(out/'development.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in sorted(w.rglob('*')):
  if f.is_file() and '__pycache__' not in f.parts:z.write(f,f.relative_to(w).as_posix())
with zipfile.ZipFile(out/'development.zip') as z:assert z.testzip() is None
(out/'sha256.json').write_text(json.dumps({f.relative_to(out).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(out.rglob('*')) if f.is_file() and f.name!='sha256.json'},indent=2)+'\n',encoding='utf-8',newline='\n')
assert not subprocess.check_output(['git','diff','4e22ff6891bded2424ad010fd1ea438fcecb30b7','--','scripts',*[f'docs/results/benchmark-remediation/attempt-{i}' for i in range(1,51)]])
print('Historical1-50 and harness unchanged; archive verifies.')
