import json
from pathlib import Path
rr=json.loads(Path('../benchmark-remediation-research-review-51.json').read_text(encoding='utf-8'))
for arm in ['main','feature']:
 ops=[op for r in rr if r['arm']==arm for op in r['ops'] if op['tool']=='push']
 receipts=[json.loads(op['result']['content'][0]['text']) for op in ops]
 print(json.dumps(dict(arm=arm,pushes=len(ops),fingerprints=sum(len(op['arguments']['sources']) for op in ops),stored=sum(r.get('stored')is True for r in receipts),queued=sum(r.get('queued')is True for r in receipts))))
