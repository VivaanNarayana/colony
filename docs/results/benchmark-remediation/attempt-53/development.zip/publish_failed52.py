import hashlib
import json
import shutil
import subprocess
import zipfile
from pathlib import Path

root=Path.cwd(); work=root/'work'; out=root/'docs/results/benchmark-remediation/attempt-52'
assert not out.exists()
out.mkdir()
source='e38923577f3baa10e558a5a89220bd3affcd340f'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==source
assert int((work/'local-52.exit.txt').read_text(encoding='utf-8-sig'))==1
assert not (root.parent/'benchmark-remediation-live-52-results').exists()
def put(name,data):
 (out/name).write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['preflight-52.json','verification-52.json','required-gates-52.json','cli-instruction-source-audit-52.json','independent-review-52.json','usage-budget.json','usage-samples.jsonl','local-52.stdout.txt','local-52.exit.txt','local-52-awake.json','full-52-verified.stdout.txt','full-52-verified.xml','full-52-verified.exit.txt','full-52-verified-awake.json','ruff-52-final.stdout.txt','ruff-52-final.exit.txt']:
 shutil.copyfile(work/name,out/name)
local=root.parent/'benchmark-remediation-local-52-results'
runtime=root.parent/'benchmark-remediation-local-52-runtime'
for name in ['lookup-plan.json','lookup-workload.json']:
 shutil.copyfile(local/name,out/name)
shutil.copyfile(runtime/'main.stderr.txt',out/'main-worker.stderr.txt')
put('outcome.json',dict(trial=52,source=source,baseline='6fa6826aa4c835001c0d2bc8f3bec838499e5b5d',status='Incomplete startup failure; no complete gate verdict',local_invocations=1,local_completed_queries=0,native_invocations=0,native_subject_tokens=0,official_analyzer_invocations=0,gate_verdict=None,all_gates_passed=False,reason='Coordinator omitted explicit verified model-directory environment variables; baseline default cache lacked special_tokens_map.json. Worker failed before ready/query execution.',external_blocker=False,benchmark_retries=0,models_changed=False,known_test_failure=True,tests_passed=339,tests_failed=1,tests_skipped=1,ruff_passed=True,usage=dict(baseline=5,last_observed=7,stop=13,reset=1793294233),all_costs_and_failures_retained=True))
put('code-hashes.json',dict(source=source,sha256={name:hashlib.sha256(subprocess.check_output(['git','show',f'{source}:{name}'])).hexdigest() for name in subprocess.check_output(['git','ls-tree','-r','--name-only',source,'--','src','tests','scripts'],text=True).splitlines()}))
put('retained-development-notes.json',dict(earlier_full52_citation_only=dict(passed=325,failed=1,skipped=1),first_consolidated_suite=dict(passed=334,failed=6,skipped=1,reason='Five wording assertions required conditional reuse updates; same retained wrong-attribute red test.'),initial_lint=dict(command='ruff check .',errors=194,reason='Accidentally included untracked scratch scripts; no autofix applied. Proper tracked project scope src/tests/scripts passes.'),preflight_initial_failure='History anchor initially used initial commit before legitimate50/51 additions; fixed to published51; no benchmark had started.',post51_retrieval_diagnostics='Source-witness, contextual-sentence, parent-child and contextual-child proposals disconfirmed; all exact inputs, outputs and failures in development.zip; none integrated.',cost_note='Native50+51 gross5,088,862 retained;52native0. Development/model usage included in observed shared account delta, not inferred from tokens.'))
readme='''# Trial52 — incomplete local startup failure

Runtime `e38923577f3baa10e558a5a89220bd3affcd340f`, freshly fetched main `6fa6826aa4c835001c0d2bc8f3bec838499e5b5d`. One local invocation failed before ready/query execution: the coordinator omitted the explicit verified embedding/ranking model directory environment variables. The baseline default cache lacks `special_tokens_map.json`. This is an invocation mistake, not an external blocker or a measured runtime regression. All logs, pinned baseline source and partial plans are retained. **Zero completed queries, zero native invocations, zero analyzer invocations; no complete eight-gate verdict.** No identical-runtime retry occurred. Incomplete evidence establishes no passing gates. The latest completed comparison remains trial51,3/8, on its distinct runtime.

The reviewed general changes make reuse-alone versus mixed reuse/research obligations consistent across initialization and both tools, prioritize the existing relative citation rule, avoid rewriting identical membership, share the ask connection with evidence fallback while preserving the answer-stage commit, and stop before rereading files beyond excerpt capacity. These do not change models, scores, relevance cutoffs, source/freshness/scope/authentication/proof rules or benchmark configuration. Server-enforced MCP taint, explicit false, encrypted queue/retry and strict64-character actual-new-read proofs remain covered. No malformed hash is repaired. No native performance benefit is established. Registration still acquires a writer lock; that remaining cost is a separate investigation.

Final-source tests: **339passed, onefailed, oneexisting Windows skip**; Ruff on src/tests/scripts and whitespace pass. The unrelated explanatory login-session answer falsely matching a deletion-permissions question remains a blocking failure. New regressions cover per-request verification, changed/forged/expired grants, duplicate-scope rollback and concurrent membership snapshots; one-connection fallback, standalone evidence compatibility and exception commit boundaries; selected-source freshness/redaction and unused reread avoidance; consistent mixed reuse/research guidance. An earlier consolidated suite failed five outdated wording assertions plus the same real retrieval failure; exact results retained. Scripted contracts do not prove model adherence. Independent AstraHigh review found no blocking issue; concurrency coverage is sampled and no contention/time benefit is inferred.

The matching-version CLI source audit finds a **512KiB namespace-description cap, not512characters**. The official recommendation to prioritize important content within512characters is not proof of client truncation. Regular MCP instructions are expected to pass into namespace metadata in the matching upstream version. Installed-binary reproducibility and actual per-request payloads remain unverified; instruction-order and receipt causality remain unproved. See cli-instruction-source-audit-52.json for immutable primary links and limitations. Historical reports are not rewritten.

Further fixed-model retrieval proposals were rejected by unrelated controls: source-witness metadata could outscore actual facts; contextual sentence checks rejected genuine composed answers and admitted a permission false hit; parent-child scoring produced no new true admissions; contextual child scoring did not rescue either retained target and its broader phase was not run. These are diagnostics, not benchmark passes or a proof that every fixed-model approach is impossible. All models remain unchanged per user instruction.

Weekly baseline5%, observed7%, stopping threshold13%; task remains active with2observed points consumed. Reset2026-10-29 17:17:13UTC does not renew the task allowance. Native50+51 cost5,088,862gross tokens plus all development work remains counted;52 has no native subject tokens. Reporting lag/coarse percentages prevent treating this as a hard billing cap. No credits/reset/API billing/account switching was used. All3 workers were idle during the failed measurement. Wake request released; no persistent power change. All eight original strict ruleset25440133 checks remain required with no bypass/main exemption. PR3 remains draft/unmerged/noauto-merge.

Exact original scratch evidence is in development.zip; incomplete local results, stderr, workload and exported baseline Python sources are in local-incomplete.zip. Private database/identity/queue material is excluded. ZIP member integrity is checked, not an offline benchmark replay. Public text uses canonicalLF; archives retain original bytes. sha256.json covers every other published file. Attempts1–51 and all harness files remain unchanged. Next checkpoint: investigate a consistent read before no-op registration so unchanged grants can avoid a writer lock; do not retry52 or weaken/remove the red retrieval test.
'''
(out/'README.md').write_text(readme,encoding='utf-8',newline='\n')
with zipfile.ZipFile(out/'development.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for file in sorted(work.rglob('*')):
  if file.is_file() and '__pycache__' not in file.parts:z.write(file,file.relative_to(work).as_posix())
with zipfile.ZipFile(out/'local-incomplete.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for file in sorted(local.rglob('*')):
  if file.is_file():z.write(file,'results/'+file.relative_to(local).as_posix())
 for file in sorted((runtime/'main-source').rglob('*.py')):z.write(file,'main-source/'+file.relative_to(runtime/'main-source').as_posix())
 for name in ['workload.json','main.stderr.txt']:z.write(runtime/name,name)
for archive in ['development.zip','local-incomplete.zip']:
 with zipfile.ZipFile(out/archive) as z:assert z.testzip() is None
for file in out.rglob('*'):
 if file.is_file() and file.suffix in {'.json','.jsonl','.txt','.md','.xml'}:file.write_text(file.read_text(encoding='utf-8-sig'),encoding='utf-8',newline='\n')
put('sha256.json',{f.relative_to(out).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(out.rglob('*')) if f.is_file() and f.name!='sha256.json'})
assert not subprocess.check_output(['git','diff','c75736bbaad9fe39e5aea39ca9d61f85f2719e06','--','scripts',*[f'docs/results/benchmark-remediation/attempt-{i}' for i in range(1,52)]])
resume=root/'docs/results/benchmark-remediation/RESUME.txt'
old=resume.read_text(encoding='utf-8')
resume.write_text('''ACTIVE BUDGETED REMEDIATION — TRIAL52 INCOMPLETE STARTUP CHECKPOINT.
Baseline5%, latest7%, STOP13%; reset1793294233. Read reliable usage before furtherwork.
All retrieval models remain unchanged. PR3draft/unmerged/noautomerge, all8strictrequired.
Runtimee38923577f3baa10e558a5a89220bd3affcd340f; main6fa6826aa4c835001c0d2bc8f3bec838499e5b5d.
Read attempt-52/README.md/outcome.json/verification-52.json/independent-review-52.json
and cli-instruction-source-audit-52.json. MatchingCLI cap512KiB, NOT512characters.
One localinvocationfailed BEFOREqueries because coordinatoromittedexplicitverified
modeldirectoryenvironmentvariables; defaultcachemissingspecial_tokens_map.json.
No native52/analyzer52 invocation, NOeight-gateverdict, NOidentical-runtime retry.
Keep52incomplete; incompleteevidencecannotestablishpasses. Latestcomplete51=3/8.
Finalsuite339pass/1fail/1existingWindows skip; Ruff/whitespacepass. Wrong-attribute
sessionexpiry/deletionpermission redtest retained. Allproof/taint/queue/scope/freshness
unchanged. Conditionalmixedresearch/reuse andsafeI/Ochangesreviewed, benefitunmeasured.
Source-witness/contextualsentence/parent-child/contextual-child diagnostics REJECTED,
notpending: no demonstrated safe admission repair. Exactinputs/resultsretained52archive.
NEXT: consistentmemberLEFTJOINscope snapshot before no-opregister; returnunchanged
withoutwriterlock, elseBEGINIMMEDIATE recheckandrefreshatomically. Independentreview
and lock/authorization tests before consideringmeaningfulnewruntime comparison.
Do not benchmark52again; use explicit verified modelenv in ALLfuturetest/benchmarkcalls.
All3workersused/no nesting; coordinatoralone commits/push/PR/checks/fullbenchmarks.
Tasknative50+51gross5088862;52native0. Allcostsretained; allowanceNOTrenewedonreset.
Taskunfinished/active; no automation. Earliercheckpoints below preservedhistory.

'''+old,encoding='utf-8',newline='\n')
index=root/'docs/results/benchmark-remediation/README.md'
old=index.read_text(encoding='utf-8'); first,rest=old.split('\n',1)
index.write_text(first+'\n\nLatest [trial52](attempt-52/README.md) is an incomplete startup failure, not a gate verdict. No retry/native/analyzer. Final339pass/1fail/1skip; latest completed51remains3/8 on differentcode. Sharedbaseline5%,observed7%,stop13%; active, all models frozen, PR3draft.\n\n'+rest,encoding='utf-8',newline='\n')
print('Published incomplete52 evidence; no passing gates claimed.')
