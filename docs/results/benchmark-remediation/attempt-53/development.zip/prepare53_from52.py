from pathlib import Path
import subprocess

source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
p=Path('work/prepare_52.py').read_text(encoding='utf-8')
p=p.replace('e38923577f3baa10e558a5a89220bd3affcd340f',source)
p=p.replace('c75736bbaad9fe39e5aea39ca9d61f85f2719e06','cb5620ae647387530374cf5ca77f90a0abeb3f2a')
p=p.replace('-52','-53').replace('trial=52','trial=53').replace('range(1,52)','range(1,53)')
p=p.replace('full-53-verified.xml','full-53.xml').replace("a['tests']==341","a['tests']==342").replace('tests_passed=339','tests_passed=340')
p=p.replace('last_observed=7','last_observed=8')
p=p.replace("'Stop before rereading unselected excerpts beyond capacity']","'Stop before rereading unselected excerpts beyond capacity','Read complete atomic membership snapshot before reserving writer slot; demonstrated contention failure before and pass after']")
p=p.replace('import hashlib,json,platform,subprocess,sys,xml.etree.ElementTree as ET','import hashlib,json,os,platform,subprocess,sys,xml.etree.ElementTree as ET')
p=p.replace('for role,info in modelinfo.items():',"assert Path(os.environ['COLONY_EMBED_MODEL_DIR']).resolve()==(modelroot/'embed').resolve()\nassert Path(os.environ['COLONY_RANK_MODEL_DIR']).resolve()==(modelroot/'rank').resolve()\nfor role,info in modelinfo.items():")
Path('work/prepare_53.py').write_text(p,encoding='utf-8')
print(source)
