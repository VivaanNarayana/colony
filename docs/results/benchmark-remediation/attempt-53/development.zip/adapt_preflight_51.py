from pathlib import Path
s=Path('work/prepare_50.py').read_text(encoding='utf-8-sig')
s=s.replace('full-50-final.xml','full-51.xml').replace('d5a8669a0f354a33bbdaca470c6f26fab230eacf','8604fc883fc4f8a85cb58d6420713d1c18c6966e')
s=s.replace("a['tests']==324","a['tests']==327").replace('tests_passed=322','tests_passed=325')
s=s.replace('-50-','-51-').replace('-50.','-51.').replace('trial=50','trial=51')
s=s.replace("['4000-character answer support boundary consistency','conditional research-save policy ordering and receipt confirmation']","['Frontloaded complete64-character new-read proof copying and no identical rejected resubmission']")
Path('work/prepare_51.py').write_text(s,encoding='utf-8')
