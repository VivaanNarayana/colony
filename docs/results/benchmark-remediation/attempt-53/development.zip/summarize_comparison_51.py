from pathlib import Path
import json
c=json.loads(Path('../benchmark-remediation-live-51-results/comparison.json').read_text(encoding='utf-8'))
print(json.dumps({k:c[k] for k in ['arms','observed_reductions','descriptive_family_bootstrap_reduction_95pct','gate','blocking_gates']},indent=2))
