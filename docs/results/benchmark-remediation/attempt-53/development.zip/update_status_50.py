import json,hashlib,subprocess
from pathlib import Path
out='docs/results/benchmark-remediation/attempt-50'
manifest=json.loads(subprocess.check_output(['git','show',f'HEAD:{out}/sha256.json']))
for n,h in manifest.items():assert hashlib.sha256(subprocess.check_output(['git','show',f'HEAD:{out}/{n}'])).hexdigest()==h,n
rules=json.loads(subprocess.check_output(['gh','api','repos/VivaanNarayana/colony/rulesets/25440133']))
required=next(r['parameters'] for r in rules['rules'] if r['type']=='required_status_checks')
assert len(required['required_status_checks'])==8 and required['strict_required_status_checks_policy'] and not rules['bypass_actors']
sha=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
for c in required['required_status_checks']:
 data=dict(state='failure',context=c['context'],description='Trial50 evidence integrity failed; no complete eight-gate verdict',target_url='https://github.com/VivaanNarayana/colony/blob/'+sha+'/'+out+'/README.md')
 payload=Path('work/status-50.json');payload.write_text(json.dumps(data),encoding='utf-8')
 subprocess.run(['gh','api',f'repos/VivaanNarayana/colony/statuses/{sha}','--input',str(payload)],check=True,stdout=subprocess.DEVNULL)
print(json.dumps(dict(public_manifest_verified=len(manifest),strict_checks=8,statuses='all failure; integrity failure retained',head=sha)))
