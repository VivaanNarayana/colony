from pathlib import Path
s=Path('work/compact_trace_50_final.py').read_text(encoding='utf-8-sig').replace('-50.','-51.')
Path('work/compact_trace_51.py').write_text(s,encoding='utf-8')
