import asyncio,json
from pathlib import Path
from types import SimpleNamespace
import colony.mcp

root=Path('work/policy-80');root.mkdir(exist_ok=True)
packets={
 'miss':{'hit':False},
 'stale':{'hit':True,'status':'stale','tainted':True,'content':'Old retention: 19 days.','sources':[]},
 'sufficient':{'hit':True,'match_kind':'answer','status':'validated','tainted':True,'namespace':'ops','content':'Archives expire after 23 days only after export approval.','sources':[{'ref':'policy.md','content_hash':'a'*64}],'evidence':[{'ref':'policy.md','line':3,'text':'Archives expire after 23 days only after export approval.'}]},
 'incomplete':{'hit':True,'match_kind':'evidence','status':'validated','sources':[{'ref':'guide.md','content_hash':'b'*64}],'evidence':[{'ref':'guide.md','line':5,'text':'Archive management metadata.'}]},
}
def snapshot():
 out={}
 for name,packet in packets.items():
  colony.mcp.Client=lambda home:SimpleNamespace(ask=lambda *a,**k:packet)
  server=colony.mcp.create_mcp(Path('.'))
  out[name]=json.loads(server._tool_manager.get_tool('ask').fn('When do records expire?','ops')[0].text)
 tools=asyncio.run(server.list_tools())
 return {'instructions':server.instructions,'tools':[t.model_dump(mode='json') for t in tools],'packets':out}
if __name__=='__main__':
 import sys
 label=sys.argv[1];path=root/(label+'.json');assert not path.exists()
 result=snapshot();path.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
 print(json.dumps({'label':label,'initialization_bytes':len(result['instructions'].encode()),'tools_json_bytes':len(json.dumps(result['tools'],ensure_ascii=False,separators=(',',':')).encode())}))
