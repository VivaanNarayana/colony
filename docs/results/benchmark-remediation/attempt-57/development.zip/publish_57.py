import hashlib,json,shutil,subprocess,zipfile
from datetime import datetime,timezone
from pathlib import Path
root=Path.cwd();w=root/'work';parent=root.parent;base=root/'docs/results/benchmark-remediation';out=base/'attempt-57';assert not out.exists();out.mkdir()
source='ba77687804a7d7a49b182c75fc2e50995ef50e45';baseline='6fa6826aa4c835001c0d2bc8f3bec838499e5b5d';assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==source
live=parent/'benchmark-remediation-live-57-results';runtime=parent/'benchmark-remediation-live-57-runtime';local=parent/'benchmark-remediation-local-57-results';r=json.loads((live/'comparison.json').read_text(encoding='utf-8'));assert sum(r['gate'].values())==3 and r['data_budget_verified'];assert int((w/'analyzer-57.exit.txt').read_text(encoding='utf-8-sig'))==1;assert not subprocess.check_output(['git','diff','6e0a4e1','--','scripts',*[str(Path('docs/results/benchmark-remediation')/f'attempt-{n}') for n in range(1,57)]])
def cp(p,n):
 d=out/n;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,d)
def put(n,x):(out/n).write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
for arm in ['main','feature']:
 for n in ['raw-measurements.jsonl','loaded-implementations.json','metadata.json','corpus-sha256.json','reviews.json']:cp(live/arm/n,arm+'/'+n)
for n in ['comparison.json','completed.json','protocol.json','model-policy-failures.jsonl']:cp(live/n,n)
cp(live/'review-mapping.json','review-records.json')
for n in ['manual-review','frozen-labels','verification','preflight','required-gates']:cp(w/f'{n}-57.json',n+'.json')
for n in ['tool-audit','research-review']:cp(parent/f'benchmark-remediation-{n}-57.json',n+'.json')
cp(w/'review-native57.json','selected-native-review.json');cp(w/'review77.json','implementation-review.json');cp(base/'budget-allowance-4.json','usage-budget.json');cp(w/'local-raw-audit-57.json','local-raw-audit.json')
for p in local.iterdir():
 if p.is_file():cp(p,p.name)
for n in ['local-57.stdout.txt','local-57.exit.txt','live-57.stdout.txt','live-57.exit.txt','analyzer-57.stdout.txt','analyzer-57.stderr.txt','analyzer-57.exit.txt','wake-local-57.json','wake-live-57.json']:cp(w/n,n)
for n in ['full.txt','full.xml','before.txt','before.xml','focused.txt','focused.xml','ruff-full.txt']:cp(w/'full-literal-77'/n,'tests-'+n)
assert all(json.loads((w/f'wake-{k}-57.json').read_text(encoding='utf-8'))['request_released'] for k in ['local','live'])
prev=json.loads((base/'attempt-56/comparison.json').read_text(encoding='utf-8'));gross=sum(a['tokens'] for a in r['arms'].values());assert gross==2411931
put('raw-totals.json',{'all48_sessions_included':True,'totals':r['arms']});put('outcome.json',{'trial':57,'source':source,'baseline':baseline,'gates_passed':3,'gates_total':8,'gate_statuses':{'benchmarks/'+k:'success' if v else 'failure' for k,v in r['gate'].items()},'blocking_gates':r['blocking_gates'],'gate_changes_from56':[k for k,v in r['gate'].items() if v!=prev['gate'][k]],'official_analyzer_invocations':1,'local_invocations':1,'native_invocations':1,'native_sessions_completed':48,'native_gross_tokens':gross,'cumulative_native50_through57_gross':15497907+gross,'all_outcomes_costs_retained':True,'benchmark_or_session_restarts':0,'proof_repair':False,'all_gates_passed':False,'current_complete_eight_gate_verdict_available':True,'tests_passed':424,'tests_failed':1,'tests_skipped':1,'ruff_passed':True,'usage':{'allowance':4,'baseline':20,'continuation_start_observed':21,'last_observed':23,'stop':25,'reset':1793382050,'shared':True,'reporting_may_lag':True},'all_models_harness_and_gates_unchanged':True,'causal_limit':'Current feature versus main is cumulative feature difference; saved wording/sampling/cache vary. No isolated native benefit of lexical-bypass patch77 established. Independent regression mechanism is narrower.','next_mechanism':'Wrong tool-name final answer after metadata-only hit makes general source-context completeness/answer support the highest-priority failure. Do not weaken lexical guards or reuse rejected candidate tuning.','published_utc':datetime.now(timezone.utc).isoformat()})
put('code-hashes.json',{'source':source,'sha256':{n:hashlib.sha256(subprocess.check_output(['git','show',f'{source}:{n}'])).hexdigest() for n in subprocess.check_output(['git','ls-tree','-r','--name-only',source,'--','src','scripts','tests'],text=True).splitlines()}})
rows='\n'.join(f"|{k}|{r['arms']['main'][k]:,.3f}|{r['arms']['feature'][k]:,.3f}|" for k in ['tokens','uncached_input_plus_output','seconds','research_calls','tool_calls'])
(out/'README.md').write_text(f'''# Trial57: 3/8 unchanged strict gates; feature metadata answer fails

Measured **{source}** versus freshly fetched main **{baseline}**. One fresh local comparison, all48native sessions and one unchanged official analyzer invocation after frozen labels. Every session, failure, attempted save and cost is retained. No identical-code retry, selective resampling, proof repair or main exemption.

The reviewed [lexical-bypass fix77](../investigation-77/README.md) requires complete local word coverage to skip the existing semantic answer-support guard. Its reproduced access/fertilizer false hit becomes a miss without losing tested sufficient controls. It does not fix the older expiry/deletion failure. This comparison measures the cumulative feature versus main; generated saved wording, cache and provider sampling vary. **No isolated native benefit of patch77 is established.**

Pass: loaded implementations, local lookup, live time. Fail: tests/lint, correctness, protocol, gross tokens, uncached tokens. No gate changes from complete56; both pass3/8. Feature time11.98%lower,95%reductionCI+3.42%to+19.69%. Gross5.99%higher,CI−13.36%to+1.11%crosseszero. Uncached32.35%higher,CI−61.36%to−12.49%is strictly worse. Confidence requirements unchanged.

|Metric|Main|Feature|
|---|---:|---:|
{rows}

Local117/117each; unchanged raw audit verifies234observations. Warm lookup29.1052%lower,95%reductionCI+20.1161%to+39.0896%. Setup/push/coldstart/concurrency excluded. Repeated public-development comparisons are not independent production confirmation. Premeasurement full suite424passed/1knownwrong-attribute failure/1existingWindows skip; Ruff/whitespace pass. The red test is retained without waiver.

Coordinator reviewed all48answers/49ask packets(25unique) and13research/save traces. All41displayed current contexts match exact frozen bytes, hashes, original lines and scrubbed prefixes. Core facts24/24main versus23/24feature. Citations19/24main,23/24feature. Selected independent nonblind SolHigh review reconciledR14/R21/R29after labels froze; it is not independent blind grading of48. All frozen label hashes remain unchanged.

FeatureR21/mcp2receives README96wrapper metadata and answers with metadata, omitting required ask/push tool names. The packet is irrelevant and the final core answer wrong. It performs no missing-fact research/save, so it also violates protocol. FeatureR14/stale2asks twice with identical sufficient validated packets, retaining both calls/costs. FeatureR25/outage2now reuses a sufficient saved answer and actual READMEqueue evidence without research/push. MainR31/capture1asks once in57; its prior56duplicate remains retained historically. Main protocol0, feature2. These differences do not isolate patch effects.

R29's named README heading exists. The unchanged numeric-fragment oracle rejects its citation. The helper's extra missing-target diagnostic comes from parser error handling and does not establish a missing file or fabricated provenance. All five invalid main citations remain invalid, and bare-file references retain the original acceptance rule.

All13pushes/15fingerprints match actual preceding new reads and frozen source bytes; all receipts report stored/queued. Main1storedreceipt/5queuedreceipts, finalDB6rows/5queueitems (lost responses can leave both durable rows and queued entries). Feature7storedreceipts/7rows/noqueue. All actual57taints are true, including main; historical56mainexplicitfalse finding remains immutable. Explicitfalse/offline feature enforcement remains test coverage, not exercised by57. Auth/scope/freshness, strict fingerprints and encrypted retry are unchanged.

Nativegross2,411,931; cumulative50/51/53/54/55/56/57gross17,909,838,52native0; earlier costs remain separately retained. Shared allowance4 baseline20%, continuation first observed21%, latest23%, stop25%, reset2026-10-30 17:40:50UTC. One combined allowance includes every coordinator/worker/subject/review and unrelated account increase; previous remainder is not added. Reporting may lag. Noreset/credit/account/APIbilling bypass. Both workers idle; no benchmark active.

Models/weights/revisions, gpt-6-luna/low subjects, harness/config/workload/order/prompts/rubrics/oracles/confidence/relevance/context/research/token/time budgets and all eight active strict ruleset25440133checks/no bypass remain unchanged. PR3 stays draft/unmerged/noauto. Exact events/prompts/answers/labels, pinned implementations/corpus/proofs are in live-native.zip; development.zip retains audit/preflight/label scripts and review. Private databases/identity/queue/storage keys are excluded. Public text is normalizedLF; ZIP entries preserve original bytes and frozen label hashes. Archives/manifests verified; no offline analyzer replay claimed. Wake requests released. No further identical-runtime comparison is authorized.

The next measured priority is a general source-context/answer-support repair for the metadata-only wrong answer, with unrelated qualification/dependency controls. Known red retrieval, sufficient misses and all failing gates remain. Continue only within the same shared allowance; at25stop new model work, preserve every partial outcome and update [RESUME](../RESUME.txt)/PR. This branch remains unfinished.
''',encoding='utf-8',newline='\n')
with zipfile.ZipFile(out/'live-native.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(live.rglob('*')):
  if p.is_file():z.write(p,'results/'+p.relative_to(live).as_posix())
 for arm,folder in [('main','main'),('feature','feat')]:
  for p in sorted((runtime/'implementation'/arm).rglob('*.py')):z.write(p,'implementation/'+arm+'/'+p.relative_to(runtime/'implementation'/arm).as_posix())
  for p in sorted((runtime/folder/'repo').rglob('*')):
   if p.is_file():z.write(p,'corpus/'+arm+'/'+p.relative_to(runtime/folder/'repo').as_posix())
with zipfile.ZipFile(out/'development.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n in ['prepare57.py','prepare_review57.py','inspect_57.py','freeze_labels_57.py','preflight-57.stdout.txt','review-prep-57.txt','tool-audit-57.stdout.txt','manual-review-57.json','review-native57.json','review77.json','local-raw-audit-57.json','usage-allowance4.jsonl']:z.write(w/n,n)
 z.write(w/'publish_57.py','publish_57.py')
for n in ['live-native.zip','development.zip']:
 with zipfile.ZipFile(out/n) as z:
  assert z.testzip() is None;assert not any(n.endswith(('.db','.key','.pem','.enc')) or 'identity.json' in n for n in z.namelist())
for p in out.rglob('*'):
 if p.is_file() and p.suffix in {'.json','.jsonl','.txt','.md','.xml'}:p.write_bytes(p.read_bytes().replace(b'\r\n',b'\n'))
frozen=json.loads((w/'frozen-labels-57.json').read_text(encoding='utf-8'))['labels_sha256'];put('label-hash-scopes.json',{'original_zip_hashes':frozen,'public_LF_hashes':{a+'/reviews.json':hashlib.sha256((out/a/'reviews.json').read_bytes()).hexdigest() for a in ['main','feature']}})
put('sha256.json',{p.relative_to(out).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(out.rglob('*')) if p.is_file() and p.name!='sha256.json'})
resume=base/'RESUME.txt';header=f'''TRIAL57 COMPLETE — SAME3/8STRICTGATES; TASK UNFINISHED.
Sameallowance4 baseline20%used, latest23%, STOP25%; +3observedpoints; lagpossible.
Reset2026-10-30 17:40:50UTC. Allpriorcosts/outcomes/remainder separatelyretained.
Measured {source}, freshmain{baseline}; no runtimechangesaftermeasurement.
Read attempt57 README/comparison/manual-review/research-review/tool-audit/outcome.
Onefreshlocal234rows +complete48native+officialanalyzeronce, alloutcomesretained.
PASS loaded/local/time; FAIL tests/correctness/protocol/gross/uncached; no gatechangesfrom56.
Time11.98%lowerCI+3.42to+19.69; gross5.99%higherCIcross0; uncached32.35%higherCIworse.
Core24main/23feature; citations19main/23feature. R21metadataanswer omitsask/push names,
no missingfactresearch/save. FeatureR14two identicalsufficientasks. Mainprotocol0/feature2.
R29realheadinganchorinvalid underunchangedoracle; helpermissingtargetdiagnosticmisleading.
All13pushes/15hashesactualprecedingnewreads; main1stored/5queuedreceipts,DB6rows5queue;
feature7stored/7rows0queue; allactual57taintsTrue. Historical56false-taintfindingretained.
424pass1knownexpiry-deletionfailure1Windows skip; Ruffpass. Lexical77regressionfixedonly.
No isolatednativebenefit: sourcecorpusfrozenmain, generatedwording/cache/samplingvary.
Nativegross57=2,411,931; cumulative50through57=17,909,838;52native0/earliercostsretained.
All48coordinatorreviewed/49packets/41sourcecontexts; selectedSolreview3recordsnonblindagrees.
Bothworkersidle;2totalused, no nesteddelegation; no activebenchmark. PR3draft/unmerged/noauto.
Next: distinct general sourcecontext/answer-supportfix forwrongmetadataanswer withgoverning
qualifications/dependenciescontrols. No rejectedcandidateretuning/unsafecompaction/hints.
Nextnative58 onlyaftermeaningfulreviewedruntimechange/tests, freshmain/freshdirectories;
neverretryidenticalsource. Allmodels/harness/gates/oracles/budgets/taint/proofs/scopeunchanged.
At25stopnewphases/workers/benchmark, preservepartialcosts, updatecheckpoint andstopunfinished.

''';resume.write_bytes(header.encode('utf-8')+resume.read_bytes())
print(json.dumps({'trial':57,'passed':3,'native_gross':gross,'archive_bytes':(out/'live-native.zip').stat().st_size,'public_files':len([p for p in out.rglob('*') if p.is_file()])}))
