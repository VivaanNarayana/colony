import json, time
from pathlib import Path
import pytest
import colony.retrieval as r
import colony.store as s
cost = {'embedding_items':0,'ce_pairs':0,'embed_invocations':0,'rank_invocations':0,'embed_passages_invocations':0}
def wrap_embed(original):
    def f(*args, **kwargs):
        cost['embedding_items'] += 1
        cost['embed_invocations'] += 1
        return original(*args, **kwargs)
    return f
def wrap_rank(original):
    def f(query, passages):
        cost['ce_pairs'] += len(dict.fromkeys(passages))
        cost['rank_invocations'] += 1
        return original(query, passages)
    return f
def wrap_passages(original):
    def f(texts):
        cost['embedding_items'] += len(texts)
        cost['embed_passages_invocations'] += 1
        return original(texts)
    return f
r.embed = s.embed = wrap_embed(r.embed)
r.rank = s.rank = wrap_rank(r.rank)
r.embed_passages = s.embed_passages = wrap_passages(r.embed_passages)
started=time.perf_counter()
code=pytest.main(['-q','-s','tests/test_saved_wording_regression.py','-k','explanatory and login'])
print('AUDIT_COST '+json.dumps({**cost,'elapsed_seconds':time.perf_counter()-started,'pytest_exit':code,'provider_calls':0,'subject_calls':0},sort_keys=True))
raise SystemExit(code)
