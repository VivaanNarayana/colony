import json, sqlite3, re, time
import sqlite_vec
from colony import retrieval as r
started=time.perf_counter()
query='Does a login session permit deleting other users?'
saved='What is the lifetime of a login session?'
content='After thirty minutes, the login session expires. Users must authenticate again before continuing. The expiry interval applies to each newly created session.'
counts={'embedding_items':0,'ce_pairs':0,'provider_calls':0,'subject_calls':0}
def embed(text,query=False):
    counts['embedding_items']+=1
    assert counts['embedding_items']<=6
    return r.embed(text,query=query)
def rank(query,texts):
    counts['ce_pairs']+=len(dict.fromkeys(texts))
    assert counts['ce_pairs']<=12
    return r.rank(query,texts)
q=embed(query,True)
a=embed(r.passage(saved,content))
sq=embed(saved,True)
with sqlite3.connect(':memory:') as db:
    db.enable_load_extension(True)
    sqlite_vec.load(db)
    ad,qd=db.execute('SELECT vec_distance_cosine(?,?),vec_distance_cosine(?,?)',(q,a,q,sq)).fetchone()
answer,control=rank(query,[content,saved])
similarity=1-min(ad,qd)
qt=r.terms(query)
sentences=re.split(r'(?<=[.!?])\s+',content)
windows=[{'text':' '.join(sentences[i:i+2]),'shared_terms':sorted(qt & r.terms(' '.join(sentences[i:i+2])))} for i in range(len(sentences))]
result={'question':query,'saved_question':saved,'content':content,'query_terms':sorted(qt),'two_sentence_windows':windows,'requires_procedure':r.requires_procedure(query),'exact_question':query.strip().casefold()==saved.strip().casefold(),'answer_passage_similarity':1-ad,'question_similarity':1-qd,'selected_similarity':similarity,'dense_eligibility':similarity>=0.55 and 1-qd>=0.65,'literal_support':r.local_term_support(qt,content[:4000]),'needs_semantic_support':not r.local_term_support(qt,content[:4000]),'answer_logit':answer,'question_control_logit':control,'contrastive_eligible':answer>max(0,control),'relevance':r.fused_score(similarity,answer),'threshold':0.60,'threshold_eligible':r.fused_score(similarity,answer)>=0.60,'counts':counts,'elapsed_seconds':time.perf_counter()-started,'limitation':'Static admission-gate trace only; live proof/excerpt and early return verified by focused pytest reproduction.'}
print(json.dumps(result,indent=2,sort_keys=True))
