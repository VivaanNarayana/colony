import json,hashlib,runpy
from pathlib import Path
O=Path('work/paragraph-completion-72')
# Preserve initial fixtures/results verbatim. Load definitions without executing the diagnostic.
ns={}; src=(O/'diagnostic.py').read_text(encoding='utf-8-sig'); exec(src[:src.index('inputs=')],ns)
complete=ns['complete'];context_window=ns['context_window']
old=json.loads((O/'inputs.json').read_text());cases=[]
for c in old['fresh_cases']:
 x=dict(c);x['source']='\n'.join(f'# preceding diagnostic line {i}' for i in range(40))+'\n\n'+x['source']+'\n'+('\n# following independent section\n'+'# padding\n'*40);x['selected_line']=43;cases.append(x)
raw=(json.dumps({'note':'Initial fixtures did not all exercise a bounded mid-file window; these corrected geometries preserve the same candidate unchanged. Initial inputs/results remain. No model selection or tuning.','cases':cases},indent=2)+'\n').encode();(O/'geometry-controls.json').write_bytes(raw)
(O/'geometry-manifest.json').write_text(json.dumps({'inputs_sha256':hashlib.sha256(raw).hexdigest(),'candidate_script_sha256':hashlib.sha256((O/'diagnostic.py').read_bytes()).hexdigest(),'frozen_before_execution':True},indent=2)+'\n')
rows=[]
for c in cases:
 lines=c['source'].splitlines();start,text=context_window('guide.py',lines,c['selected_line'],c['span']);before=[{'ref':'guide.py','line':start,'text':text}];after=complete(lines,before);rows.append({'name':c['name'],'baseline':before,'candidate':after,'missing_before':[m for m in c['required'] if m not in text],'missing_after':[m for m in c['required'] if m not in after[0]['text']],'baseline_preserved':after[0]['text'].startswith(text),'caps':len(after[0]['text'])<=2400})
(O/'geometry-results.json').write_text(json.dumps({'rows':rows,'note':'Only a boundary mechanism diagnostic. A separate dependency remains absent and oversized paragraph is skipped; no safety or runtime benefit established.','CE_pairs':0,'embeddings':0,'providers':0},indent=2)+'\n')
print(json.dumps([{k:v for k,v in x.items() if k not in ['baseline','candidate']} for x in rows],indent=2))
