"""One frozen boundary diagnostic; no production edits, models, or Store admission."""
import hashlib,json
from pathlib import Path
from colony.context import context_window
O=Path('work/paragraph-completion-72')
# Candidate is one additive pass after all baseline selections, so it cannot evict a second excerpt.
# Complete only a partially shown last paragraph, when the full added text fits both existing caps.
def complete(lines,items):
 out=[dict(x) for x in items]; spare=2800-sum(len(x['text']) for x in out)
 for item in out:
  end=item['line']-1+len(item['text'].splitlines())
  if not item['text'] or end>=len(lines) or not lines[end-1].strip() or not lines[end].strip():continue
  high=end
  while high<len(lines) and lines[high].strip():high+=1
  addition='\n'+'\n'.join(lines[end:high])
  if len(item['text'])+len(addition)<=2400 and len(addition)<=spare:
   item['text']+=addition;spare-=len(addition)
 return out
inputs={'candidate':'After preserving every baseline excerpt, finish its trailing nonblank paragraph only if the whole addition fits unused 2400-per-excerpt/2800-total caps. No reranking, start changes, new files, or truncation.','reject_if':'Standalone correction fails to resolve relevant selection or governing dependencies; no production integration based on substring recovery alone.','fresh_cases':[]}
for name,after,required in [
 ('journal-write','    persist_journal(entry)\n    return {"durable": True}',['persist_journal(entry)','"durable": True']),
 ('long-condition','    if legal_hold:\n        return "suspended"',['legal_hold','"suspended"']),
 ('separate-dependency','\nPolicy prerequisites are defined by require_review in authorization.py.',['require_review']),
 ('oversize-paragraph','    '+('opaque '*500)+'\n    return "committed"',['"committed"'])]:
 source='def update(entry):\n'+''.join(f'    stage_{i} = entry\n' for i in range(1,23))+after+'\n\ndef inspect():\n    return "metadata"\n'
 inputs['fresh_cases'].append({'name':name,'source':source,'selected_line':1,'span':16,'required':required})
b=(json.dumps(inputs,indent=2)+'\n').encode();(O/'inputs.json').write_bytes(b)
(O/'manifest.json').write_text(json.dumps({'inputs_sha256':hashlib.sha256(b).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'context_sha256':hashlib.sha256(Path('src/colony/context.py').read_bytes()).hexdigest(),'frozen_before_execution':True},indent=2)+'\n')
rows=[]
for c in inputs['fresh_cases']:
 lines=c['source'].splitlines();start,text=context_window('guide.py',lines,c['selected_line'],c['span']);baseline=[{'ref':'guide.py','line':start,'text':text}];candidate=complete(lines,baseline)
 rows.append({'name':c['name'],'baseline':baseline,'candidate':candidate,'missing_before':[m for m in c['required'] if m not in text],'missing_after':[m for m in c['required'] if m not in candidate[0]['text']],'baseline_preserved':all(a['line']==z['line'] and z['text'].startswith(a['text']) for a,z in zip(baseline,candidate)),'caps':sum(len(x['text']) for x in candidate)<=2800 and all(len(x['text'])<=2400 for x in candidate)})
# Retrospective outputs are explanatory, not independent controls or a new model selection run.
old=json.loads(Path('work/query-only-context-68/inputs.json').read_text());results=json.loads(Path('work/query-only-context-68/results.json').read_text())
c=next(x for x in old['rows'] if x['name']=='R25-motivating-nonindependent');r=next(x for x in results['rows'] if x['name']==c['name'])
for mode in ['current','query-only']:
 before=r['outputs'][mode];after=complete(c['source'].splitlines(),before)
 rows.append({'name':'R25-retrospective-'+mode,'baseline':before,'candidate':after,'queue_write_before':any('private_write(path, encrypted)' in x['text'] for x in before),'queue_write_after':any('private_write(path, encrypted)' in x['text'] for x in after),'queued_return_after':any('"queued": True' in x['text'] for x in after),'baseline_preserved':all(a['line']==z['line'] and z['text'].startswith(a['text']) for a,z in zip(before,after)),'caps':sum(len(x['text']) for x in after)<=2800 and all(len(x['text'])<=2400 for x in after)})
out={'rows':rows,'embeddings':0,'CE_pairs':0,'provider_calls':0,'subject_calls':0,'production_changes':False,'verdict':'Do not integrate as proposed quality/protocol fix. Additive paragraph completion repairs a cutoff if the relevant paragraph was already selected, but current R25 selection remains ask and omits the queue write. Separate dependency remains absent. Query-only plus this extension is an untested combined candidate, not validated by retrospective substring recovery; prior parent/decorator qualification risks remain.'}
(O/'results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps([{k:v for k,v in x.items() if k not in ['baseline','candidate']} for x in rows],indent=2))
