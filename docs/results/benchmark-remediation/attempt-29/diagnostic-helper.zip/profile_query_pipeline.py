"""Independent interleaved query/reranker execution profile, not gate evidence."""
import gc
import json
import os
import statistics
import time
from pathlib import Path
import numpy as np
from colony.retrieval import TextEmbedding,TextCrossEncoder,EMBED_MODEL,EMBED_REVISION,RANK_MODEL,RANK_REVISION

cases=[
 ('How long are signed archives retained?', ['Signed archives are retained for thirty-seven days.','Production archives require ninety days.']),
 ('Which region handles sandbox traffic?', ['Sandbox traffic uses eu-west-2.','Primary traffic uses us-east-2.']),
 ('Start the reconciliation worker.', ['Run `orbitctl reconcile --jobs 3`.','The archive retention policy is thirty-seven days.']),
 ('How are service credentials verified?', ['Issuer signatures and expiry are checked before accepting a credential.','Each member has its own encrypted local queue.']),
 ('What is the retry delay?', ['Retry failed deliveries after nineteen seconds.','Telemetry is sampled once per minute.']),
 ('Which operation repairs an index?', ['Use `ledgerctl repair-index --offline`.','Run the report after the repair finishes.']),
 ('What does the audit record include?', ['The audit record includes event time and operation name.','It excludes request bodies and private credentials.']),
 ('归档保留多久？', ['Archives are retained for thirty-seven days.','Production archives require ninety days.']),
]
configs=[(2,2),(4,4),(8,8),(4,8),(8,4)]
order=configs+list(reversed(configs));blocks=[];reference={};max_error=0.0
for block,(embed_threads,rank_threads) in enumerate(order):
    embedding=TextEmbedding(model_name=EMBED_MODEL,revision=EMBED_REVISION,specific_model_path=os.environ['COLONY_EMBED_MODEL_DIR'],threads=embed_threads)
    ranker=TextCrossEncoder(model_name=RANK_MODEL,revision=RANK_REVISION,specific_model_path=os.environ['COLONY_RANK_MODEL_DIR'],threads=rank_threads)
    # Warm this exact pair, outside the fixed measured sequence.
    list(embedding.query_embed(cases[0][0]));list(ranker.rerank(*cases[0],batch_size=1))
    rows=[]
    for rep in range(4):
        for i,(question,passages) in enumerate(cases):
            cpu=time.process_time();start=time.perf_counter()
            vector=np.array(next(embedding.query_embed(question)))
            middle=time.perf_counter();scores=np.array(list(ranker.rerank(question,passages,batch_size=1)))
            end=time.perf_counter();cpu_end=time.process_time()
            if block==0 and rep==0:reference[i]=(vector,scores)
            max_error=max(max_error,float(np.max(np.abs(vector-reference[i][0]))),float(np.max(np.abs(scores-reference[i][1]))))
            rows.append({'case':i,'repeat':rep,'query_seconds':middle-start,'rank_seconds':end-middle,'pipeline_seconds':end-start,'process_cpu_seconds':cpu_end-cpu})
    blocks.append({'embedding_threads':embed_threads,'ranking_threads':rank_threads,'rows':rows,'pipeline_median':statistics.median(r['pipeline_seconds'] for r in rows),'pipeline_total':sum(r['pipeline_seconds'] for r in rows),'cpu_total':sum(r['process_cpu_seconds'] for r in rows)})
    print(json.dumps({k:v for k,v in blocks[-1].items() if k!='rows'}),flush=True)
    del embedding,ranker
    gc.collect()
summary={str(c):{'pipeline_median':statistics.median(r['pipeline_seconds'] for b in blocks if (b['embedding_threads'],b['ranking_threads'])==c for r in b['rows']),'pipeline_total':sum(b['pipeline_total'] for b in blocks if (b['embedding_threads'],b['ranking_threads'])==c),'cpu_total':sum(b['cpu_total'] for b in blocks if (b['embedding_threads'],b['ranking_threads'])==c)} for c in configs}
out={'role':'Independent fixed interleaved short-query/two-passage CPU execution diagnostic; not frozen-workload or gate evidence; all observations retained','cases':cases,'configurations':configs,'fixed_block_order':order,'blocks':blocks,'summary':summary,'max_absolute_vector_or_logit_difference_from_original_threads2':max_error,'limitations':'One configuration pair exists at a time; initialization and one warmup excluded. Measures short-query critical path, not all long-document ingestion or service concurrency.'}
Path('../benchmark-remediation-query-pipeline-profile-29.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'summary':summary,'max_abs_difference':max_error},indent=2))
