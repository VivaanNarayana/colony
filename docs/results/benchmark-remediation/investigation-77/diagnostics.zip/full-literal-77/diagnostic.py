"""Frozen full-coverage lexical bypass; original semantic fallback unchanged."""
import hashlib,json,re,sqlite3,time
from pathlib import Path
import sqlite_vec
from colony import retrieval as r
O=Path(__file__).parent
CASES=[
 ('seed-label','When does a seed lot label expire?','A seed lot label expires after fourteen months. The storage shelf is checked weekly.','How many months is the seed lot label valid?','Which pesticide may be applied to the seed lot?'),
 ('field-trip','What happens if a school field trip is cancelled?','When a field trip is cancelled, the booking fee is returned. Transport deposits are refunded only if the operator agrees.','Is the transport deposit always refunded on cancellation?','Which buses may be used for a school field trip?'),
 ('camera-cell','How long does the camera battery last?','A camera battery supplies about seven hours of recording. Cold weather shortens that duration.','Does cold weather reduce recording time?','Which chemicals may be used to clean the camera battery?'),
 ('research-desk','How long may a desk be reserved?','A research desk may be reserved for up to five hours. A second booking is allowed after the first finishes.','Can a desk reservation last six hours?','Which network may be accessed from the research desk?'),
 ('library-locker','What happens if a library locker code is forgotten?','A librarian resets a forgotten locker code after checking the borrowers card. Contents remain in the same locker.','Are locker contents removed when a forgotten code is reset?','Which objects may be stored in a library locker?'),
 ('poster-storage','How are printed posters stored?','Printed posters are stored flat in labelled drawers. Oversized posters may be rolled around an archival tube.','May an oversized poster be rolled for storage?','Which images may be printed on a poster?'),
 ('shift-change','When does a volunteer shift end?','A volunteer shift ends at four in the afternoon. The shift leader records the handover before volunteers leave.','Is handover recorded before the volunteers leave?','Which equipment may volunteers repair during a shift?'),
 ('reservation-expiry','When does an unpaid reservation expire?','An unpaid reservation expires after twenty hours. Payment received before expiry confirms the reservation.','Does payment before the deadline confirm a reservation?','Which passengers may use an unpaid reservation?'),
]
rows=[]
for n,s,c,p,q in CASES:rows += [dict(name=n+'-positive',saved=s,content=c,query=p,expected=True,fresh=True),dict(name=n+'-negative',saved=s,content=c,query=q,expected=False,fresh=True)]
# Existing controls include the literal false hit and actual native sufficient answer.
old=json.loads(Path('work/paired-rerank-73/inputs.json').read_text(encoding='utf-8'));rows += [dict(x,name='control-'+x['name'],fresh=False) for x in old['rows'] if x['name'] in ['garden-access-wrong-attribute','known-lifetime-positive','known-deletion-negative']]
m=json.loads(Path('../benchmark-remediation-live-56-results/review-mapping.json').read_text(encoding='utf-8'));p=next(x for x in m if x.get('review_id')=='R25')['packets'][0];rows.append(dict(name='native-sufficient-offline-answer',saved='What happens when the server is down?',content=p['content'],query='Does an offline push get queued?',expected=True,fresh=False))
design={'candidate':'Only complete query-term coverage within an existing two-neighbor-sentence window bypasses the existing positive answer>question control. Keep original CE inputs/scores, ranking, dense floors, exact/procedure cases, source fallback and context unchanged.','rejection':'Any baseline admitted sufficient answer lost (including actual R25), new false hit, error; control garden false hit must be rejected. Known deletion failure may remain and must not be claimed fixed. No retuning or combination with rejected candidates.','caps':{'embedding_items':60,'CE_pairs':40},'rows':rows};raw=(json.dumps(design,indent=2)+'\n').encode();(O/'inputs.json').write_bytes(raw);(O/'manifest.json').write_text(json.dumps({'inputs_sha256':hashlib.sha256(raw).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'frozen_before_inference':True},indent=2)+'\n',encoding='utf-8')
cost={'embedding_items':0,'CE_pairs':0,'providers':0,'subjects':0};results=[];error=None;start=time.perf_counter()
try:
 with sqlite3.connect(':memory:') as db:
  db.enable_load_extension(True);sqlite_vec.load(db)
  for c in rows:
   assert cost['embedding_items']+3<=60 and cost['CE_pairs']+2<=40
   q=r.embed(c['query'],query=True);a=r.embed(r.passage(c['saved'],c['content']));s=r.embed(c['saved'],query=True);cost['embedding_items']+=3
   ad,sd=db.execute('SELECT vec_distance_cosine(?,?),vec_distance_cosine(?,?)',(q,a,q,s)).fetchone();sim=1-min(ad,sd);forward,topic=r.rank(c['query'],[c['content'][:4000],c['saved']]);cost['CE_pairs']+=2
   qt=r.terms(c['query']);parts=re.split(r'(?<=[.!?])\s+',c['content'][:4000]);literal=r.local_term_support(qt,c['content'][:4000]);full=bool(qt) and any(qt<=r.terms(' '.join(parts[i:i+2])) for i in range(len(parts)))
   base=sim>=.55 and 1-sd>=.65 and r.fused_score(sim,forward)>=.6
   results.append(dict(name=c['name'],expected=c['expected'],fresh=c['fresh'],literal=literal,full_literal=full,forward=forward,topic=topic,baseline=base and (literal or forward>max(0,topic)),candidate=base and (full or forward>max(0,topic))))
except Exception as e:error={'type':type(e).__name__,'message':str(e)}
lost=[x['name'] for x in results if x['expected'] and x['baseline'] and not x['candidate']];newfalse=[x['name'] for x in results if not x['expected'] and x['candidate'] and not x['baseline']];garden=next((x['candidate'] for x in results if x['name']=='control-garden-access-wrong-attribute'),True)
out={'error':error,'cost':cost,'elapsed_seconds':time.perf_counter()-start,'rows':results,'lost_positives':lost,'new_false_hits':newfalse,'garden_false_hit_remaining':garden,'baseline_positive_misses':[x['name'] for x in results if x['expected'] and not x['baseline']],'baseline_false_hits':[x['name'] for x in results if not x['expected'] and x['baseline']],'candidate_false_hits':[x['name'] for x in results if not x['expected'] and x['candidate']],'rejected':bool(error or lost or newfalse or garden)};(O/'results.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k!='rows'},indent=2))
