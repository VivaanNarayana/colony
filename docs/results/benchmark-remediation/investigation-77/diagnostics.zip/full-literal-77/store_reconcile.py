"""Actual Store reconciliation of frozen full-literal proposal; production read-only."""
import inspect,json,re,tempfile,textwrap,time,uuid
from pathlib import Path
from colony import store as sm,retrieval as r
from colony.models import Grant,Scope,Trail
from colony.validation import snapshot
O=Path('work/full-literal-77');rows=json.loads((O/'inputs.json').read_text(encoding='utf-8'))['rows'];selected=[x for x in rows if x['name'] in ['control-garden-access-wrong-attribute','native-sufficient-offline-answer','control-known-deletion-negative','control-known-lifetime-positive','field-trip-positive','library-locker-negative']]
raw=(json.dumps({'stage':'Actual Store pair, same frozen candidate/labels. Check candidate calls preserve entire answer/current source, source fallback and negative outcome separately. No native claims.','rows':selected},indent=2)+'\n').encode();(O/'store-inputs.json').write_bytes(raw)
def complete(q,t):
 parts=re.split(r'(?<=[.!?])\s+',t)
 return bool(q) and any(q<=r.terms(' '.join(parts[i:i+2])) for i in range(len(parts)))
source=textwrap.dedent(inspect.getsource(sm.Store.find_answer));assert source.count('local_term_support(query_terms, content[:4000])')==1
space=dict(sm.__dict__);space['complete_local_support']=complete;exec(compile(source.replace('local_term_support(query_terms, content[:4000])','complete_local_support(query_terms, content[:4000])'),'<candidate-find-answer>','exec'),space)
original=sm.Store.find_answer;candidate=space['find_answer'];results=[];start=time.perf_counter();cost={'embedding_items':0,'CE_pair_entries':0,'providers':0,'subjects':0}
orig_embed=r.embed;orig_rank=r.rank;orig_ep=r.embed_passages
def embed(*a,**kw):cost['embedding_items']+=1;return orig_embed(*a,**kw)
def ep(texts):cost['embedding_items']+=len(texts);return orig_ep(texts)
def rank(q,texts):cost['CE_pair_entries']+=len(set(texts));return orig_rank(q,texts)
r.embed=sm.embed=embed;r.embed_passages=sm.embed_passages=ep;r.rank=sm.rank=rank
# candidate globals were copied before wrappers; bind its original ranking functions to counters too.
space['embed']=embed;space['rank']=rank
with tempfile.TemporaryDirectory(prefix='colony-literal-store-77-') as tmp:
 root=Path(tmp)
 for i,c in enumerate(selected):
  repo=root/str(i)/'repo';repo.mkdir(parents=True);(repo/'policy.md').write_text(c['content']+'\n',encoding='utf-8');s=sm.Store(repo.parent/'data',repo);g=Grant(member_id='diagnostic',name='Diagnostic',server='http://127.0.0.1:7331',expires_at=int(time.time())+3600,scopes=[Scope(namespace='team',push=True,pull=True)]);s.push(Trail(id=uuid.uuid4().hex,namespace='team',question=c['saved'],content=c['content'],sources=[snapshot(repo,'policy.md')]),g)
  pair={}
  for mode,method in [('baseline',original),('candidate',candidate)]:
   sm.Store.find_answer=method;answer=s.find_answer(c['query'],['team'],604800,.60);result=s.ask(c['query'],['team'],604800,.60);pair[mode]={'answer':answer,'ask':result}
  results.append({'name':c['name'],'expected':c['expected'],'results':pair,'lost_sufficient_answer':c['expected'] and pair['baseline']['answer']['hit'] and not pair['candidate']['answer']['hit'],'introduced_hit':not pair['baseline']['ask']['hit'] and pair['candidate']['ask']['hit']});assert cost['CE_pair_entries']<=150 and cost['embedding_items']<=100
sm.Store.find_answer=original
out={'rows':results,'cost':cost,'elapsed_seconds':time.perf_counter()-start,'lost_sufficient_answers':[x['name'] for x in results if x['lost_sufficient_answer']],'introduced_hits':[x['name'] for x in results if x['introduced_hit']],'qualification':'Garden authored-answer rejection is not total no-hit: source fallback can still expose insufficient topical text. Known deletion failure remains. Six Store pairs only, no native impact.'};(O/'store-results.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8');print(json.dumps({'cost':cost,'lost':out['lost_sufficient_answers'],'introduced':out['introduced_hits'],'outcomes':[{'name':x['name'],'baseline_answer':x['results']['baseline']['answer']['hit'],'candidate_answer':x['results']['candidate']['answer']['hit'],'candidate_ask':x['results']['candidate']['ask'].get('match_kind')} for x in results]},indent=2))
