"""One frozen reverse-direction support guard; answer scores/ranking remain unchanged."""
import hashlib,json,sqlite3,time
from pathlib import Path
import sqlite_vec
from colony import retrieval as r
O=Path(__file__).parent
PAIRS=[
 ('bike-hire','When must a hired bicycle be returned?','Hired bicycles must be returned by six in the evening. The shop accepts overnight returns only with advance agreement.','Can a rented bicycle be kept overnight if this was arranged beforehand?','What insurance accompanies the hired bicycle?'),
 ('theatre-seat','When can a theatre seat booking be changed?','Seat bookings may be changed until noon the preceding day. A sold-out replacement performance cannot be selected.','May a patron move the booking to a fully booked performance?','Which payment processor handles theatre seat bookings?'),
 ('telemetry-buffer','What occurs when the telemetry buffer becomes full?','Once the telemetry buffer reaches capacity, the oldest sample is discarded to make room for the new sample.','Which samples are removed when telemetry storage fills up?','Which cipher protects telemetry samples?'),
 ('ceramic-storage','Where must finished ceramic pieces be stored?','Finished ceramic pieces belong on padded shelves in the dry storeroom. Unfired pieces must remain in the workshop.','Can completed pottery be kept in the workshop with unfired pieces?','Who may purchase finished ceramic pieces?'),
 ('badge-activation','How soon is a temporary access badge activated?','A temporary badge becomes active ten minutes after issue. It remains inactive until the host has approved the visit.','Will a temporary badge work after ten minutes without host approval?','What doors can a temporary badge open?'),
 ('piano-practice','How many practice rooms may a pianist reserve?','A pianist may reserve one practice room at a time. Another reservation can begin after the first one ends.','Can one pianist hold two simultaneous room reservations?','Which piano models equip the practice rooms?'),
 ('text-import','What text files does the importer accept?','The importer reads UTF-8 documents. A byte-order mark is allowed, but malformed byte sequences reject the entire import.','Does the document loader accept a UTF-8 byte-order mark?','How large may an imported document be?'),
 ('water-meter','When is a water meter reading transmitted?','The meter transmits its reading every four hours. If transmission fails, the reading remains locally until the next scheduled attempt.','Is an unsent meter reading retained after a transmission failure?','What protocol authenticates meter transmissions?'),
]
rows=[]
for n,s,c,p,q in PAIRS:rows += [dict(name=n+'-positive',saved=s,content=c,query=p,expected=True,fresh=True),dict(name=n+'-negative',saved=s,content=c,query=q,expected=False,fresh=True)]
# Existing controls exercise the known red test and earlier sufficient-answer wording.
rows += [dict(name='known-login-positive',saved='What is the lifetime of a login session?',content='After thirty minutes, the login session expires. Users must authenticate again before continuing. The expiry interval applies to each newly created session.',query='When does a login session end?',expected=True,fresh=False),dict(name='known-login-negative',saved='What is the lifetime of a login session?',content='After thirty minutes, the login session expires. Users must authenticate again before continuing. The expiry interval applies to each newly created session.',query='Does a login session permit deleting other users?',expected=False,fresh=False),dict(name='known-archive-paraphrase',saved='What is the archive retention interval?',content='Archive retention interval is 57 days.',query='How long do archived records stay available?',expected=True,fresh=False),dict(name='known-attachment-paraphrase',saved='What is the maximum attachment size?',content='Attachments are limited to sixteen megabytes.',query='How large may an uploaded attachment be?',expected=True,fresh=False)]
design={'candidate':'Keep forward answer score, question control, literal support, dense/threshold/exact/procedure guards unchanged. For nonliteral related descriptive answers that otherwise pass, additionally require rank(content[:4000],[question])[0]>0. No reordering or relaxation.','reject_if':'Known login negative remains admitted; any baseline-admitted sufficient answer lost; new unsupported admission; error. Baseline misses and unchanged false hits remain explicit limitations. No retuning.','scope':'Static admission simulation, not Store or native proof. All qualifications retained in source/display, only extra support score added.','caps':{'embeddings':60,'CE_pair_entries':60},'rows':rows}
raw=(json.dumps(design,indent=2)+'\n').encode();(O/'inputs.json').write_bytes(raw);(O/'manifest.json').write_text(json.dumps({'inputs_sha256':hashlib.sha256(raw).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'frozen_before_inference':True},indent=2)+'\n',encoding='utf-8')
cost={'embeddings':0,'CE_pairs':0,'providers':0,'subjects':0};results=[];error=None;start=time.perf_counter()
try:
 with sqlite3.connect(':memory:') as db:
  db.enable_load_extension(True);sqlite_vec.load(db)
  for c in rows:
   assert cost['embeddings']+3<=60 and cost['CE_pairs']+3<=60
   q=r.embed(c['query'],query=True);a=r.embed(r.passage(c['saved'],c['content']));s=r.embed(c['saved'],query=True);cost['embeddings']+=3
   ad,sd=db.execute('SELECT vec_distance_cosine(?,?),vec_distance_cosine(?,?)',(q,a,q,s)).fetchone();sim=1-min(ad,sd)
   forward,topic=r.rank(c['query'],[c['content'][:4000],c['saved']]);reverse=r.rank(c['content'][:4000],[c['query']])[0];cost['CE_pairs']+=3
   literal=r.local_term_support(r.terms(c['query']),c['content'][:4000]);dense=sim>=.55 and 1-sd>=.65
   baseline=dense and r.fused_score(sim,forward)>=.60 and (literal or forward>max(0,topic));candidate=baseline and (literal or reverse>0)
   results.append(dict(name=c['name'],expected=c['expected'],fresh=c['fresh'],forward=forward,topic=topic,reverse=reverse,literal=literal,dense=dense,baseline=baseline,candidate=candidate))
except Exception as e:error={'type':type(e).__name__,'message':str(e)}
lost=[x['name'] for x in results if x['expected'] and x['baseline'] and not x['candidate']];false=[x['name'] for x in results if not x['expected'] and x['candidate']];newfalse=[x['name'] for x in results if not x['expected'] and x['candidate'] and not x['baseline']];red=next((x['candidate'] for x in results if x['name']=='known-login-negative'),True)
out={'error':error,'cost':cost,'elapsed_seconds':time.perf_counter()-start,'rows':results,'lost_positives':lost,'candidate_false_hits':false,'new_false_hits':newfalse,'baseline_misses':[x['name'] for x in results if x['expected'] and not x['baseline']],'known_red_remaining':red,'rejected':bool(error or lost or newfalse or red)};(O/'results.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k!='rows'},indent=2))
