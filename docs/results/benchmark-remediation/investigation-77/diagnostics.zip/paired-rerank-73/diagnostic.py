"""Frozen one-pass question/answer reranker representation study; production read-only."""
import hashlib,json,sqlite3,time
from pathlib import Path
import sqlite_vec
from colony import retrieval as r
O=Path(__file__).parent
FRESH=[
 ('parcel-retention','How long does a parcel remain in the pickup locker?','Parcel locker retention is nine days. After that interval the depot receives the parcel.','When is an uncollected shipment returned to the depot?','Which credential opens the pickup locker?'),
 ('boat-reservation','When may a boating lesson reservation be refunded?','A boating lesson reservation can be refunded until two days before departure. Later cancellations receive no refund unless the marina closes.','Are late cancellations refundable when the marina has closed?','How many boats may one reservation include?'),
 ('sound-export','What audio formats may the sound editor export?','The sound editor writes FLAC and WAV files. MP3 input is accepted but cannot be exported.','Which output encodings can the audio application write?','What sampling frequency does the sound editor use?'),
 ('garden-access','When may volunteers enter the greenhouse?','Volunteers may enter the greenhouse from seven until eleven on Saturdays, provided a supervisor is present.','Can a volunteer visit on Saturday morning without the supervisor?','Which fertilizers may volunteers use in the greenhouse?'),
 ('catalog-snapshot','How frequently is the catalogue snapshot created?','The catalogue creates a snapshot every six hours. A failed snapshot is attempted again after fifteen minutes.','When is another snapshot attempted following a failure?','Who may delete the catalogue snapshot?'),
 ('batch-capacity','How many jobs may the batch runner execute together?','The batch runner executes at most six simultaneous jobs. Additional jobs wait until a running job finishes.','What is the maximum number of concurrent batch jobs?','Which encryption algorithm protects batch job output?'),
 ('exhibit-loan','What is the maximum duration of an exhibit loan?','An exhibit loan lasts at most eighteen weeks. A signed extension is required for any longer loan.','May an exhibit remain on loan for longer than eighteen weeks?','Which insurer covers an exhibit loan?'),
 ('translation-cache','When does the translation cache discard entries?','The translation cache drops an entry after forty hours without access. Reading an entry restarts this interval.','Does reading a cached translation extend its lifetime?','May cached translations contain markup?'),
]
rows=[]
for name,saved,content,positive,negative in FRESH:
 rows += [dict(name=name+'-supported',saved=saved,content=content,query=positive,expected=True,fresh=True),dict(name=name+'-wrong-attribute',saved=saved,content=content,query=negative,expected=False,fresh=True)]
login='After thirty minutes, the login session expires. Users must authenticate again before continuing. The expiry interval applies to each newly created session.'
rows += [dict(name='known-lifetime-positive',saved='What is the lifetime of a login session?',content=login,query='When does a login session end?',expected=True,fresh=False),dict(name='known-deletion-negative',saved='What is the lifetime of a login session?',content=login,query='Does a login session permit deleting other users?',expected=False,fresh=False),dict(name='known-scope-sufficient',saved='How are namespace permissions checked?',content="The server verifies the credential, then /ask builds allowed namespaces from scopes with pull=true. If an explicitly requested namespace is not in that list, it raises HTTP 403, Namespace pull denied.",query='Can an agent pull from an ungranted namespace?',expected=True,fresh=False,note='Illustrative sufficiency control, not byte-exact trial56 replay.')]
design={'candidate':'Replace answer-only CE input by existing retrieval.passage(saved_question, content); preserve dense vectors, support predicate, positive/discriminating guard, thresholds, max12 and exact bypass.','rejection':'Reject if motivating negative remains admitted, any fresh unsupported case admitted, or any baseline admitted sufficient answer lost. No retuning.','scope':'Score-only admission simulation, not Store/protocol/native evidence. All source text and its qualifications preserved; no answer selection or compaction.','caps':{'CE_pairs':60,'embedding_items':60},'rows':rows}
raw=(json.dumps(design,indent=2)+'\n').encode();(O/'inputs.json').write_bytes(raw);(O/'manifest.json').write_text(json.dumps({'inputs_sha256':hashlib.sha256(raw).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'retrieval_sha256':hashlib.sha256(Path('src/colony/retrieval.py').read_bytes()).hexdigest(),'frozen_before_inference':True},indent=2)+'\n',encoding='utf-8')
cost={'CE_pair_entries':0,'embedding_items':0,'providers':0,'subjects':0};results=[];started=time.perf_counter();error=None
try:
 with sqlite3.connect(':memory:') as db:
  db.enable_load_extension(True);sqlite_vec.load(db)
  for c in rows:
   assert cost['embedding_items']+3<=60 and cost['CE_pair_entries']+3<=60
   q=r.embed(c['query'],query=True);a=r.embed(r.passage(c['saved'],c['content']));s=r.embed(c['saved'],query=True);cost['embedding_items']+=3
   ad,sd=db.execute('SELECT vec_distance_cosine(?,?),vec_distance_cosine(?,?)',(q,a,q,s)).fetchone();similarity=1-min(ad,sd)
   old,new,topic=r.rank(c['query'],[c['content'][:4000],r.passage(c['saved'],c['content']),c['saved']]);cost['CE_pair_entries']+=3
   literal=r.local_term_support(r.terms(c['query']),c['content'][:4000]);dense=similarity>=.55 and 1-sd>=.65
   def allowed(score):return dense and r.fused_score(similarity,score)>=.60 and (literal or score>max(0,topic))
   results.append(dict(name=c['name'],expected=c['expected'],fresh=c['fresh'],literal=literal,dense=dense,similarity=similarity,question_similarity=1-sd,old_logit=old,new_logit=new,topic_logit=topic,baseline=allowed(old),candidate=allowed(new)))
except Exception as exc:error={'type':type(exc).__name__,'message':str(exc)}
summary={'error':error,'cost':cost,'elapsed_seconds':time.perf_counter()-started,'rows':results,'lost_positives':[x['name'] for x in results if x['expected'] and x['baseline'] and not x['candidate']],'candidate_false_hits':[x['name'] for x in results if not x['expected'] and x['candidate']],'baseline_false_hits':[x['name'] for x in results if not x['expected'] and x['baseline']],'baseline_positive_misses':[x['name'] for x in results if x['expected'] and not x['baseline']]}
summary['rejected']=bool(error or summary['lost_positives'] or summary['candidate_false_hits']);(O/'results.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in summary.items() if k!='rows'},indent=2))
