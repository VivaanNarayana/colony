"""One frozen component-consensus safeguard; full answers and ordering retained."""
import hashlib,json,re,sqlite3,time
from pathlib import Path
import sqlite_vec
from colony import retrieval as r
O=Path(__file__).parent
CASES=[
 ('map-refresh','How often does the walking map update?','The walking map refreshes every twelve minutes. An unavailable network keeps the previous map visible.','Is the prior walking map retained when network access fails?','Does the walking map disclose hikers home addresses?'),
 ('textile-return','When may unused fabric be returned?','Unused fabric may be returned within eleven days. Cut lengths cannot be returned unless they contain a manufacturing defect.','Can a defective cut length be returned?','Which factory manufactured the unused fabric?'),
 ('gallery-key','Who may collect a gallery key?','Only a registered exhibitor may collect the gallery key. A delegate may collect it with a signed letter from that exhibitor.','Can a delegate obtain the gallery key with written authorization?','How many gallery keys are produced each year?'),
 ('voucher-expiry','When does a cinema voucher expire?','A cinema voucher expires eight months after purchase. Reservations made before expiry remain valid for their booked screening.','Will a screening booked before voucher expiry remain valid?','May a cinema voucher buy refreshments?'),
 ('compressor-duty','How long may the workshop compressor run?','The workshop compressor may run for fifteen minutes at a time. A cooling interval of five minutes must follow each run.','Must the compressor cool before another fifteen-minute run?','What voltage powers the workshop compressor?'),
 ('annotation-size','What is the maximum size of a recorded annotation?','Each annotation may contain at most two thousand characters. A longer annotation is rejected without saving any part.','Are oversized annotations stored partly?','Which font is used to render a recorded annotation?'),
 ('reading-room','How long may a visitor use the reading room?','A visitor may remain in the reading room for three hours. A librarian can approve one additional hour if no one is waiting.','Can the librarian extend a visit when another visitor is waiting?','Which books may a visitor borrow from the reading room?'),
 ('forecast-store','How long are station forecasts retained?','The station keeps forecasts for twenty-six days. A pinned forecast stays until an operator explicitly removes the pin.','Does a pinned station forecast expire after twenty-six days?','Are station forecasts signed with an elliptic curve key?'),
]
rows=[]
for n,s,c,p,q in CASES:rows += [dict(name=n+'-positive',saved=s,content=c,query=p,expected=True,fresh=True),dict(name=n+'-negative',saved=s,content=c,query=q,expected=False,fresh=True)]
login='After thirty minutes, the login session expires. Users must authenticate again before continuing. The expiry interval applies to each newly created session.'
rows += [dict(name='known-login-positive',saved='What is the lifetime of a login session?',content=login,query='When does a login session end?',expected=True,fresh=False),dict(name='known-login-negative',saved='What is the lifetime of a login session?',content=login,query='Does a login session permit deleting other users?',expected=False,fresh=False),dict(name='known-archive-positive',saved='What is the archive retention interval?',content='Archive retention interval is 57 days.',query='How long do archived records stay available?',expected=True,fresh=False),dict(name='known-attachment-positive',saved='What is the maximum attachment size?',content='Attachments are limited to sixteen megabytes.',query='How large may an uploaded attachment be?',expected=True,fresh=False)]
design={'candidate':'For otherwise admitted related nonliteral descriptive answers, require arithmetic mean of forward CE scores for all nonempty punctuation-delimited sentences in original4000-char answer prefix to be >0. Full answer, source context, current forward ranking/control and thresholds unchanged. Singleton mean is its existing score.','rejection':'Known wrong-attribute remains; any baseline accepted sufficient answer is lost; any new unsupported admission; error. No retuning of this candidate. Existing baseline misses/false hits retained.','caps':{'embedding_items':60,'CE_pair_entries':110},'rows':rows};raw=(json.dumps(design,indent=2)+'\n').encode();(O/'inputs.json').write_bytes(raw);(O/'manifest.json').write_text(json.dumps({'inputs_sha256':hashlib.sha256(raw).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'frozen_before_inference':True},indent=2)+'\n',encoding='utf-8')
cost={'embedding_items':0,'CE_pairs':0,'providers':0,'subjects':0};results=[];error=None;start=time.perf_counter()
try:
 with sqlite3.connect(':memory:') as db:
  db.enable_load_extension(True);sqlite_vec.load(db)
  for c in rows:
   parts=[x for x in re.split(r'(?<=[.!?])\s+',c['content'][:4000]) if x.strip()];assert cost['CE_pairs']+2+len(parts)<=110 and cost['embedding_items']+3<=60
   q=r.embed(c['query'],query=True);a=r.embed(r.passage(c['saved'],c['content']));s=r.embed(c['saved'],query=True);cost['embedding_items']+=3
   ad,sd=db.execute('SELECT vec_distance_cosine(?,?),vec_distance_cosine(?,?)',(q,a,q,s)).fetchone();sim=1-min(ad,sd)
   values=r.rank(c['query'],[c['content'][:4000],c['saved'],*parts]);cost['CE_pairs']+=len(set([c['content'][:4000],c['saved'],*parts]));forward,topic,*components=values;mean=sum(components)/len(components)
   literal=r.local_term_support(r.terms(c['query']),c['content'][:4000]);dense=sim>=.55 and 1-sd>=.65;baseline=dense and r.fused_score(sim,forward)>=.60 and (literal or forward>max(0,topic));candidate=baseline and (literal or mean>0)
   results.append(dict(name=c['name'],expected=c['expected'],fresh=c['fresh'],literal=literal,forward=forward,topic=topic,parts=parts,component_scores=components,mean=mean,baseline=baseline,candidate=candidate))
except Exception as e:error={'type':type(e).__name__,'message':str(e)}
lost=[x['name'] for x in results if x['expected'] and x['baseline'] and not x['candidate']];newfalse=[x['name'] for x in results if not x['expected'] and x['candidate'] and not x['baseline']];red=next((x['candidate'] for x in results if x['name']=='known-login-negative'),True)
out={'error':error,'cost':cost,'elapsed_seconds':time.perf_counter()-start,'rows':results,'lost_positives':lost,'new_false_hits':newfalse,'known_red_remaining':red,'baseline_false_hits':[x['name'] for x in results if not x['expected'] and x['baseline']],'candidate_false_hits':[x['name'] for x in results if not x['expected'] and x['candidate']],'baseline_positive_misses':[x['name'] for x in results if x['expected'] and not x['baseline']],'rejected':bool(error or lost or newfalse or red)};(O/'results.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k!='rows'},indent=2))
