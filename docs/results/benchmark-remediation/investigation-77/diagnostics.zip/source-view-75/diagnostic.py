import json,time,hashlib
from pathlib import Path
from colony.context import source_chunks,context_window,source_lines
from colony.retrieval import rank
from colony.validation import snapshot
root=Path('../benchmark-remediation-live-56-runtime/feat/repo');p=snapshot(root,'README.md');chunks=source_chunks(root,[p]);question='Which tools does the MCP wrapper expose?';out=Path('work/source-view-75');raw=(json.dumps({'question':question,'source_hash':p.content_hash,'chunks':chunks,'diagnostic':'unrestricted existing query rank across already cited bounded source descriptors; no admission or Store changes'},indent=2)+'\n').encode();(out/'inputs.json').write_bytes(raw);(out/'inputs.sha256').write_text(hashlib.sha256(raw).hexdigest(),encoding='utf-8')
s=rank(question,[x[2] for x in chunks]);rows=sorted([{'ref':x[0],'line':x[1],'text':x[2],'score':v} for x,v in zip(chunks,s)],key=lambda x:x['score'],reverse=True);(out/'scores.json').write_text(json.dumps({'rows':rows,'CE_pairs':len(chunks),'embeddings':0,'providers':0,'subject_calls':0},indent=2)+'\n',encoding='utf-8');print(json.dumps([{k:v for k,v in x.items() if k!='text'} for x in rows[:5]],indent=2))
