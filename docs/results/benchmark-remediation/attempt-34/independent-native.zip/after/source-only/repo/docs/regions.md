Staging traffic uses ap-east-4. Production traffic uses sa-west-7.
