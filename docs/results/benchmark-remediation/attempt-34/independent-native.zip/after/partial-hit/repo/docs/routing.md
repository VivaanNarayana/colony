The active zone is cedar-2. The fallback zone is defined in src/colony/regions.py.
