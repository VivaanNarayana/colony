Ordinary archives expire after 65 days. Legal-hold archives remain until the hold is released.
