import hmac

def check_digest(body, stamp, key):
    expected = hmac.digest(key, body, 'sha512')
    if not hmac.compare_digest(expected, stamp):
        raise ValueError('invalid stamp')
