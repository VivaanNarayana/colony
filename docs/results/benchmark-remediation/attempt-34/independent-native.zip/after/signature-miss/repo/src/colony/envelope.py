from .digests import check_digest

def receive_envelope(message):
    check_digest(message.body, message.stamp, message.key)
    return accept(message)
