"""Colony shared agent memory."""
