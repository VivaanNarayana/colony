import json,time,statistics,tempfile
from pathlib import Path
from colony.context import source_chunks,excerpts
from colony.validation import snapshot
prefix='# Archive policy\n\nGeneral archives expire after37days.\n\nProduction archives require90days.\n\napi_key=private_archive_credential\n\n# Appendix\n\n'
template='Appendix entry {i}: deployment metadata has unrelated routing details and build settings.'
rows=[]
with tempfile.TemporaryDirectory(prefix='colony-descriptor-profile-') as directory:
    root=Path(directory)
    for n in [100,1000,10000]:
        body=prefix+'\n\n'.join(template.format(i=i) for i in range(n))
        (root/'guide.md').write_text(body,encoding='utf-8',newline='\n')
        sources=[snapshot(root,'guide.md')];times={'rebuilt':[],'forwarded':[]}
        for rep in range(6):
            # The upstream evidence lookup computes these in both paths; isolate
            # only the subsequent excerpt materialization stage, not a whole ask.
            chunks=source_chunks(root,sources);outputs={}
            for kind in (['rebuilt','forwarded'] if rep%2==0 else ['forwarded','rebuilt']):
                start=time.perf_counter()
                outputs[kind]=excerpts(root,sources,'Archive retention?',preferred=[('guide.md',3)],candidate_chunks=chunks if kind=='forwarded' else None)
                times[kind].append(time.perf_counter()-start)
            assert outputs['rebuilt']==outputs['forwarded']
            text=str(outputs['forwarded']);assert '37days' in text and '90days' in text and 'private_archive_credential' not in text
        rows.append({'paragraphs':n,'file_bytes':len(body.encode()),'sha256':sources[0].content_hash,'seconds':times,'medians':{k:statistics.median(v) for k,v in times.items()},'outputs_identical':True,'fresh_display_fingerprints_required':True})
out={'role':'Independent excerpt-materialization stage diagnostic, not whole-ask/native-token/gate evidence; all fixed alternating observations retained','prefix':prefix,'appendix_template':template,'cases':rows}
Path('../benchmark-remediation-descriptor-profile-28.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps([{'bytes':r['file_bytes'],'medians':r['medians']} for r in rows],indent=2))
