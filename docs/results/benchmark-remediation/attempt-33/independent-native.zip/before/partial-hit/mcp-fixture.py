import copy,sys
from pathlib import Path
sys.path.insert(0,'C:\\Users\\b3vel\\Documents\\Codex\\2026-10-20\\https-github-com-vivaannarayana-colony-https\\work\\benchmark-remediation-schema-regressions-33\\before\\source')
import colony.mcp as m
PACKET={'hit': True, 'match_kind': 'answer', 'status': 'validated', 'namespace': 'bench', 'recommendation': 'reuse_if_relevant', 'tainted': True, 'sources': [{'ref': 'docs/routing.md', 'content_hash': '61f82894f1003e5e2ac80df256bbc6abd0851aba4fb54b1d7b6ff15b18019150'}], 'evidence': [{'ref': 'docs/routing.md', 'line': 1, 'text': 'The active zone is amber-4. The fallback zone is defined in src/colony/zones.py.\n'}], 'content': 'The active zone is amber-4.'}
class Client:
 def __init__(self,home):pass
 def ask(self,*a,**kw):return copy.deepcopy(PACKET)
 def push(self,trail):return {'id':trail.id,'stored':True,'duplicate':False}
m.Client=Client
m.create_mcp(Path.cwd()).run(transport='stdio')
