import asyncio
import copy
import json
from types import SimpleNamespace

import pytest
from mcp.server.fastmcp import FastMCP
from mcp.server.fastmcp.exceptions import ToolError

import colony.mcp as mcp


def test_schema_labels_do_not_remove_title_properties_or_literal_data():
    schema = {
        "title": "GeneratedArguments",
        "type": "object",
        "properties": {
            "title": {"title": "Title", "type": "string", "minLength": 1},
            "options": {
                "title": "Options",
                "default": {"title": "keep"},
                "examples": [{"title": "example"}],
                "const": {"title": "literal"},
                "enum": [{"title": "enum-value"}],
            },
        },
        "$defs": {"title": {"title": "NamedType", "type": "string"}},
        "required": ["title"],
        "additionalProperties": False,
        "allOf": [{"title": "Constraint", "properties": {"title": {"maxLength": 30}}}],
        "items": [{"title": "Item", "$ref": "#/$defs/title"}],
        "x-ui": {"title": "extension data"},
    }
    original = copy.deepcopy(schema)
    compact = mcp.schema_without_titles(schema)
    assert schema == original
    assert "title" not in compact
    assert compact["properties"]["title"] == {"type": "string", "minLength": 1}
    assert compact["required"] == ["title"] and compact["additionalProperties"] is False
    assert compact["$defs"] == {"title": {"type": "string"}}
    assert compact["items"] == [{"$ref": "#/$defs/title"}]
    assert compact["allOf"] == [{"properties": {"title": {"maxLength": 30}}}]
    for key in ("default", "examples", "const", "enum"):
        assert compact["properties"]["options"][key] == original["properties"]["options"][key]
    assert compact["x-ui"] == {"title": "extension data"}


def test_list_projection_retains_descriptions_annotations_constraints_and_internal_schema(
    monkeypatch, tmp_path
):
    monkeypatch.setattr(mcp, "Client", lambda home: None)
    server = mcp.create_mcp(tmp_path)
    original = asyncio.run(FastMCP.list_tools(server))
    projected = asyncio.run(server.list_tools())
    assert [t.name for t in projected] == ["ask", "push"]
    for before, after in zip(original, projected, strict=True):
        b = before.model_dump()
        a = after.model_dump()
        assert {k: v for k, v in b.items() if k != "inputSchema"} == {
            k: v for k, v in a.items() if k != "inputSchema"
        }
        assert len(json.dumps(a)) < len(json.dumps(b))
    ask = projected[0].inputSchema
    assert ask["required"] == ["question"]
    assert ask["properties"]["namespace"] == {
        "anyOf": [{"type": "string"}, {"type": "null"}],
        "default": None,
    }
    proof = projected[1].inputSchema["$defs"]["FileEvidence"]
    assert proof["additionalProperties"] is False
    assert proof["required"] == ["ref", "content_hash"]
    assert proof["properties"]["ref"] == {"minLength": 1, "maxLength": 1024, "type": "string"}
    assert proof["properties"]["content_hash"] == {"pattern": "^[a-f0-9]{64}$", "type": "string"}
    assert proof["properties"]["kind"] == {"default": "file", "pattern": "^file$", "type": "string"}
    assert original[0].inputSchema["properties"]["question"]["title"] == "Question"
    assert asyncio.run(FastMCP.list_tools(server)) == original


@pytest.mark.parametrize(
    "bad_source",
    [
        {"ref": "policy.md", "content_hash": "a" * 63},
        {"ref": "policy.md", "content_hash": "G" * 64},
        {"ref": "", "content_hash": "a" * 64},
        {"ref": "x" * 1025, "content_hash": "a" * 64},
        {"ref": "policy.md", "content_hash": "a" * 64, "kind": "url"},
        {"ref": "policy.md", "content_hash": "a" * 64, "symbol": "invented"},
        {"ref": "policy.md", "content_hash": "a" * 64, "contains": "invented"},
    ],
)
def test_compact_schema_still_rejects_invalid_proof_arguments_before_client(
    monkeypatch, tmp_path, bad_source
):
    calls = []
    monkeypatch.setattr(
        mcp, "Client", lambda home: SimpleNamespace(push=lambda trail: calls.append(trail))
    )
    server = mcp.create_mcp(tmp_path)
    with pytest.raises(ToolError):
        asyncio.run(
            server.call_tool(
                "push",
                {
                    "namespace": "lab",
                    "question": "Retention?",
                    "content": "37 days.",
                    "sources": [bad_source],
                },
            )
        )
    assert calls == []


def test_compact_schema_preserves_argument_defaults_and_successful_push(monkeypatch, tmp_path):
    saved = []

    def push(trail):
        saved.append(trail)
        return {"id": trail.id, "stored": True, "duplicate": False}

    monkeypatch.setattr(mcp, "Client", lambda home: SimpleNamespace(push=push))
    server = mcp.create_mcp(tmp_path)
    output = asyncio.run(
        server.call_tool(
            "push",
            {
                "namespace": "lab",
                "question": "Retention?",
                "content": "37 days.",
                "sources": [{"ref": "policy.md", "content_hash": "a" * 64}],
            },
        )
    )
    assert saved[0].tainted is True and saved[0].sources[0].kind == "file"
    assert json.loads(output[0].text) == {"stored": True, "duplicate": False}
