import copy,sys
from pathlib import Path
sys.path.insert(0,'C:\\Users\\b3vel\\Documents\\Codex\\2026-10-20\\https-github-com-vivaannarayana-colony-https\\work\\benchmark-remediation-schema-regressions-33\\after\\source')
import colony.mcp as m
PACKET={'hit': True, 'match_kind': 'answer', 'status': 'validated', 'namespace': 'bench', 'recommendation': 'reuse_if_relevant', 'tainted': True, 'sources': [{'ref': 'docs/archive.md', 'content_hash': '8562a8f3b360c9aa6e26955c4642f9a9e6ccb01160c616ca2dd9955f183150f4'}], 'evidence': [{'ref': 'docs/archive.md', 'line': 1, 'text': 'Ordinary archives expire after 37 days. Legal-hold archives remain until the hold is released.\n'}], 'content': 'Ordinary archives expire after 37 days. Legal holds prevent expiry until released.'}
class Client:
 def __init__(self,home):pass
 def ask(self,*a,**kw):return copy.deepcopy(PACKET)
 def push(self,trail):return {'id':trail.id,'stored':True,'duplicate':False}
m.Client=Client
m.create_mcp(Path.cwd()).run(transport='stdio')
