Ordinary archives expire after 37 days. Legal-hold archives remain until the hold is released.
