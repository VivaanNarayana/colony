Sandbox traffic uses eu-north-3. Production traffic uses ap-south-2.
