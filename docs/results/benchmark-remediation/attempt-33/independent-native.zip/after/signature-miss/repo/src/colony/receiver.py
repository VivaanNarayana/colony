from .stamps import verify_stamp

def receive(message):
    verify_stamp(message.body, message.stamp, message.key)
    return accept(message)
