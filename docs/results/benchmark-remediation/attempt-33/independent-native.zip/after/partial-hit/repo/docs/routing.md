The active zone is amber-4. The fallback zone is defined in src/colony/zones.py.
