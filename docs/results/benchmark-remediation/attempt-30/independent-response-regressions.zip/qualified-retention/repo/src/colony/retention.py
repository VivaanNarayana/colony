# Default archives expire after 14 days. Production archives require 90 days.
# Legal-hold archives never expire until the hold is released.
DEFAULT_DAYS = 14
PRODUCTION_DAYS = 90
