import json,sys
from pathlib import Path
from importlib import import_module
sys.path.insert(0, 'C:\\Users\\b3vel\\Documents\\Codex\\2026-10-20\\https-github-com-vivaannarayana-colony-https\\work\\colony\\src')
import colony.mcp as m
class Client:
    def __init__(self, home): pass
    def ask(self, *a, **kw): return {"hit": False, "reason": "no_relevant_trail"}
    def push(self, trail): return {"id": trail.id, "stored": True, "duplicate": False}
m.Client=Client
m.create_mcp(Path.cwd()).run(transport="stdio")
