# First repair the connection. Then run `exportctl retry --pending`.
# If the server still returns 503, wait at least 23 seconds before another attempt.
RETRY_DELAY_SECONDS = 23
