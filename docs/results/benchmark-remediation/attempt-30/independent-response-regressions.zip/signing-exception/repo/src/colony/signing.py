# Production messages require Ed25519 signatures.
# Local test fixtures may omit a signature only when sandbox=True.
def required(sandbox=False):
    return not sandbox
