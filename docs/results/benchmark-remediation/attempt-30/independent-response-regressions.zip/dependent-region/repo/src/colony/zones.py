TENANT_REGIONS = {"archive": "ap-south-1", "sandbox": "eu-north-1"}
