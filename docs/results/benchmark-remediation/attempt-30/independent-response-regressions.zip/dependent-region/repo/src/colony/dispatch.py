from .zones import TENANT_REGIONS

def region(tenant):
    return TENANT_REGIONS[tenant]
