from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil,subprocess,zipfile
root=Path.cwd();w=root/'work';base=root/'docs/results/benchmark-remediation';out=base/'attempt-59';assert not out.exists();out.mkdir()
source='0606a51b712024fd517624243ac190ce54dc201a';baseline='6fa6826aa4c835001c0d2bc8f3bec838499e5b5d';assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==source
live=root.parent/'benchmark-remediation-live-59-results';runtime=root.parent/'benchmark-remediation-live-59-runtime';local=root.parent/'benchmark-remediation-local-59-results'
r=json.loads((live/'comparison.json').read_text(encoding='utf-8'));assert sum(r['gate'].values())==5 and r['data_budget_verified'];assert int((w/'analyzer-59.exit.txt').read_text(encoding='utf-8-sig'))==1
assert not subprocess.check_output(['git','diff','4e39df9','--','scripts',*[str(Path('docs/results/benchmark-remediation')/f'attempt-{n}') for n in range(1,59)]])
def cp(p,n):
 d=out/n;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,d)
def put(n,x):(out/n).write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
for arm in ['main','feature']:
 for n in ['raw-measurements.jsonl','loaded-implementations.json','metadata.json','corpus-sha256.json','reviews.json']:cp(live/arm/n,arm+'/'+n)
for n in ['comparison.json','completed.json','protocol.json']:cp(live/n,n)
if (live/'model-policy-failures.jsonl').exists():cp(live/'model-policy-failures.jsonl','model-policy-failures.jsonl')
cp(live/'review-mapping.json','review-records.json')
for n in ['manual-review','frozen-labels','verification','preflight','required-gates']:cp(w/f'{n}-59.json',n+'.json')
for n in ['tool-audit','research-review']:cp(root.parent/f'benchmark-remediation-{n}-59.json',n+'.json')
cp(w/'review81.json','implementation-review.json');cp(base/'budget-allowance-4.json','usage-budget.json');cp(w/'local-raw-audit-59.json','local-raw-audit.json')
for p in local.iterdir():
 if p.is_file():cp(p,p.name)
for n in ['local-59.stdout.txt','local-59.exit.txt','live-59.stdout.txt','live-59.exit.txt','analyzer-59.stdout.txt','analyzer-59.stderr.txt','analyzer-59.exit.txt','wake-local-59.json','wake-live-59.json']:cp(w/n,n)
for n,p in [('tests-full.txt','full-final.txt'),('tests-full.xml','full-final.xml'),('tests-focused.txt','final-controls.txt'),('tests-focused.xml','final-controls.xml'),('tests-ruff.txt','ruff-final.txt')]:cp(w/'overlap-81'/p,n)
assert all(json.loads((w/f'wake-{k}-59.json').read_text(encoding='utf-8'))['request_released'] for k in ['local','live'])
prev=json.loads((base/'attempt-58/comparison.json').read_text(encoding='utf-8'));gross=sum(a['tokens'] for a in r['arms'].values());assert gross==2550418
put('raw-totals.json',{'all48_sessions_included':True,'totals':r['arms']})
put('outcome.json',{'trial':59,'source':source,'baseline':baseline,'gates_passed':5,'gates_total':8,'gate_statuses':{'benchmarks/'+k:'success' if v else 'failure' for k,v in r['gate'].items()},'blocking_gates':r['blocking_gates'],'gate_changes_from58':{k:{'before':prev['gate'][k],'after':v} for k,v in r['gate'].items() if v!=prev['gate'][k]},'official_analyzer_invocations':1,'local_invocations':1,'native_invocations':1,'native_sessions_completed':48,'native_gross_tokens':gross,'cumulative_native50_through59_gross':20411150+gross,'all_outcomes_costs_retained':True,'benchmark_or_session_restarts':0,'proof_repair':False,'all_gates_passed':False,'current_complete_eight_gate_verdict_available':True,'tests_passed':433,'tests_failed':0,'tests_skipped':1,'ruff_passed':True,'usage':{'allowance':4,'baseline':20,'continuation_start_observed':21,'last_observed':24,'stop':25,'reset':1793382050,'shared':True,'reporting_may_lag':True},'all_models_harness_and_gates_unchanged':True,'causal_limit':'Cumulative feature/main comparison; generated saved wording/cache/sampling vary. No isolated native benefit of overlap81 or prior repairs established. Local loss reproduction and regression survival are narrower evidence.','next_mechanism':'Unnecessary research despite available source/saved facts and gross/uncached/time overhead. Same irrelevant metadata packet persists; no safe candidate is yet approved.','model_policy_failure_file_present':(live/'model-policy-failures.jsonl').exists(),'published_utc':datetime.now(timezone.utc).isoformat()})
put('code-hashes.json',{'source':source,'sha256':{n:hashlib.sha256(subprocess.check_output(['git','show',f'{source}:{n}'])).hexdigest() for n in subprocess.check_output(['git','ls-tree','-r','--name-only',source,'--','src','scripts','tests'],text=True).splitlines()}})
(out/'README.md').write_text('''# Trial 59: 5/8 strict gates; correctness/protocol pass, performance remains red

Measured **0606a51b712024fd517624243ac190ce54dc201a** versus freshly fetched main **6fa6826aa4c835001c0d2bc8f3bec838499e5b5d**. One fresh local comparison, all 48 native gpt-6-luna/low sessions, and one unchanged analyzer invocation after frozen labels. Every outcome, attempted save and cost is retained without retries, resampling, proof repair or main exemption.

Pass: **loaded implementations, tests/lint, local lookup, correctness, both-arm tool protocol**. Fail: **gross tokens, uncached tokens, live time**. From trial 58, correctness and protocol become green; time becomes red. Full 433 passed / one existing Windows skip, Ruff/whitespace pass. Local117/117each,234 audited observations:31.5722% lower warm time,95%reductionCI+23.3799%to+40.9262%. Native gross18.9050% higher, reductionCI−29.5249%to−7.1145%; uncached24.1905% higher,CI−51.6037%to−0.8868%; time1.3198% higher,CI−12.9015%to+10.0851%. Original strict confidence requirements remain.

| Metric | Main | Feature |
|---|---:|---:|
| Gross tokens | 1,165,080 | 1,385,338 |
| Uncached input+output | 158,616 | 196,986 |
| Subject seconds | 230.866 | 233.913 |
| Research calls | 20 | 28 |
| Tool calls | 50 | 60 |
| Core facts | 24/24 | 24/24 |
| Valid citations | 16/24 | 24/24 |
| Protocol violations | 0 | 0 |

The [overlap fix81](../investigation-81/README.md) reproduces and preserves three otherwise omitted selected qualifications/dependencies in local controls. It retains every baseline excerpt byte/slot and adds complete same-file overlapping ranges only in unused original caps. It does not fix disjoint source selection. Native R21 still receives the same irrelevant README96 metadata; subsequent actual MCP source research and push yield a correct final tool-name answer. Feature research increases rather than decreases. There is **no demonstrated isolated native performance benefit** from81 or the earlier source/index/retry changes: cumulative feature/main differences, saved wording, sampling and cache vary. The local mechanism, regression survival and this complete native result are separate evidence.

Coordinator reviewed48answers/48packets and14research/save traces. Six unique new contexts were read; other contexts match reviewed58 bytes. All42displayed source contexts match frozen bytes/SHA256/original line/scrubbed prefixes. Core facts24each and all24featurecitations pass. Eight main citations fail; mainR39 names a real README heading rejected by the unchanged nonnumeric-fragment oracle. The helper's additional missing-target message after fragment error is misleading; the file/heading exists. No fabricated-provenance claim. Bare-file references retain original acceptance rules.

All14pushes/15fingerprints match actual preceding successful new reads; no malformed-hash repair. Main3stored/3queued receipts, finalDB6rows/3encryptedqueue; feature8stored/8rows/noqueue. MainR39explicitlytainted=false persists as stored0/queuedfalse; preserve this fresh finding along with historical56false. AllfeaturetaintsTrue; explicitfalse server enforcement remains covered by unchanged tests. Every session asks once, all actual research sessions save with successful stored/queued receipts, and no research budget is exceeded. MainR37now saves after real reads; historical58failure remains retained.

Independent SolHigh patch review before measurement found no runtime blocker with explicit limits. It did not grade this native run; coordinator grading is nonblind development evidence. Both existing workers idle throughout timing. Original fixture failures and rejected80policy prototype remain retained. No universal semantic-completeness or production-readiness claim.

Native59gross2,550,418; cumulative50/51/53/54/55/56/57/58/59gross22,961,568,52native0; earlier costs remain separate. Same shared allowance4 baseline20%, continuation first21%, latest24%, stop25%, reset2026-10-30 17:40:50UTC; reporting may lag. No earlier remainder added, natural-reset renewal, credits/accounts/APIbilling bypass. No activebenchmark; wake requests released. Task unfinished; PR3draft/unmerged/noauto.

Models/weights/revisions, harness/config/workload/order/prompts/rubrics/oracles/confidence/context/research/token/time budgets and all8active strict ruleset25440133checks/no bypass remain unchanged. Implementations/corpus/loaded-source proofs, exact prompts/events/answers/labels, all costs and manifests are archived. Private DB/identity/queue/storage keys excluded. Public top-level text normalizesLF; ZIP labels preserve original bytes. No analyzer replay. Next work must address a distinct general measured failure and preserve safeguards before another comparison; no identical-code retry. Read [RESUME](../RESUME.txt).
''',encoding='utf-8',newline='\n')
with zipfile.ZipFile(out/'live-native.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(live.rglob('*')):
  if p.is_file():z.write(p,'results/'+p.relative_to(live).as_posix())
 for arm,folder in [('main','main'),('feature','feat')]:
  for p in sorted((runtime/'implementation'/arm).rglob('*.py')):z.write(p,'implementation/'+arm+'/'+p.relative_to(runtime/'implementation'/arm).as_posix())
  for p in sorted((runtime/folder/'repo').rglob('*')):
   if p.is_file():z.write(p,'corpus/'+arm+'/'+p.relative_to(runtime/folder/'repo').as_posix())
with zipfile.ZipFile(out/'development.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n in ['prepare59.py','prepare_review59.py','inspect_59.py','freeze_labels_59.py','publish59.py','preflight-59.stdout.txt','review-prep-59.txt','tool-audit-59.stdout.txt','manual-review-59.json','new-contexts-59.json','review81.json','local-raw-audit-59.json','usage-allowance4.jsonl']:z.write(w/n,n)
for n in ['live-native.zip','development.zip']:
 with zipfile.ZipFile(out/n) as z:
  assert z.testzip() is None;assert not any(n.endswith(('.db','.key','.pem','.enc')) or 'identity.json' in n for n in z.namelist())
for p in out.rglob('*'):
 if p.is_file() and p.suffix in {'.json','.jsonl','.txt','.md','.xml'}:p.write_bytes(p.read_bytes().replace(b'\r\n',b'\n'))
frozen=json.loads((w/'frozen-labels-59.json').read_text(encoding='utf-8'))['labels_sha256'];put('label-hash-scopes.json',{'original_zip_hashes':frozen,'public_LF_hashes':{a+'/reviews.json':hashlib.sha256((out/a/'reviews.json').read_bytes()).hexdigest() for a in ['main','feature']}})
put('sha256.json',{p.relative_to(out).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(out.rglob('*')) if p.is_file() and p.name!='sha256.json'})
resume=base/'RESUME.txt';header='TRIAL59 COMPLETE — 5/8STRICTGATES; PERFORMANCE STILL FAILS.\nSame allowance4 baseline20%, latest24%, STOP25%; +4observedpoints, lagpossible.\nReset2026-10-30 17:40:50UTC; priorcosts/outcomes preserved, no remainderadded.\nMeasured0606a51b712024fd517624243ac190ce54dc201a versusfreshmain6fa6826.\nRead attempt59 README/comparison/manual-review/research-review/tool-audit/outcome.\nPASS loaded/tests/local/correctness/both-armprotocol. FAIL gross/uncached/time.\nFrom58correctness/protocolturngreen; timebecomesred. Full433pass1Windows skip, Ruffpass.\nLocal31.57%lowerpositiveCI; nativegross18.90%higher/uncached24.19%higherstrictlyworseCIs;\ntime1.32%higherCIcrosses0. Core24both; citations16main24feature; protocol0both.\nFeature research28versusmain20; sameREADME96irrelevantmetadata persists.\nAll14pushes/15proofsmatchactualnewreads; main3stored3queued/DB6rows3queue;\nfeature8stored8rows0queue. Mainexplicitfalse stored0/queuedfalse retained; featureallTrue.\nNo isolated81nativebenefit; local omittedfact recovery is narrower evidence.\nAll48answers/48packets/14tracesreviewed,42contextsverified; coordinatornonblindgrading.\nNative59gross2,550,418; cumulative50through59=22,961,568;52native0/earliercostsretained.\nBoth existingworkersidle, two total/no nested. No activebenchmark; wake released.\nAllmodels/harness/gates/budgets/taint/proofs/auth/scope/freshness/queue safeguards unchanged.\nNextdistinctgeneralmechanism mustreduce unnecessaryresearch/overhead; no safecandidateapproved.\nNo identical-code retry, per-sessionresampling, oraclechange or mainexemption.\nAt25stopnewphases, preserve partialresults/costs, updateandstopunfinished. PR3draft/unmerged/noauto.\n\n';resume.write_bytes(header.encode('utf-8')+resume.read_bytes())
print(json.dumps({'trial':59,'passes':5,'gross':gross,'archive_bytes':(out/'live-native.zip').stat().st_size}))
