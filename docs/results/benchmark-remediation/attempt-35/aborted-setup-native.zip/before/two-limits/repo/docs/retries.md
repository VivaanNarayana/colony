Retries stop after seven attempts.
