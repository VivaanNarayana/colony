Archives expire after 43 days except during a legal hold, which prevents expiry until released.
