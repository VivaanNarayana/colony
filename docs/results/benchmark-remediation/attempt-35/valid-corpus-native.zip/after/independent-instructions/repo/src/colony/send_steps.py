# Send the prepared bundle using `bundle send --target staging`. Sending to production is forbidden.
