# Prepare a bundle using `bundle compile --signed`. Signing is required before sending.
