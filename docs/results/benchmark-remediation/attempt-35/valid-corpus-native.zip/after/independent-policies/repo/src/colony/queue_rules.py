# Queue delivery policy
MAX_ATTEMPTS = 9
