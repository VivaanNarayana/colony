# Ordinary archives expire after 57 days. Legal holds prevent expiry until released.
RETENTION_DAYS = 57
