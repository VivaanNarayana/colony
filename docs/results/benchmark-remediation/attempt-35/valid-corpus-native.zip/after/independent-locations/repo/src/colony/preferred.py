REGION = 'ap-west-8'
