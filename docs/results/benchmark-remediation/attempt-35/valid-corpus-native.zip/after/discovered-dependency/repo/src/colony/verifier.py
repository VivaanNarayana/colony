from .algorithms import verify_record

def check(record):
    verify_record(record)
