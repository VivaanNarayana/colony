# Independent fixture
