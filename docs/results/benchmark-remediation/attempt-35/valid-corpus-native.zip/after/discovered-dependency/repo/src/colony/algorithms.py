import hmac

def verify_record(record):
    expected = hmac.digest(record.key, record.body, 'sha224')
    if not hmac.compare_digest(expected, record.signature):
        raise ValueError('bad signature')
