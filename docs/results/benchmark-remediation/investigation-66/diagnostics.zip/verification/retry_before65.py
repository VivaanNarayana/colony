import subprocess,types
from pathlib import Path
old=types.ModuleType('before_retry_receipt_guard')
exec(compile(subprocess.check_output(['git','show','bf240ab:src/colony/client.py']),'bf240ab:client.py','exec'),old.__dict__)
import colony.client
colony.client.Client.retry=old.Client.retry
import pytest
raise SystemExit(pytest.main(['tests/test_retry_receipt.py','-q']))
