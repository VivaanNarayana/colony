"""One fixed procedural-prefix predicate comparison with actual temporary Store."""

import hashlib
import importlib.util
import json
import sys
import tempfile
import time
from pathlib import Path
from unittest.mock import patch

BASE = Path.cwd()
DIRECTORY = Path(__file__).parent
DOMAINS = [
    dict(name="weather", question="How do I start the weather station collector?",
         saved_question="How can I launch the weather station collector?",
         overview="The weather station collector is a local process that gathers outdoor measurements. Its overview describes station identity, polling state, observation counters and retained diagnostic metadata. Startup status is reported as an informational field.",
         command="Run `weatherctl collect --foreground` to start the weather station collector.",
         unrelated="archive-audit --check"),
    dict(name="audio", question="How do I start the audio normalization worker?",
         saved_question="How can I launch the audio normalization worker?",
         overview="The audio normalization worker is a local process that processes recorded sound. Its overview describes input levels, output meters, clipping counters and retained diagnostic metadata. Launch status is reported as an informational field.",
         command="Run `soundctl normalize --listen` to start the audio normalization worker.",
         unrelated="inventory-audit --check"),
]


def frozen(name,value):
    data = (json.dumps(value,indent=2)+"\n").encode()
    (DIRECTORY / f"{name}.json").write_bytes(data)
    digest = hashlib.sha256(data).hexdigest()
    (DIRECTORY / f"{name}.sha256").write_text(digest+"\n")
    return digest


def prepare():
    rows = []
    for domain in DOMAINS:
        prefix = " ".join([domain["overview"]]*((4200//len(domain["overview"]))+1))
        assert len(prefix)>4000
        for case_type in ["unsupported-tail","sufficient-prefix","sufficient-tail","exact-full-api"]:
            tail = domain["unrelated"] if case_type=="unsupported-tail" else domain["command"]
            content = domain["command"]+"\n\n"+prefix if case_type=="sufficient-prefix" else prefix+"\n\n"+tail
            rows.append(dict(id=domain["name"]+"-"+case_type,domain=domain["name"],case_type=case_type,
                             question=domain["saved_question"] if case_type=="exact-full-api" else domain["question"],
                             saved_question=domain["saved_question"],content=content,source=content,
                             namespace="team",source_state="current",expired=False,
                             expected_supported=case_type!="unsupported-tail",required_command=domain["command"]))
    for control in ["scope","stale","expired"]:
        original = next(r for r in rows if r["id"]==("audio" if control=="expired" else "weather")+"-sufficient-tail")
        rows.append(dict(original, id="boundary-"+control, case_type="boundary-"+control,
                         namespace="private" if control=="scope" else "team",
                         source_state="stale" if control=="stale" else "current",expired=control=="expired"))
    source = (BASE / "src/colony/store.py").read_text()
    old = "or procedural_text(content)"
    new = "or procedural_text(content[:4000])"
    assert source.count(old)==1
    candidate = source.replace(old,new)
    (DIRECTORY / "candidate_store.py").write_text(candidate,encoding="utf-8")
    design = dict(change={"original":old,"candidate":new},store_calls=22,store_call_cap=24,actual_ce_pair_cap=120,
                  fixed_cases="Two unrelated domains x unsupported-tail/sufficient-prefix/sufficient-tail/exact-full-API, plus scope/stale/expired",
                  original_thresholds=True,original_models=True,scope_and_hash_rules_unchanged=True,
                  limitations="Not a trial55 explanation. Compare answer versus evidence fallback separately; full API content retains supported tails; no MCP-output claim.",
                  source_copy="Private candidate is an exact current store.py copy with one predicate-window replacement; temporary encrypted DB/key directories are not retained")
    digest = frozen("inputs",dict(design=design,rows=rows))
    manifest = dict(inputs_sha256=digest,script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                    original_store_sha256=hashlib.sha256(source.encode()).hexdigest(),
                    candidate_store_sha256=hashlib.sha256(candidate.encode()).hexdigest(),
                    retrieval_sha256=hashlib.sha256((BASE/"src/colony/retrieval.py").read_bytes()).hexdigest(),
                    frozen_before_models=True,cases=len(rows),production_edits=False)
    frozen("manifest",manifest)
    print(json.dumps(manifest))


class PairBudgetExceeded(RuntimeError):
    pass


def measure():
    from colony import context
    from colony import store as original
    from colony.models import Grant, Scope, Trail
    from colony.retrieval import embed, embed_passages, procedural_text, rank, requires_procedure
    from colony.store import Store
    from colony.validation import snapshot

    data = (DIRECTORY / "inputs.json").read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    assert digest == (DIRECTORY / "inputs.sha256").read_text().strip()
    spec = importlib.util.spec_from_file_location("procedure_window_candidate",DIRECTORY / "candidate_store.py")
    candidate = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(candidate)
    cost = dict(store_calls=0,embedding_single_calls=0,embedding_batch_calls=0,embedding_vectors=0,
                rank_calls=0,rank_pair_entries=0,actual_ce_pairs=0,provider_calls=0)
    active = {"case":"setup","arm":"setup"}
    inference_log = []

    def counted_embed(text,*,query=False):
        cost["embedding_single_calls"] += 1
        cost["embedding_vectors"] += 1
        inference_log.append(dict(**active,operation="embed",mode="query" if query else "passage",texts=[text]))
        return embed(text,query=query)

    def counted_passages(texts):
        cost["embedding_batch_calls"] += 1
        cost["embedding_vectors"] += len(texts)
        inference_log.append(dict(**active,operation="embed_passages",mode="passage",texts=texts))
        return embed_passages(texts)

    def counted_rank(question,passages):
        unique = len(set(passages))
        if cost["actual_ce_pairs"]+unique>120:
            raise PairBudgetExceeded("120 actual CE-pair cap reached before inference")
        cost["rank_calls"] += 1
        cost["rank_pair_entries"] += len(passages)
        cost["actual_ce_pairs"] += unique
        scores = rank(question,passages)
        inference_log.append(dict(**active,operation="rank",question=question,passages=passages,scores=scores,actual_pairs=unique))
        return scores

    def compact(result,case):
        return dict(hit=result.get("hit"),kind=result.get("match_kind"),status=result.get("status"),
                    age=result.get("age_flag"),content_chars=len(result.get("content","")),
                    content_has_required_command=case["required_command"] in result.get("content",""),
                    evidence_has_required_command=case["required_command"] in json.dumps(result.get("evidence",[])),
                    reason=result.get("reason"))

    rows = []
    started = time.perf_counter()
    stop_error = None
    with patch.multiple(original,embed=counted_embed,embed_passages=counted_passages,rank=counted_rank), patch.multiple(
        candidate,embed=counted_embed,embed_passages=counted_passages,rank=counted_rank
    ), patch.object(context,"rank",counted_rank):
        for case in json.loads(data)["rows"]:
            active.update(case=case["id"],arm="setup")
            try:
                with tempfile.TemporaryDirectory(prefix="colony-procedure-window-63-") as temp:
                    root = Path(temp)
                    repo = root/"repo"
                    repo.mkdir()
                    (repo/"manual.md").write_text(case["source"]+"\n",encoding="utf-8")
                    store = Store(root/"data",repo)
                    grant = Grant(member_id="diagnostic",name="diagnostic",server="http://localhost",
                                  expires_at=int(time.time())+3600,scopes=[Scope(namespace=n,push=True,pull=True) for n in ["team","private"]])
                    trail = Trail(id=hashlib.md5(case["id"].encode()).hexdigest(),namespace=case["namespace"],
                                  question=case["saved_question"],content=case["content"],sources=[snapshot(repo,"manual.md")])
                    store.push(trail,grant)
                    if case["source_state"]=="stale":
                        (repo/"manual.md").write_text("The source changed.\n")
                    if case["expired"]:
                        with store.connect() as db:
                            db.execute("UPDATE trails SET created_at=0")
                    outputs = {}
                    for arm in ["original","prefix-only"]:
                        if cost["store_calls"]>=24:
                            raise PairBudgetExceeded("24 Store-call cap reached")
                        active["arm"] = arm
                        cost["store_calls"] += 1
                        if arm=="prefix-only":
                            with patch.object(Store,"find_answer",candidate.Store.find_answer):
                                outputs[arm] = store.ask(case["question"],["team"],604800,.60)
                        else:
                            outputs[arm] = store.ask(case["question"],["team"],604800,.60)
                    rows.append(dict(**case,procedure_question=requires_procedure(case["question"]),
                                     full_procedural_predicate=procedural_text(case["content"]),
                                     prefix_procedural_predicate=procedural_text(case["content"][:4000]),
                                     results=outputs,summary={arm:compact(result,case) for arm,result in outputs.items()}))
                    print(json.dumps(dict(id=case["id"],summary=rows[-1]["summary"])))
            except Exception as exc:
                stop_error = dict(case=case["id"],type=type(exc).__name__,message=str(exc),arm=active["arm"])
                print(json.dumps(dict(stop_error=stop_error)))
                break
    cost["elapsed_seconds"] = time.perf_counter()-started
    output = dict(inputs_sha256=digest,cost=cost,stop_error=stop_error,rows=rows,inference_log=inference_log,
                  limitations="Actual Store results with unchanged models; one predicate change in private source copy only. No semantics forced. Full API content and source-only fallback are distinct. Not a trial55 explanation. Temporary DB/key material excluded.")
    (DIRECTORY / "results.json").write_text(json.dumps(output,indent=2)+"\n")
    print(json.dumps(dict(cost=cost,completed=len(rows),stop_error=stop_error)))


if __name__=="__main__":
    prepare() if sys.argv[1:]==["--prepare"] else measure()
