Question-eligibility crowding: bounded diagnostic 66

Conclusion: actual SQLite reproduces candidate starvation by question-ineligible
near answer vectors. This establishes the code mechanism, not a trial55 cause.
The private prefilter candidate recovers the hidden answer but is not shown safe:
an explicit score-stub counterexample replaces a numeric answer with an answer
that supplies no requested number. No production patch is recommended from this
diagnostic alone. All production code, models, guards and retained evidence stay
unchanged.

Reproduction (repo root, PowerShell):
  .venv/Scripts/python.exe work/eligibility-crowding-66/diagnostic.py freeze
  .venv/Scripts/python.exe work/eligibility-crowding-66/diagnostic.py run
Do not execute again into this directory: freeze/run reject replacement.
Frozen manifest SHA256:
  b2fcf92cff1316a7f8ca79c8242b6b10ce14b6bf3935db93852dac9ef633c311

Artifacts:
  manifest.json: exact production source identity and frozen artifact hashes
  preregistration.json, cases.json: rule, cases, explicit ranks and limits
  baseline-store.py, candidate-store.py, candidate.diff: source and only change
  results.jsonl: all24 full receipts, SQL traces, actual dense orders, real
    synthetic-source hashes, exact stub scores/passages and timestamp controls
  run-output.txt, run-exit.txt, report.json: retained one-run results/costs
  started.json: no-retry marker
Never publish private-runtime/ databases or generated storage.key files.

Mechanism in current src/colony/store.py:
  lines578-587 select scope-filtered top12 by minimum answer/question distance;
  lines591-600 remove rows failing question cosine/exact-question eligibility.
In crowded: twelve answer cosines .9900 to .9889, saved-question cosine
.10000002384185791; eligible thirteenth answer/question cosine
.800000011920929. Baseline has zero survivors and misses. Candidate has one
survivor, returns its actual hash-validated source. No model produced this order:
sqlite-vec computed it from explicit384-dimensional float32 unit vectors.

Candidate changes only the SQL selection: same question-distance >=.65
(>=.70 for procedure) OR exact saved_question.strip().casefold()==query
predicate added before LIMIT12; exact normalization uses a deterministic SQLite
Python UDF. Existing postfilter remains. No age predicate, age sorting, relevance
change, guard weakening or full-corpus production fetchall. See candidate.diff.
Extra cosine computation and Python UDF callbacks are a cost/complexity risk;
this experiment does not quantify production speed or query-plan selectivity.

Observed paired outcomes:
  crowded: miss -> validated eligible answer
  unicode-exact-crowded: miss -> validated exact answer
  eligible-alone: same validated answer
  ineligible-only: same miss
  denied-nearest: same permitted validated answer
  expired-eligible: same unverified, age_flag=true diagnostic
  exact-age-boundary: same validated, age_flag=false answer
  unicode-exact-alone: same validated answer, no ranking
  descriptive-threshold: both accept actual cosine .6500000059604645
  procedure-threshold: both reject actual cosine .699999988079071
  empty-scope: same no_pull_scope, zero embed/rank calls
  precision-counterexample: correct numeric answer -> unsupported blue-folder
    answer. Eleven ineligible near rows leave the correct answer twelfth in
    baseline; prefilter admits the extra eligible row. Fixed answer ranks20 vs10
    make it win. This demonstrates possible pool-precision risk under declared
    synthetic ranks; it does NOT show actual neural rankings or native failures.

Exact Unicode control: saved ' \tStraẞe torque\n', query 'STRASSE TORQUE'.
Python strip/casefold agrees; ASCII SQLite lower() would not be equivalent.
Timestamp immutability and permitted namespace checks remain intact. Nominal
float thresholds are not mathematically exact boundary vectors; recorded actual
SQLite float outputs govern both engines, with no epsilon/retuning.

Costs: 12 cases,24 actual find_answer query calls,60 Store.push fixture setup
calls,22 query embed-stub calls,19 rank-stub calls (including source excerpts),
largest primary answer rank batch2 (cap12 unchanged). Zero neural/provider/
subject/download calls. Single run exit0; measured diagnostic2.7163212seconds.
No causal performance/native token claims. No failed attempts or resamples.
