"""Frozen, zero-neural question-eligibility candidate-pool diagnostic.

Run freeze first, then run once. Synthetic rank outputs isolate pool behavior;
they are deliberately not measurements of model quality or answer correctness.
"""
import difflib
import hashlib
import json
import math
import sys
import time
import types
from contextlib import contextmanager
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
SOURCE = REPO / "src/colony/store.py"
NOW = 2_000_000_000.0
AGE = 1000
Q = "What numeric torque is specified for the copper bracket?"
ANSWER = "Copper bracket specified numeric torque is 11 newtonmeters."
WRONG = "Copper bracket specified numeric torque is listed in the blue folder."


def row(label, a=.8, q=.8, *, question=None, answer=ANSWER, age=0, ns="public"):
    return dict(label=label, a=a, q=q, question=question or "Copper bracket numeric torque specification", answer=answer, age=age, ns=ns)


def blockers(n=12):
    return [row(f"ineligible-{i:02}", .99-i*.0001, .1,
                question=f"Which orchard inspection schedule applies to plot {i}?") for i in range(n)]


def cases():
    unicode = row("unicode-exact", .9, .1, question=" \tStraẞe torque\n", answer="Straße torque is 11 newtonmeters.")
    return [
        dict(name="crowded", rows=blockers()+[row("eligible")], query=Q),
        dict(name="eligible-alone", rows=[row("eligible")], query=Q),
        dict(name="ineligible-only", rows=blockers(), query=Q),
        dict(name="denied-nearest", rows=[row("denied",1,1,ns="private"),row("eligible")], query=Q),
        dict(name="expired-eligible", rows=[row("aged",age=AGE+.001)], query=Q),
        dict(name="exact-age-boundary", rows=[row("boundary",age=AGE)], query=Q),
        dict(name="unicode-exact-alone", rows=[unicode], query="STRASSE TORQUE"),
        dict(name="unicode-exact-crowded", rows=blockers()+[unicode], query="STRASSE TORQUE"),
        dict(name="descriptive-threshold", rows=[row("nominal-.65",.9,.65)], query=Q),
        dict(name="procedure-threshold", rows=[row("nominal-.70",.9,.70,answer="Start copper bracket torque calibration with `torque-check`.")], query="How do I start copper bracket torque calibration?"),
        dict(name="empty-scope", rows=[row("eligible")], query=Q, namespaces=[]),
        dict(name="precision-counterexample", rows=blockers(11)+[row("correct",.85,.85),row("unsupported",.8,.8,answer=WRONG)], query=Q),
    ]


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, obj):
    path.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")


def freeze():
    assert not (ROOT/"manifest.json").exists(), "Never replace a frozen design"
    baseline = SOURCE.read_text(encoding="utf-8")
    old = "WHERE t.namespace IN ({placeholders}) ORDER BY distance, t.created_at DESC LIMIT ?"
    new = "WHERE t.namespace IN ({placeholders}) AND (1 - vec_distance_cosine(q.embedding, ?) >= ? OR py_strip_casefold(t.question) = ?) ORDER BY distance, t.created_at DESC LIMIT ?"
    bindings = "[vector, vector, vector, *namespaces, CANDIDATES]"
    replacement = "[vector, vector, vector, *namespaces, vector, (0.70 if procedure else 0.65), normalized_question, CANDIDATES]"
    connect = "db.row_factory = sqlite3.Row"
    udf = connect + '\n        db.create_function("py_strip_casefold", 1, lambda value: value.strip().casefold(), deterministic=True)'
    assert all(baseline.count(x)==1 for x in [old,bindings,connect])
    candidate = baseline.replace(old,new).replace(bindings,replacement).replace(connect,udf)
    compile(candidate,"candidate-store.py","exec")
    (ROOT/"baseline-store.py").write_text(baseline,encoding="utf-8")
    (ROOT/"candidate-store.py").write_text(candidate,encoding="utf-8")
    (ROOT/"candidate.diff").write_text("".join(difflib.unified_diff(baseline.splitlines(True),candidate.splitlines(True),fromfile="baseline/store.py",tofile="candidate/store.py")),encoding="utf-8")
    write_json(ROOT/"cases.json",cases())
    write_json(ROOT/"preregistration.json",dict(rule="Only move existing question cosine/exact strip().casefold eligibility ahead of LIMIT12; retain scope, distance ordering, age, postfilter, literal/semantic guards, validation.",cases=12,query_calls=24,neural_calls=0,rank_stub="20 for blue-folder answer,10 for numeric torque or procedure answer,0 otherwise. No calibration/retuning. Explicit ranks isolate SQL only.",failure_policy="All outputs retained; no candidate adjustment or resampling. Precision counterexample is an anticipated rejection risk, not desired-patch assertion.",threshold_policy="float32 .65/.70 vectors use actual SQLite outputs; do not repair rounding.",costs="No model/provider/subject/download/tokenizer calls. Store.push fixture setup separately counted; 24 find_answer queries. SQL trace includes actual selection and validation DML. Private DB/key files never publish."))
    files=["diagnostic.py","baseline-store.py","candidate-store.py","candidate.diff","cases.json","preregistration.json"]
    write_json(ROOT/"manifest.json",dict(source_path=str(SOURCE),source_sha256=digest(SOURCE.read_bytes()),files={f:digest((ROOT/f).read_bytes()) for f in files}))
    print(json.dumps(dict(frozen=True,manifest_sha256=digest((ROOT/"manifest.json").read_bytes()),cases=12,query_calls=24)))


def run():
    manifest=json.loads((ROOT/"manifest.json").read_text(encoding="utf-8"))
    assert digest(SOURCE.read_bytes())==manifest["source_sha256"]
    assert all(digest((ROOT/f).read_bytes())==h for f,h in manifest["files"].items())
    assert not (ROOT/"started.json").exists(), "No identical-run retry"
    write_json(ROOT/"started.json",dict(time=time.time(),manifest_sha256=digest((ROOT/"manifest.json").read_bytes())))
    import sqlite_vec
    import colony.context as context
    import colony.retrieval as retrieval
    from colony.models import Grant,Scope,Trail
    from colony.validation import snapshot
    calls=[]
    attempts=[]
    def forbidden(*args,**kwargs):
        attempts.append(True)
        raise AssertionError("Neural initialization prohibited")
    retrieval.models=forbidden
    def vector(cosine):
        return sqlite_vec.serialize_float32([cosine,math.sqrt(1-cosine*cosine)]+[0.0]*382)
    def embed(text,**kwargs):
        calls.append(dict(operation="embed_stub",text=text,kwargs=kwargs))
        return vector(1)
    def rank(question,passages):
        scores=[20.0 if "blue folder" in p else 10.0 if "11 newtonmeters" in p or "`torque-check`" in p else 0.0 for p in passages]
        calls.append(dict(operation="rank_stub",question=question,passages=passages,scores=scores))
        return scores
    engines={}
    for name in ["baseline","candidate"]:
        mod=types.ModuleType("colony.eligibility_66_"+name)
        mod.__file__=str(ROOT/(name+"-store.py"))
        sys.modules[mod.__name__]=mod
        exec(compile(Path(mod.__file__).read_text(encoding="utf-8"),mod.__file__,"exec"),mod.__dict__)
        mod.models=lambda:None
        mod.index_version=lambda:"deterministic-384-eligibility-only"
        mod.embed=embed
        mod.embed_passages=lambda texts:[vector(1) for _ in texts]
        mod.rank=rank
        mod.time=types.SimpleNamespace(time=lambda:NOW)
        engines[name]=mod
    context.rank=rank
    specs=json.loads((ROOT/"cases.json").read_text(encoding="utf-8"))
    grant=Grant(member_id="fixture",name="Synthetic fixture",server="http://127.0.0.1",expires_at=4102444800,scopes=[Scope(namespace=n,push=True,pull=True) for n in ["public","private"]])
    started=time.perf_counter()
    results=[]
    pushes=0
    for case in specs:
        folder=ROOT/"private-runtime"/case["name"]
        repo=folder/"repo"
        repo.mkdir(parents=True)
        store=engines["baseline"].Store(folder/"data",repo)
        labels={}
        sources=[]
        for i,spec in enumerate(case["rows"]):
            ident=digest((case["name"]+":"+spec["label"]).encode())[:32]
            labels[ident]=spec["label"]
            ref=f"fixture-{i}.txt"
            (repo/ref).write_text(spec["answer"]+"\n",encoding="utf-8")
            source=snapshot(repo,ref)
            sources.append(dict(label=spec["label"],ref=ref,content_hash=source.content_hash))
            store.push(Trail(id=ident,namespace=spec["ns"],question=spec["question"],content=spec["answer"],sources=[source]),grant)
            pushes+=1
            with store.connect() as db:
                rid=db.execute("SELECT rowid FROM trails WHERE id=?",[ident]).fetchone()[0]
                db.execute("UPDATE trail_vectors SET embedding=? WHERE rowid=?",[vector(spec["a"]),rid])
                db.execute("UPDATE trail_questions SET embedding=? WHERE rowid=?",[vector(spec["q"]),rid])
                db.execute("UPDATE trails SET created_at=? WHERE id=?",[NOW-spec["age"],ident])
        with store.connect() as db:
            before=dict(db.execute("SELECT id,created_at FROM trails").fetchall())
            dense=db.execute("SELECT t.id,t.namespace,vec_distance_cosine(v.embedding,?) AS answer_distance,vec_distance_cosine(q.embedding,?) AS question_distance FROM trails t JOIN trail_vectors v ON t.rowid=v.rowid JOIN trail_questions q ON t.rowid=q.rowid ORDER BY min(vec_distance_cosine(v.embedding,?),vec_distance_cosine(q.embedding,?)),t.created_at DESC",[vector(1)]*4).fetchall()
        pools=[dict(label=labels[r["id"]],namespace=r["namespace"],answer_cosine=1-r["answer_distance"],question_cosine=1-r["question_distance"]) for r in dense]
        for name,mod in engines.items():
            instance=object.__new__(mod.Store)
            instance.__dict__.update(store.__dict__)
            original=instance.connect
            sql=[]
            @contextmanager
            def traced():
                with original() as db:
                    db.set_trace_callback(sql.append)
                    yield db
            instance.connect=traced
            offset=len(calls)
            receipt=instance.find_answer(case["query"],case.get("namespaces",["public"]),AGE,.60)
            stubcalls=calls[offset:]
            primary=next((len(c["scores"]) for c in stubcalls if c["operation"]=="rank_stub"),0)
            assert primary<=12
            with store.connect() as db:
                after=dict(db.execute("SELECT id,created_at FROM trails").fetchall())
            result=dict(case=case["name"],engine=name,selected=labels.get(receipt.get("id")),receipt=receipt,sql_trace=sql,stub_calls=stubcalls,first_rank_batch=primary,created_at_unchanged=before==after,actual_dense_order=pools,sources=sources)
            results.append(result)
            with (ROOT/"results.jsonl").open("a",encoding="utf-8") as stream:
                stream.write(json.dumps(result,ensure_ascii=False)+"\n")
            print(json.dumps(dict(case=case["name"],engine=name,selected=result["selected"],hit=receipt.get("hit"),status=receipt.get("status"),age_flag=receipt.get("age_flag"),primary_rank_batch=primary)),flush=True)
    paired={c["name"]:{r["engine"]:r for r in results if r["case"]==c["name"]} for c in specs}
    observations=dict(crowded_recovery=not paired["crowded"]["baseline"]["receipt"]["hit"] and paired["crowded"]["candidate"]["selected"]=="eligible",unicode_crowded_recovery=paired["unicode-exact-crowded"]["candidate"]["selected"]=="unicode-exact",precision_counterexample=paired["precision-counterexample"]["baseline"]["selected"]=="correct" and paired["precision-counterexample"]["candidate"]["selected"]=="unsupported")
    report=dict(observations=observations,queries=len(results),fixture_pushes=pushes,models_called=len(attempts),elapsed_seconds=time.perf_counter()-started,max_primary_rank_batch=max(r["first_rank_batch"] for r in results),timestamps_unchanged=all(r["created_at_unchanged"] for r in results),production_source_unchanged=digest(SOURCE.read_bytes())==manifest["source_sha256"],limits="Explicit vector/rank fixtures demonstrate admission mechanics and precision risk only. Not native/model evidence; no trial55 causal claim. SQL UDF incurs Python callbacks and repeated cosine computation; full-table selection already computes distances. Keep private-runtime DBs and generated keys private.")
    write_json(ROOT/"report.json",report)
    assert not attempts
    print(json.dumps(report),flush=True)


if __name__=="__main__":
    {"freeze":freeze,"run":run}[sys.argv[1]]()
