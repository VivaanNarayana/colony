"""Evidence-capture repetition of the completed trial55 exact-byte audit.

Reads retained public evidence only. No tokenizer, model, native sample or corpus
normalization. Source hashes are receipt assertions, not newly recomputed full-file
hashes. Review packets are compared with their actual retained ask responses.
"""

import hashlib
import json
import time
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
EVIDENCE = REPO / "docs" / "results" / "benchmark-remediation" / "attempt-55"
started = time.perf_counter()
input_paths = [EVIDENCE / "review-records.json", EVIDENCE / "main" / "raw-measurements.jsonl", EVIDENCE / "feature" / "raw-measurements.jsonl"]
input_hashes = {str(path.relative_to(REPO)): hashlib.sha256(path.read_bytes()).hexdigest() for path in input_paths}
records = json.loads(input_paths[0].read_text(encoding="utf-8"))
raw = {}
for arm in ["main", "feature"]:
    for line in (EVIDENCE / arm / "raw-measurements.jsonl").read_text(encoding="utf-8").splitlines():
        row = json.loads(line)
        raw[(arm, row["task_id"])] = json.loads(row["asks"][0]["result"]["content"][0]["text"])

counts = Counter()
results = []
eligible_ids = []
saved_characters = saved_bytes = 0
for record in records:
    packet = record["packets"][0]
    actual = raw[(record["arm"], record["task_id"])]
    assert packet == actual, record["review_id"]
    counts["packets"] += 1
    counts[f"{record['arm']}_packets"] += 1
    answer = packet.get("content")
    eligible = packet.get("hit") and packet.get("status") == "validated" and packet.get("match_kind") == "answer" and isinstance(answer, str) and bool(answer)
    if not packet.get("hit"):
        category = "miss"
    elif packet.get("status") != "validated":
        category = "nonvalidated_hit"
    elif packet.get("match_kind") != "answer":
        category = "validated_source_only"
    elif not isinstance(answer, str) or not answer:
        category = "saved_answer_without_content"
    else:
        category = "validated_saved_answer"
    counts[category] += 1
    if eligible:
        eligible_ids.append(record["review_id"])
        counts[f"{record['arm']}_validated_saved_answers"] += 1
        saved_characters += len(answer)
        saved_bytes += len(answer.encode("utf-8"))
        if packet.get("current_repository_reads"):
            counts["saved_answers_with_reads"] += 1
    row = {"review_id": record["review_id"], "arm": record["arm"], "task_id": record["task_id"], "category": category, "raw_packet_equals_review_packet": packet == actual, "packet_reference": f"{record['arm']}/raw-measurements.jsonl:{record['task_id']}:asks[0]", "eligible_saved_answer_characters": len(answer) if eligible else 0, "eligible_saved_answer_utf8_bytes": len(answer.encode("utf-8")) if eligible else 0, "saved_answer_utf8_sha256": hashlib.sha256(answer.encode("utf-8")).hexdigest() if eligible else None, "sources_reported_by_receipt": packet.get("sources", []), "current_reads": []}
    for index, source in enumerate(packet.get("current_repository_reads", [])):
        text = source["content"].encode("utf-8")
        occurrences = []
        if eligible:
            needle = answer.encode("utf-8")
            offset = 0
            while True:
                position = text.find(needle, offset)
                if position < 0:
                    break
                occurrences.append(position)
                offset = position + 1
        row["current_reads"].append({"read_index": index, "source_path": source["path"], "reported_full_source_sha256": source["sha256"], "start_line": source.get("start_line"), "complete_file": source.get("complete_file", False), "citation": source.get("citation"), "included_text_characters": len(source["content"]), "included_text_utf8_bytes": len(text), "included_text_utf8_sha256": hashlib.sha256(text).hexdigest(), "comparison_performed": bool(eligible), "entire_read_equals_saved_answer": text == answer.encode("utf-8") if eligible else None, "exact_saved_answer_byte_offsets": occurrences})
    matches = sum(len(source["exact_saved_answer_byte_offsets"]) for source in row["current_reads"])
    row["exact_occurrences"] = matches
    row["potential_removed_characters_once"] = len(answer) if eligible and matches else 0
    row["potential_removed_utf8_bytes_once"] = len(answer.encode("utf-8")) if eligible and matches else 0
    results.append(row)

summary = {"operation": "Evidence-capture repetition of completed audit; not a new investigation, model or native sample", "counts": dict(counts), "eligible_trace_ids": eligible_ids, "saved_answer_characters_examined": saved_characters, "saved_answer_utf8_bytes_examined": saved_bytes, "matching_packets": sum(row["exact_occurrences"] > 0 for row in results), "exact_contiguous_occurrences": sum(row["exact_occurrences"] for row in results), "entire_read_equalities": sum(source["entire_read_equals_saved_answer"] is True for row in results for source in row["current_reads"]), "potential_removed_characters": sum(row["potential_removed_characters_once"] for row in results), "potential_removed_utf8_bytes": sum(row["potential_removed_utf8_bytes_once"] for row in results), "review_raw_packet_equalities": sum(row["raw_packet_equals_review_packet"] for row in results), "model_calls": 0, "tokenizer_calls": 0, "native_samples": 0, "input_sha256": input_hashes, "audit_script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), "elapsed_seconds": time.perf_counter() - started, "limits": ["Only entire saved answer bytes searched inside each actual included read; no normalization, partial phrase matching, reconstructed text or concatenation across reads.", "Reported full-file source hashes are retained receipt assertions; included text hashes are computed here. This does not rerun full-source validation.", "No token or native-performance savings inferred.", "No private runtime/database/key files accessed or copied."], "conclusion": "Zero exact occurrences and zero removable characters/bytes; no justified saved-answer deduplication patch."}
assert (counts["packets"], counts["validated_saved_answer"], counts["validated_source_only"], counts["miss"]) == (48, 13, 21, 14)
assert (saved_characters, saved_bytes, summary["exact_contiguous_occurrences"]) == (5270, 5284, 0)
assert summary["potential_removed_characters"] == summary["potential_removed_utf8_bytes"] == 0
assert all(hashlib.sha256(path.read_bytes()).hexdigest() == input_hashes[str(path.relative_to(REPO))] for path in input_paths)
(ROOT / "per-packet-results.json").write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
(ROOT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
print(json.dumps(summary, indent=2))
