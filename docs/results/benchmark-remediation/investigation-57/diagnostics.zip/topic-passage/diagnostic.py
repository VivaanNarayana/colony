"""Frozen same-query/topic-document guard, temporary Store only; no product edits."""

import hashlib
import inspect
import json
import re
import sys
import tempfile
import textwrap
import time
from pathlib import Path
from unittest.mock import patch

BASE = Path.cwd()
DIRECTORY = Path(__file__).parent

EXAMPLES = [
    ("What is the operating temperature range of the humidity probe?",
     "The humidity probe works between minus ten and forty degrees Celsius. Outside that range its measurements are unreliable.",
     "Can the humidity probe operate below zero?", "Does the humidity probe detect carbon monoxide?"),
    ("What happens when a ferry reservation is cancelled?",
     "Cancellation restores the ferry fare to the original payment card on the following business day. No cancellation fee is charged.",
     "Will a cancelled ferry reservation return the payment?", "Will a cancelled ferry reservation renew a passport?"),
    ("Which doors can a visitor badge open?",
     "A visitor badge unlocks the lobby entrance. Laboratory doors remain locked for visitors even during staffed hours.",
     "May a visitor badge unlock the laboratory?", "May a visitor badge authorize a bank transfer?"),
    ("What happens when an exam attempt is interrupted?",
     "Responses already entered remain saved. Resuming the exam attempt restores those responses and the remaining time.",
     "Does interrupting an exam attempt erase its answers?", "Does an exam attempt reveal another student's grade?"),
    ("What is the late arrival policy for a clinic appointment?",
     "The clinic holds the appointment for eight minutes after its scheduled start. Later arrivals must book a new visit.",
     "Is a clinic appointment still held after six minutes?", "Does a clinic appointment include a free blood test?"),
    ("What temperature is required for drone battery charging?",
     "Recharging the drone battery requires an ambient temperature above five degrees Celsius. Charging below that temperature is prohibited.",
     "May a drone battery be recharged below freezing?", "Can a drone battery identify its owner's voice?"),
    ("What happens to notebook edits made without a connection?",
     "The notebook keeps local changes while disconnected. On reconnection it uploads them to the shared copy without discarding them.",
     "Will offline notebook changes survive until synchronization?", "Will offline notebook changes modify a router password?"),
    ("How long does a hearing recorder keep its audio?",
     "Captured sound stays on the hearing recorder for nine days. It is then removed automatically unless an operator exports it first.",
     "When is audio removed from a hearing recorder?", "Does a hearing recorder verify a witness's identity?"),
    ("Which filament diameters fit the desktop printer?",
     "The desktop printer accepts one point seven five millimeter filament only. Thicker feedstock jams the inlet and must not be used.",
     "Can the desktop printer use three millimeter filament?", "Can the desktop printer sterilize surgical instruments?"),
    ("When does a temporary parking permit expire?",
     "A temporary parking permit is valid for forty-eight hours from issuance. Renewing it starts another forty-eight hour period.",
     "Will a temporary parking permit still work three days after issuance?", "Will a temporary parking permit unlock a storage room?"),
]


def save_frozen(name, value):
    payload = (json.dumps(value, indent=2) + "\n").encode()
    (DIRECTORY / f"{name}.json").write_bytes(payload)
    digest = hashlib.sha256(payload).hexdigest()
    (DIRECTORY / f"{name}.sha256").write_text(digest + "\n")
    return digest


def prepare():
    rows = []
    for index, (saved, answer, positive, negative) in enumerate(EXAMPLES, 1):
        for supported, question in [(True, positive), (False, negative)]:
            rows.append(dict(id=f"F{index:02d}-{'positive' if supported else 'negative'}",
                             origin="fresh-preregistered", question=question, positive=supported,
                             records=[dict(question=saved, answer=answer, source=answer)]))
    design = dict(
        extraction="Original incoming [A-Za-z][A-Za-z0-9'-]* tokens whose terms overlap saved-question terms; skip STOP_WORDS; preserve case/order and join spaces",
        application="Only existing positive nonliteral/nonexact/nonprocedural candidates, with nonempty topic terms a proper subset of incoming terms",
        guard="Same original query: answer raw logit strictly above topic-document raw logit; every existing gate retained",
        integration="In-memory copy of current find_answer filters candidates only after original scoring and thresholding; actual Store.ask/fallback unchanged",
        rejection="Any newly lost supported hit or newly unsupported fallback rejects; all baseline errors retained",
        privacy="Each temporary DB includes exact-query private canary; only team namespace queried; excluded content must never reach scorer/output",
        cost="Record all pair counts; no model changes or provider calls; diagnostic scores also reported for inactive candidates",
    )
    fresh_hash = save_frozen("fresh-inputs", dict(design=design, rows=rows))
    # Fresh inputs are frozen BEFORE copying the explicitly nonindependent controls.
    calibration = json.loads((BASE / "work/floor-calibration-56/calibration-cases.json").read_text())
    labels = {r["id"]: r for r in json.loads((BASE / "work/floor-calibration-56/calibration-labels.json").read_text())}
    for case in calibration:
        if case["id"] in {"C03", "C06", "C16"}:
            rows.append(dict(**case, origin="known-nonindependent", positive=labels[case["id"]]["positive"]))
    content = ("After thirty minutes, the login session expires. Users must authenticate again "
               "before continuing. The expiry interval applies to each newly created session.")
    rows.append(dict(id="exact-red-lifetime", origin="known-nonindependent", positive=False,
                     question="Does a login session permit deleting other users?",
                     records=[dict(question="What is the lifetime of a login session?", answer=content, source=content)]))
    digest = save_frozen("inputs", dict(design=design, fresh_sha256=fresh_hash, rows=rows))
    print(json.dumps(dict(fresh=20, known=4, fresh_sha256=fresh_hash, inputs_sha256=digest,
                          frozen_before_models=True)))


def measure():
    from colony import context as context_module
    from colony import store as store_module
    from colony.models import Grant, Scope, Trail
    from colony.retrieval import STOP_WORDS, local_term_support, rank, requires_procedure, terms
    from colony.store import Store
    from colony.validation import snapshot

    payload = (DIRECTORY / "inputs.json").read_bytes()
    digest = hashlib.sha256(payload).hexdigest()
    assert digest == (DIRECTORY / "inputs.sha256").read_text().strip()
    inputs = json.loads(payload)
    cost = dict(pair_entries=0, guard_pair_entries=0, diagnostic_pair_entries=0, provider_calls=0)
    log = []
    guard_log = []

    def counted_rank(question, passages):
        assert not any("PRIVATE_CANARY_57" in p for p in passages)
        scores = rank(question, passages)
        cost["pair_entries"] += len(passages)
        log.append(dict(question=question, passages=passages, scores=scores))
        return scores

    def topic(saved, question):
        selected = [word for word in re.findall(r"[A-Za-z][A-Za-z0-9'-]*", question)
                    if word.casefold() not in STOP_WORDS and terms(word) & terms(saved)]
        document = " ".join(selected)
        return document, bool(terms(document)) and terms(document) < terms(question)

    def extra_guard(question, row, content, score):
        saved = row["question"]
        document, proper = topic(saved, question)
        applies = (proper and not requires_procedure(question)
                   and question.strip().casefold() != saved.strip().casefold()
                   and not local_term_support(terms(question), content[:4000]))
        control = counted_rank(question, [document])[0] if applies else None
        cost["guard_pair_entries"] += int(applies)
        guard_log.append(dict(id=row["id"], topic_document=document, proper_overlap=proper,
                              applied=applies, answer_score=score, topic_score=control,
                              accepted=not applies or score > control))
        return not applies or score > control

    original_method = Store.find_answer
    source = textwrap.dedent(inspect.getsource(original_method))
    needle = "        if not candidates:\n"
    assert source.count(needle) == 1
    source = source.replace(needle,
        "        candidates = [item for item in candidates if _diagnostic_topic_guard(question, item[0], item[1], item[3])]\n" + needle)
    globals_copy = dict(store_module.__dict__, _diagnostic_topic_guard=extra_guard)
    exec(compile(source, "<topic-passage-57-readonly-method>", "exec"), globals_copy)
    candidate_method = globals_copy["find_answer"]
    rows = []
    started = time.perf_counter()
    for case in inputs["rows"]:
        with tempfile.TemporaryDirectory(prefix="colony-topic-passage-57-") as temp:
            root = Path(temp)
            repo = root / "repo"
            repo.mkdir()
            store = Store(root / "db", repo)
            grant = Grant(member_id="diagnostic", name="diagnostic", server="http://localhost",
                          expires_at=int(time.time()) + 3600,
                          scopes=[Scope(namespace=n, push=True, pull=True) for n in ["team", "private"]])
            records = []
            for index, record in enumerate(case["records"]):
                ref = f"source-{index}.md"
                (repo / ref).write_text(record["source"] + "\n", encoding="utf-8")
                trail = Trail(id=hashlib.md5(f"{case['id']}-{index}".encode()).hexdigest(), namespace="team",
                              question=record["question"], content=record["answer"], sources=[snapshot(repo, ref)])
                store.push(trail, grant)
                records.append(dict(**record, id=trail.id))
            private_id = hashlib.md5(f"private-{case['id']}".encode()).hexdigest()
            (repo / "private.md").write_text("PRIVATE_CANARY_57\n")
            store.push(Trail(id=private_id, namespace="private", question=case["question"],
                             content="PRIVATE_CANARY_57 " + case["question"], sources=[snapshot(repo,"private.md")]), grant)
            log.clear()
            guard_log.clear()
            with patch.object(store_module, "rank", counted_rank), patch.object(context_module, "rank", counted_rank):
                baseline = store.ask(case["question"], ["team"], 604800, .60)
                baseline_calls = list(log)
                log.clear()
                with patch.object(Store, "find_answer", candidate_method):
                    candidate = store.ask(case["question"], ["team"], 604800, .60)
                candidate_calls = list(log)
            assert baseline.get("id") != private_id and candidate.get("id") != private_id
            assert "PRIVATE_CANARY_57" not in json.dumps([baseline, candidate, baseline_calls, candidate_calls])
            measurements = []
            for record in records:
                document, proper = topic(record["question"], case["question"])
                scores = rank(case["question"], [record["answer"][:4000], record["question"], document])
                cost["diagnostic_pair_entries"] += 3
                literal = local_term_support(terms(case["question"]), record["answer"][:4000])
                measurements.append(dict(**record, answer_score=scores[0], saved_question_score=scores[1],
                                         topic_document=document, topic_score=scores[2], proper_overlap=proper,
                                         literal_support=literal, procedure=requires_procedure(case["question"]),
                                         original_semantic_pass=literal or requires_procedure(case["question"]) or scores[0] > max(0, scores[1])))
            old_hit = baseline.get("hit", False) and baseline.get("status") == "validated"
            new_hit = candidate.get("hit", False) and candidate.get("status") == "validated"
            rows.append(dict(**case, baseline=baseline, candidate=candidate, measurements=measurements,
                             guard_events=list(guard_log), baseline_calls=baseline_calls, candidate_calls=candidate_calls,
                             lost_positive=case["positive"] and old_hit and not new_hit,
                             new_unsupported_hit=not case["positive"] and not old_hit and new_hit,
                             new_unsupported_fallback=not case["positive"] and candidate.get("match_kind")=="evidence" and baseline.get("match_kind")!="evidence",
                             remaining_unsupported_hit=not case["positive"] and new_hit,
                             old_positive_miss=case["positive"] and not old_hit,
                             private_exclusion_passed=True))
            print(json.dumps({k:rows[-1][k] for k in ["id","origin","positive","lost_positive","new_unsupported_hit","new_unsupported_fallback","remaining_unsupported_hit","old_positive_miss"]}))
    cost["elapsed_seconds"] = time.perf_counter()-started
    output = dict(inputs_sha256=digest, cost=cost, rows=rows,
                  limitation="Actual temporary Store.ask with in-memory candidate-filter insertion; no production edits. Fresh source hashes and age used, not a stale-source race test.")
    (DIRECTORY / "results.json").write_text(json.dumps(output, indent=2)+"\n")
    print(json.dumps(dict(cost=cost, cases=len(rows), lost_positives=sum(r["lost_positive"] for r in rows),
                         new_unsupported_hits=sum(r["new_unsupported_hit"] for r in rows),
                         new_unsupported_fallbacks=sum(r["new_unsupported_fallback"] for r in rows),
                         remaining_unsupported_hits=sum(r["remaining_unsupported_hit"] for r in rows))))


if __name__ == "__main__":
    prepare() if sys.argv[1:] == ["--prepare"] else measure()
