"""Fixed-model Store diagnostic. Calibration never opens holdout label files."""

import ast
import hashlib
import json
import sys
import time
import types
from pathlib import Path


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]


def read_json(name):
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def write_json(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_freeze():
    manifest = read_json("frozen-manifest.json")
    for name, entry in manifest.items():
        path = REPO / "src" / "colony" / name.split("/")[1] if name.startswith("source/") else ROOT / name
        assert sha(path) == entry["sha256"], name


def variant_module():
    path = REPO / "src" / "colony" / "store.py"
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    count = 0
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "max" and len(node.args) == 2:
            if ast.unparse(node) == "max(0.0, topic_scores[i])":
                node.args.insert(0, ast.Name(id="ABSOLUTE_FLOOR", ctx=ast.Load()))
                count += 1
    assert count == 1, count
    ast.fix_missing_locations(tree)
    module = types.ModuleType("floor_diagnostic_store")
    module.__file__ = str(path)
    module.ABSOLUTE_FLOOR = 0
    sys.modules[module.__name__] = module
    exec(compile(tree, str(path), "exec"), module.__dict__)
    return module


def evaluate(receipt, label):
    text = str(receipt.get("content", "")) + "\n" + "\n".join(e["text"] for e in receipt.get("evidence", []))
    sufficient = bool(receipt.get("hit")) and label["positive"] and all(marker.casefold() in text.casefold() for marker in label["required_markers"])
    return {"accepted_positive": bool(sufficient), "false_hit": bool(receipt.get("hit")) and not sufficient, "miss": not bool(receipt.get("hit"))}


def execute(cases, floors, stage):
    import colony.store as baseline
    import colony.context as context
    from colony.models import Grant, Scope, Trail
    from colony.validation import snapshot

    variant = variant_module()
    counters = []
    original_rank = baseline.rank
    original_embed = baseline.embed
    original_passages = baseline.embed_passages

    def rank(question, passages):
        start = time.perf_counter()
        scores = original_rank(question, passages)
        counters.append({"operation": "rank", "question_sha256": hashlib.sha256(question.encode()).hexdigest(), "passage_sha256": [hashlib.sha256(p.encode()).hexdigest() for p in passages], "scores": scores, "seconds": time.perf_counter() - start})
        return scores

    def embed(text, **kwargs):
        start = time.perf_counter()
        result = original_embed(text, **kwargs)
        counters.append({"operation": "embed", "query": kwargs.get("query", False), "text_sha256": hashlib.sha256(text.encode()).hexdigest(), "seconds": time.perf_counter() - start})
        return result

    def passages(texts):
        start = time.perf_counter()
        result = original_passages(texts)
        counters.append({"operation": "embed_passages", "count": len(texts), "seconds": time.perf_counter() - start})
        return result

    baseline.rank = variant.rank = rank
    context.rank = rank
    baseline.embed = variant.embed = embed
    baseline.embed_passages = variant.embed_passages = passages
    results = []
    for case in cases:
        directory = ROOT / "runtime" / stage / case["id"]
        assert not directory.exists(), "No same-stage retries"
        repo = directory / "repo"
        repo.mkdir(parents=True)
        start = time.perf_counter()
        cost_start = len(counters)
        store = baseline.Store(directory / "data", repo)
        grant = Grant(member_id="diagnostic", name="Floor diagnostic", server="http://127.0.0.1", expires_at=4102444800, scopes=[Scope(namespace="diagnostic", push=True, pull=True)])
        for index, record in enumerate(case["records"]):
            ref = f"policy-{index}.md"
            (repo / ref).write_text(record["source"] + "\n", encoding="utf-8")
            trail_id = hashlib.sha256(f"{case['id']}:{index}".encode()).hexdigest()[:32]
            store.push(Trail(id=trail_id, namespace="diagnostic", question=record["question"], content=record["answer"], sources=[snapshot(repo, ref)]), grant)
        setup_cost = {"seconds": time.perf_counter() - start, "operations": counters[cost_start:]}
        for floor in floors:
            start = time.perf_counter()
            cost_start = len(counters)
            try:
                if floor == 0:
                    receipt = store.ask(case["question"], ["diagnostic"], 604800, 0.60)
                else:
                    variant.ABSOLUTE_FLOOR = floor
                    selected = object.__new__(variant.Store)
                    selected.__dict__.update(store.__dict__)
                    receipt = selected.ask(case["question"], ["diagnostic"], 604800, 0.60)
                row = {"id": case["id"], "floor": floor, "receipt": receipt, "error": None}
            except Exception as exc:
                row = {"id": case["id"], "floor": floor, "receipt": {}, "error": repr(exc)}
            row.update({"seconds": time.perf_counter() - start, "operations": counters[cost_start:]})
            results.append(row)
            with (ROOT / f"{stage}-raw.jsonl").open("a", encoding="utf-8") as stream:
                stream.write(json.dumps(row) + "\n")
        write_json(f"{stage}-setup-{case['id']}.json", setup_cost)
        print(json.dumps({"stage": stage, "case": case["id"], "rows": len(floors)}), flush=True)
    return results


def calibration():
    config = read_json("preregistration.json")
    labels = {label["id"]: label for label in read_json("calibration-labels.json")}
    rows = execute(read_json("calibration-cases.json"), config["grid"], "calibration")
    evaluated = [{**row, **evaluate(row["receipt"], labels[row["id"]])} for row in rows]
    baseline = {row["id"]: row for row in evaluated if row["floor"] == 0}
    summaries = []
    for floor in config["grid"]:
        selected = [row for row in evaluated if row["floor"] == floor]
        summaries.append({"floor": floor, "rejected_baseline_false_hits": sum(baseline[row["id"]]["false_hit"] and not row["false_hit"] and row["miss"] for row in selected), "lost_baseline_positives": sum(baseline[row["id"]]["accepted_positive"] and not row["accepted_positive"] for row in selected), "new_false_hits": sum(not baseline[row["id"]]["false_hit"] and row["false_hit"] for row in selected), "errors": sum(row["error"] is not None for row in selected)})
    eligible = [summary for summary in summaries if summary["lost_baseline_positives"] == 0 and summary["errors"] == 0]
    chosen = min(eligible, key=lambda s: (-s["rejected_baseline_false_hits"], s["floor"]))["floor"] if eligible else 0
    selection = {"chosen_floor": chosen, "calibration": summaries, "baseline_accepted_positives": sum(row["accepted_positive"] for row in baseline.values()), "baseline_false_hits": sum(row["false_hit"] for row in baseline.values()), "manifest_sha256": sha(ROOT / "frozen-manifest.json"), "holdout_labels_loaded": False}
    write_json("selection.json", selection)
    (ROOT / "selection.sha256").write_text(sha(ROOT / "selection.json") + "\n", encoding="ascii")
    write_json("calibration-evaluated.json", evaluated)
    print(json.dumps(selection), flush=True)


def holdout():
    assert sha(ROOT / "selection.json") == (ROOT / "selection.sha256").read_text().strip()
    selection = read_json("selection.json")
    floors = list(dict.fromkeys([0, selection["chosen_floor"]]))
    rows = execute(read_json("holdout-cases.json"), floors, "holdout")
    # This is the first holdout-label read, after immutable selection and all predictions.
    labels = {label["id"]: label for label in read_json("holdout-labels.json")}
    evaluated = [{**row, **evaluate(row["receipt"], labels[row["id"]])} for row in rows]
    baseline = {row["id"]: row for row in evaluated if row["floor"] == 0}
    selected = [row for row in evaluated if row["floor"] == selection["chosen_floor"]]
    report = {"chosen_floor": selection["chosen_floor"], "lost_baseline_positives": [row["id"] for row in selected if baseline[row["id"]]["accepted_positive"] and not row["accepted_positive"]], "new_false_hits": [row["id"] for row in selected if not baseline[row["id"]]["false_hit"] and row["false_hit"]], "rejected_baseline_false_hits": [row["id"] for row in selected if baseline[row["id"]]["false_hit"] and row["miss"]], "errors": [row for row in rows if row["error"]], "baseline_accepted_positives": sum(row["accepted_positive"] for row in baseline.values()), "baseline_false_hits": sum(row["false_hit"] for row in baseline.values()), "selection_sha256": sha(ROOT / "selection.json")}
    report["procedure_rejected"] = bool(report["lost_baseline_positives"] or report["new_false_hits"] or report["errors"])
    report["recommendation"] = "no change" if report["procedure_rejected"] or selection["chosen_floor"] == 0 else "bounded result only; no production claim"
    write_json("holdout-evaluated.json", evaluated)
    write_json("holdout-report.json", report)
    print(json.dumps(report), flush=True)


def known():
    assert sha(ROOT / "selection.json") == (ROOT / "selection.sha256").read_text().strip()
    selection = read_json("selection.json")
    case = {"id": "motivating-login", "question": "Does a login session permit deleting other users?", "records": [{"question": "What does a login session permit?", "answer": "A login session expires after thirty minutes.", "source": "A login session expires after thirty minutes."}]}
    rows = execute([case], list(dict.fromkeys([0, selection["chosen_floor"]])), "known")
    write_json("known-report.json", {"independent": False, "purpose": "Previously inspected motivating example; excluded from all selection and heldout criteria", "selection_sha256": sha(ROOT / "selection.json"), "rows": rows})
    print(json.dumps({"known_only": True, "chosen_floor": selection["chosen_floor"], "hits": [row["receipt"].get("hit") for row in rows]}), flush=True)


if __name__ == "__main__":
    verify_freeze()
    {"calibration": calibration, "holdout": holdout, "known": known}[sys.argv[1]]()
