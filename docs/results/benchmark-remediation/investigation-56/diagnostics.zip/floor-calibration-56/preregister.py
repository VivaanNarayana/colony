"""Author and freeze diagnostic inputs before importing any retrieval models."""

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def case(cid, saved, answer, question, positive, markers=(), *, extra=None, source=None):
    records = [{"question": saved, "answer": answer, "source": source or answer}]
    if extra:
        records.append({"question": extra[0], "answer": extra[1], "source": extra[1]})
    return (
        {"id": cid, "question": question, "records": records},
        {"id": cid, "positive": positive, "required_markers": list(markers)},
    )


calibration = [
    case("C01", "What is the valley train baggage weight allowance?", "Each valley train traveler may bring one suitcase weighing seventeen kilograms or less.", "How heavy may a valley train passenger's suitcase be?", True, ["seventeen"]),
    case("C02", "Can museum ticket holders leave and return?", "A museum admission ticket remains usable for return visits until the gates close that day.", "May a museum visitor reenter after stepping outside?", True, ["until the gates close"], extra=("What does the museum audio guide cost?", "The museum audio guide costs four coins per visitor.")),
    case("C03", "When is opening the pottery kiln safe?", "The chamber must cool below sixty degrees Celsius before its door is opened.", "At what temperature can the pottery kiln door be opened safely?", True, ["sixty"]),
    case("C04", "How does the nursery seed germination guarantee work?", "The nursery seed guarantee applies to packets sold by the nursery.", "What does the seed warranty promise if sprouting fails?", True, ["twenty-one", "replacement"], source="Keep the nursery purchase receipt. If no seedlings emerge within twenty-one days, the nursery provides a replacement packet without charge."),
    case("C05", "Is orchard sorbet suitable for avoiding milk?", "Orchard sorbet contains only fruit puree, water and sugar. It has no animal-derived ingredients.", "Which orchard dessert is suitable for a dairy-free diet?", True, ["fruit puree", "no animal-derived"]),
    case("C06", "When must bicycles be collected after the ferry docks?", "Passengers should retrieve their bicycles before the last crew member leaves, except when harbor staff arrange overnight storage.", "How late may a ferry passenger leave a bicycle aboard?", True, ["last crew member", "overnight storage"]),
    case("C07", "What is the climbing wall minimum age?", "Participants must be eleven years old to use the climbing wall.", "What is the climbing wall minimum age?", True, ["eleven"]),
    case("C08", "How is the violin bow made?", "The violin bow material is pernambuco wood, with horsehair for the string-contact surface.", "Which material forms the violin bow?", True, ["pernambuco"]),
    case("C09", "What access does the greenhouse sensor provide?", "The greenhouse sensor reports a fresh temperature measurement every ninety seconds.", "Can the greenhouse sensor open roof vents?", False),
    case("C10", "What does the cafe membership include?", "Cafe membership renews its billing automatically on the first Monday of each month.", "Does cafe membership give discounts on drinks?", False, extra=("Where are cafe membership receipts delivered?", "Cafe membership receipts are sent by email after billing.")),
    case("C11", "What are the wheelchair ramp specifications?", "The wheelchair ramp has a maximum load rating of two hundred kilograms.", "What slope does the wheelchair ramp have?", False),
    case("C12", "What activities does the camping permit cover?", "A camping permit is valid from the opening of spring season until the autumn closing date.", "Does a camping permit allow fishing in the lake?", False),
    case("C13", "What does the regional library card offer?", "A regional library card permits eight simultaneous book loans.", "How much does replacing a regional library card cost?", False),
    case("C14", "How does the school bus ticket work?", "The school bus ticket expires at midnight on the date of purchase.", "Can the school bus ticket be transferred to another child?", False),
    case("C15", "What are the garden watering valve characteristics?", "The garden watering valve requires a supply pressure of at least two bars.", "What diameter is the garden watering valve?", False),
    case("C16", "What are the charter radio operating limits?", "The charter radio battery takes five hours to charge fully.", "How far can the charter radio transmit?", False),
]

holdout = [
    case("H01", "When should the countertop filter cartridge be replaced?", "Replace the cartridge after it has processed nine hundred liters, or after six months, whichever comes first.", "How long can the countertop water filter cartridge remain in service?", True, ["nine hundred", "six months"]),
    case("H02", "How long will the planetarium hold a reserved seat?", "Reserved seats are held until five minutes before the planetarium show begins; after that they are released to waiting visitors.", "When does a late planetarium visitor lose their reserved seat?", True, ["five minutes", "released"]),
    case("H03", "Which snow conditions suit the violet ski wax?", "The violet blend works when the snow surface is between minus four and minus twelve degrees Celsius.", "What temperature range is appropriate for violet ski wax?", True, ["minus four", "minus twelve"]),
    case("H04", "What does the handmade clock repair warranty cover?", "The clock repair warranty covers correction of workmanship faults.", "Who pays carriage when the repaired clock needs warranty work?", True, ["outbound", "return"], source="For a workmanship fault, the owner pays outbound shipping to the clockmaker. The clockmaker pays return shipping after the covered repair."),
    case("H05", "Are dogs admitted to the lighthouse exhibition?", "Pet dogs cannot enter the exhibition. Trained assistance animals may accompany their handlers.", "Is a dog allowed inside the lighthouse exhibition?", True, ["pet dogs cannot", "assistance animals"], extra=("What are the lighthouse exhibition opening hours?", "The lighthouse exhibition is open between ten in the morning and five in the afternoon.")),
    case("H06", "How should the embroidered table linen be cleaned?", "Choose a cool hand wash with mild soap. Keep the cloth out of the tumble dryer and dry it flat in shade.", "Which washing and drying method protects the embroidered table linen?", True, ["cool hand wash", "dry it flat"]),
    case("H07", "On which date does the rowing club vote?", "The rowing club vote takes place on November the seventh.", "On which date does the rowing club vote?", True, ["november the seventh"]),
    case("H08", "How is the ceramic mug finished?", "The ceramic mug finish is a transparent lead-free glaze.", "Which finish coats the ceramic mug?", True, ["lead-free glaze"]),
    case("H09", "What does the campsite wristband authorize?", "The campsite wristband remains valid for two consecutive days after issue.", "Does a campsite wristband authorize boat hire?", False),
    case("H10", "What distinguishes the bakeshop loaves?", "The bakeshop loaves spend thirty-five minutes in the oven.", "Which bakeshop loaves contain peanuts?", False),
    case("H11", "What can the mountain trail locator do?", "The mountain trail locator battery lasts for eighteen hours in tracking mode.", "Can the mountain trail locator call emergency services?", False),
    case("H12", "What are the caravan locker limits?", "The caravan lockers are weatherproof against driven rain.", "How many tools fit in a caravan locker?", False),
    case("H13", "What does the aquarium membership provide?", "Aquarium membership is billed monthly through an automatic bank debit.", "Does aquarium membership cover entry for guests?", False, extra=("When does aquarium membership billing begin?", "Aquarium membership billing begins on the day the application is approved.")),
    case("H14", "What features does the station audio guide offer?", "The station audio guide takes two hours to charge from an empty battery.", "Which languages does the station audio guide support?", False),
    case("H15", "What does a regional park permit include?", "A regional park permit remains valid through the last day of its printed month.", "Does a regional park permit include vehicle parking?", False),
    case("H16", "What should visitors know about the herbal cordial?", "The herbal cordial is stored in brown glass bottles away from sunlight.", "Which botanicals are used in the herbal cordial?", False),
]


def write_json(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


for name, examples in [("calibration", calibration), ("holdout", holdout)]:
    assert len(examples) == 16 and sum(label["positive"] for _, label in examples) == 8
    write_json(f"{name}-cases.json", [data for data, _ in examples])
    write_json(f"{name}-labels.json", [label for _, label in examples])
write_json("preregistration.json", {
    "grid": [0, 1, 2, 4, 8],
    "variant": "Only semantic-answer-support branch additionally requires answer_logit > floor; existing strict answer > question-only control unchanged; exact/literal cases unchanged.",
    "selection": "Using calibration labels only: maximize rejected baseline false hits with zero losses of baseline-correct accepted positive cases, then choose lowest floor. If no fresh calibration false hit is rejected, choose zero. No retuning after holdout.",
    "heldout_rejection": "Any loss of a baseline-correct heldout positive, any new heldout false hit, or any execution error rejects the procedure. No resampling or case exclusions.",
    "oracle": "A positive is sufficiently answered only by a hit containing all preregistered markers in content/evidence. Any other hit is a false hit; a negative hit is always a false hit. All misses, errors and costs retained.",
    "independence": "32 newly authored cases, no reused fixtures. Holdout labels are in a separate file never loaded by the calibration process. Same author; not independent blind grading or production-representative evidence.",
    "scope": "Actual Store.push and Store.ask for every case, including multiple candidates and source fallback; no mocked model scores or forced winner; motivating known session tested only after selection.",
    "exclusions": [],
})
model_root = Path("C:/Users/b3vel/Documents/Codex/2026-10-19/colony-summary-what-it-is-colony/work/colony-models")
model_files = {}
for directory in ["embed", "rank"]:
    for path in sorted((model_root / directory).rglob("*")):
        if path.is_file():
            model_files[str(path.relative_to(model_root))] = {"bytes": path.stat().st_size, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
write_json("model-files.json", {"root": str(model_root), "files": model_files})
manifest = {}
for name in ["preregister.py", "diagnostic.py", "preregistration.json", "model-files.json", "calibration-cases.json", "calibration-labels.json", "holdout-cases.json", "holdout-labels.json"]:
    data = (ROOT / name).read_bytes()
    manifest[name] = {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
for name in ["store", "retrieval", "context", "validation", "models", "security"]:
    path = ROOT.parents[1] / "src" / "colony" / f"{name}.py"
    manifest[f"source/{name}.py"] = {"sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
write_json("frozen-manifest.json", manifest)
print(json.dumps({"frozen_manifest_sha256": hashlib.sha256((ROOT / "frozen-manifest.json").read_bytes()).hexdigest(), "cases": 32}))
