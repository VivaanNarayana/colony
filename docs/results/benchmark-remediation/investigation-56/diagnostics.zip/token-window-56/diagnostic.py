"""Paired-token visibility audit; existing models/admission remain unchanged."""

import hashlib
import json
import tempfile
import time
import uuid
from pathlib import Path

import numpy as np

from colony.models import Grant, Scope, Trail
from colony.retrieval import embed, fused_score, local_term_support, models, passage, rank, terms
from colony.store import Store
from colony.validation import snapshot

DIRECTORY = Path(__file__).parent
QUESTION = "Does a login session permit deleting other users?"
SAVED = "What does a login session permit?"
PREFIX = "A login session expires after thirty minutes." + " Status note." * 220
SUPPORTED = "A login session does not permit deleting other users; deletion requires an administrator."
UNSUPPORTED = (
    'The phrase "login session permit deleting other users" is an index label; '
    "this record does not document deletion permissions."
)


def cosine(left, right):
    left, right = np.frombuffer(left, np.float32), np.frombuffer(right, np.float32)
    return float(left @ right / (np.linalg.norm(left) * np.linalg.norm(right)))


def main():
    _, reranker = models()
    engine = reranker.model
    long_prefix = "A login session expires after thirty minutes." + " Status note." * 340
    cases = [
        ("unrelated-prefix", PREFIX, False, "current"),
        ("unsupported-echo-inside-display", PREFIX + "\n\n" + UNSUPPORTED, False, "current"),
        ("supported-tail-inside-display", PREFIX + "\n\n" + SUPPORTED, True, "current"),
        ("supported-visible-prefix", SUPPORTED + "\n\n" + PREFIX, True, "current"),
        ("supported-tail-after-display", long_prefix + "\n\n" + SUPPORTED, True, "current"),
        ("supported-tail-stale-source", PREFIX + "\n\n" + SUPPORTED, True, "stale"),
        ("supported-tail-ungranted-scope", PREFIX + "\n\n" + SUPPORTED, True, "scope"),
    ]
    rows = []
    for name, content, sufficient, state in cases:
        document = content[:4000]
        encoding = engine.tokenize([(QUESTION, document)])[0]
        doc_indices = [i for i, ((begin, end), type_id, attention) in enumerate(zip(
            encoding.offsets, encoding.type_ids, encoding.attention_mask, strict=True
        )) if type_id == 1 and end > begin and attention]
        doc_end = max(encoding.offsets[i][1] for i in doc_indices)
        visible = document[:doc_end]
        paired_input_hash = hashlib.sha256(np.array(encoding.ids, np.int64).tobytes()).hexdigest()
        full_score, control_score = rank(QUESTION, [document, SAVED])
        query = embed(QUESTION, query=True)
        qcos = cosine(query, embed(SAVED, query=True))
        acos = cosine(query, embed(passage(SAVED, content)))
        with tempfile.TemporaryDirectory(prefix="colony-token-window-") as temp:
            root = Path(temp)
            repo = root / "repo"
            repo.mkdir()
            (repo / "policy.md").write_text(content + "\n", encoding="utf-8")
            source = snapshot(repo, "policy.md")
            store = Store(root / "data", repo)
            grant = Grant(member_id="diagnostic", name="Diagnostic", server="http://127.0.0.1:7331",
                          expires_at=int(time.time()) + 3600,
                          scopes=[Scope(namespace="team", push=True, pull=True)])
            store.push(Trail(id=uuid.uuid4().hex, namespace="team", question=SAVED, content=content,
                             sources=[source]), grant)
            if state == "stale":
                (repo / "policy.md").write_text("The source was replaced.\n", encoding="utf-8")
            result = store.ask(QUESTION, ["private"] if state == "scope" else ["team"], 604800, .60)
            fallback = store.find_evidence(QUESTION, ["private"] if state == "scope" else ["team"], 604800)
        rows.append(dict(
            name=name, expected_sufficient=sufficient, source_state=state, content=content,
            content_chars=len(content), displayed_chars=len(document), paired_document_end=doc_end,
            paired_token_count=len(encoding.ids), paired_input_ids_sha256=paired_input_hash,
            paired_document_tokens=[dict(token=encoding.tokens[i], offset=list(encoding.offsets[i])) for i in doc_indices],
            model_visible_document=visible,
            literal_in_display=local_term_support(terms(QUESTION), document),
            literal_in_model_visible=local_term_support(terms(QUESTION), visible),
            full_score=full_score, saved_question_control_score=control_score,
            query_question_cosine=qcos, query_answer_cosine=acos,
            relevance=fused_score(max(qcos, acos), full_score),
            actual_store_result=result, direct_source_fallback=fallback,
            lexical_boundary_objection="Displayed text is independently available lexical evidence; model visibility is not inherently a truth boundary.",
        ))
    output = dict(question=QUESTION, saved_question=SAVED,
                  tokenizer_truncation=engine.tokenizer.truncation,
                  tokenizer_padding=engine.tokenizer.padding, rows=rows)
    (DIRECTORY / "diagnostic.json").write_text(json.dumps(output, indent=2) + "\n", encoding="utf-8")
    for row in rows:
        result, fallback = row["actual_store_result"], row["direct_source_fallback"] or {}
        print(json.dumps(dict(
            name=row["name"], content_chars=row["content_chars"], displayed_chars=row["displayed_chars"],
            paired_document_end=row["paired_document_end"], paired_token_count=row["paired_token_count"],
            paired_input_ids_sha256=row["paired_input_ids_sha256"], literal_in_display=row["literal_in_display"],
            literal_in_model_visible=row["literal_in_model_visible"], full_score=row["full_score"],
            control_score=row["saved_question_control_score"], relevance=row["relevance"],
            actual_hit=result.get("hit"), actual_kind=result.get("match_kind"), actual_status=result.get("status"),
            fallback_hit=fallback.get("hit"), fallback_kind=fallback.get("match_kind"),
            fallback_includes_supported_fact=SUPPORTED in fallback.get("content", ""),
        )))


if __name__ == "__main__":
    main()
