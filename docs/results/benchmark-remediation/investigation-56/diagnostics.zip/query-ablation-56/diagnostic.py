"""One fixed query-term attribution filter in the actual Store selector."""

import ast
import hashlib
import importlib.util
import json
import re
import sys
import time
import types
from pathlib import Path


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
attributions = []


def read(name):
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def write(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def verify():
    for name, item in read("frozen-manifest.json").items():
        assert hashlib.sha256(Path(item["path"]).read_bytes()).hexdigest() == item["sha256"], name


def term_spans(query):
    from colony.retrieval import terms
    expanded, original = [], []
    for index, character in enumerate(query):
        if index and "a" <= query[index - 1] <= "z" and "A" <= character <= "Z":
            expanded.append(" ")
            original.append(None)
        for lowered in character.lower():
            expanded.append(lowered)
            original.append(index)
    spans = {}
    for match in re.finditer(r"[a-z][a-z0-9]+", "".join(expanded)):
        for term in terms(match.group()):
            positions = [position for position in original[match.start():match.end()] if position is not None]
            spans.setdefault(term, []).append((min(positions), max(positions) + 1))
    assert set(spans) == terms(query), (query, set(spans), terms(query))
    return spans


def support(query, saved_question, answer, full_score):
    from colony.retrieval import rank, terms
    novel = sorted(terms(query) - terms(saved_question))
    details = []
    spans = term_spans(query)
    for term in novel:
        characters = list(query)
        for start, end in spans[term]:
            characters[start:end] = " " * (end - start)
        ablated = re.sub(r"\s+", " ", "".join(characters)).strip()
        start = time.perf_counter()
        score = rank(ablated, [answer])[0]
        details.append({"term": term, "removed_spans": spans[term], "ablated_query": ablated, "full_query_logit": full_score, "ablated_query_logit": score, "full_greater": full_score > score, "seconds": time.perf_counter() - start})
    accepted = not novel or sum(row["full_greater"] for row in details) > len(novel) / 2
    event = {"query": query, "saved_question": saved_question, "answer_sha256": hashlib.sha256(answer.encode()).hexdigest(), "novel_terms": novel, "terms": details, "accepted": accepted}
    attributions.append(event)
    with (ROOT / "attributions.jsonl").open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(event) + "\n")
    return accepted


def variant_module():
    path = REPO / "src" / "colony" / "store.py"
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))

    class AddGuard(ast.NodeTransformer):
        count = 0

        def visit_Compare(self, node):
            self.generic_visit(node)
            if ast.unparse(node) != "item[3] > max(0.0, topic_scores[i])":
                return node
            self.count += 1
            call = ast.parse("query_term_support(question, rows[i]['question'], contents[i][:4000], item[3])", mode="eval").body
            return ast.BoolOp(op=ast.And(), values=[node, call])

    transform = AddGuard()
    tree = transform.visit(tree)
    assert transform.count == 1, transform.count
    ast.fix_missing_locations(tree)
    module = types.ModuleType("query_ablation_store")
    module.__file__ = str(path)
    module.query_term_support = support
    sys.modules[module.__name__] = module
    exec(compile(tree, str(path), "exec"), module.__dict__)
    return module


def runner():
    path = ROOT.parent / "floor-calibration-56" / "diagnostic.py"
    spec = importlib.util.spec_from_file_location("frozen_store_diagnostic_runner", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.ROOT = ROOT
    module.REPO = REPO
    module.variant_module = variant_module
    return module


def phase(name, engine):
    before = len(attributions)
    rows = engine.execute(read(f"{name}-cases.json"), [0, 1], name)
    labels = {row["id"]: row for row in read(f"{name}-labels.json")}
    evaluated = [{**row, **engine.evaluate(row["receipt"], labels[row["id"]])} for row in rows]
    baseline = {row["id"]: row for row in evaluated if row["floor"] == 0}
    variants = [row for row in evaluated if row["floor"] == 1]
    losses = [row["id"] for row in variants if baseline[row["id"]]["accepted_positive"] and not row["accepted_positive"]]
    new_unsupported = [row["id"] for row in variants if row["false_hit"] and (not baseline[row["id"]]["false_hit"] or (row["receipt"].get("match_kind"), row["receipt"].get("id")) != (baseline[row["id"]]["receipt"].get("match_kind"), baseline[row["id"]]["receipt"].get("id")))]
    report = {"phase": name, "baseline_accepted_positive": sum(row["accepted_positive"] for row in baseline.values()), "baseline_false_hits": [row["id"] for row in baseline.values() if row["false_hit"]], "positive_losses": losses, "new_unsupported_hits": new_unsupported, "rejected_false_hits": [row["id"] for row in variants if baseline[row["id"]]["false_hit"] and row["miss"]], "errors": [row for row in evaluated if row["error"]], "attribution_candidate_calls": len(attributions) - before, "extra_rerank_pairs": sum(len(row["terms"]) for row in attributions[before:])}
    report["rejected"] = bool(losses or new_unsupported or report["errors"])
    write(f"{name}-evaluated.json", evaluated)
    write(f"{name}-report.json", report)
    print(json.dumps(report), flush=True)
    return report


if __name__ == "__main__":
    verify()
    engine = runner()
    fresh = phase("fresh", engine)
    # Only after all fresh predictions and results, run known non-independent controls.
    controls = phase("control", engine)
    write("report.json", {"recommendation": "reject candidate; no production change" if fresh["rejected"] or controls["rejected"] else "no generalizability claim; bounded evidence only", "fresh": fresh, "nonindependent_controls": controls, "limitations": ["Cross-query logits do not have a demonstrated common attribution scale.", "Synthetic cases and same-author labels are not independent blind or general recall evidence.", "No procedure retuning, resampling, or exclusions.", "Private generated runtime database/storage.key files must not be published."]})
