"""Freeze one query-attribution procedure and sixteen fresh cases before models."""

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]


def case(cid, saved, answer, question, positive, markers=(), *, source=None, extra=None):
    records = [{"question": saved, "answer": answer, "source": source or answer}]
    if extra:
        records.append({"question": extra[0], "answer": extra[1], "source": extra[1]})
    return ({"id": cid, "question": question, "records": records}, {"id": cid, "positive": positive, "required_markers": list(markers)})


fresh = [
    case("A01", "What happens when a workshop instructor cancels?", "The workshop organizer returns the entire payment within ten working days if the instructor cancels.", "Will a cancelled workshop's registration payment be refunded?", True, ["entire payment", "ten working days"]),
    case("A02", "Is community allotment access restricted by time?", "Residents may enter the neighborhood allotment between sunrise and sunset.", "Which hours can residents use the neighborhood allotment?", True, ["sunrise", "sunset"]),
    case("A03", "When does the ornamental fountain run?", "The fountain jets stop automatically below freezing and resume once the air warms above zero degrees.", "Does the ornamental fountain keep operating during frost?", True, ["stop", "below freezing"]),
    case("A04", "How does pausing the magazine delivery subscription work?", "A magazine delivery subscription may be paused for a whole number of weeks.", "What happens to the magazine subscription fee while delivery is paused?", True, ["no payment", "skipped weeks"], source="No payment is collected for skipped weeks. Billing resumes when magazine delivery restarts."),
    case("A05", "What identification is required for the chamber music event?", "Every printed chamber music event ticket must be accompanied by photo identification at the entrance.", "Can a printed chamber music event ticket be used without proof of identity?", True, ["must be accompanied", "photo identification"]),
    case("A06", "What happens to the cabin rental deposit after inspection?", "After a clean inspection, the cabin rental deposit goes back to the original payment card within seven days. Documented damage costs are deducted first.", "How are cabin rental deposits returned after inspection?", True, ["original payment card", "seven days", "damage costs"], extra=("What does a cabin rental cleaning inspection cost?", "A cabin rental cleaning inspection costs twenty crowns when booked separately.")),
    case("A07", "Can the cork wall covering tolerate cleaning?", "The cork wall covering can be wiped with a damp cloth but must not be soaked.", "Is the cork wall covering washable without immersion?", True, ["damp cloth", "must not be soaked"]),
    case("A08", "What craft are covered by the lake paddling permit?", "The lake paddling permit covers both canoes and rowing boats; powered craft need a different permit.", "Does a lake paddling permit cover a canoe and a rowing boat together?", True, ["both canoes and rowing boats", "powered craft"]),
    case("A09", "What does the chess club subscription provide?", "The chess club subscription fee is collected on the fifteenth day of every month.", "Does a chess club subscription include lessons for adult beginners?", False),
    case("A10", "What are the courtyard umbrella specifications?", "The courtyard umbrella canopy is made from waterproof polyester fabric.", "What diameter is the courtyard umbrella canopy?", False),
    case("A11", "What are the art printer ink cartridge characteristics?", "The art printer ink cartridge contains pigment-based cyan ink.", "How many times may the art printer ink cartridge be refilled?", False),
    case("A12", "What protection comes with the piano hire agreement?", "The piano hire agreement includes accidental damage insurance.", "How far does delivery under the piano hire agreement extend?", False, extra=("When is the piano hire insurance premium collected?", "The piano hire insurance premium is collected with the first rental payment.")),
    case("A13", "What benefits does the sleeper rail pass offer?", "The sleeper rail pass stays valid for six consecutive days after activation.", "Does the sleeper rail pass include free lounge access?", False),
    case("A14", "What are the household recycling tote specifications?", "The household recycling tote holds forty liters of loose material.", "Which colors are available for the household recycling tote?", False),
    case("A15", "What does the evening language class provide?", "The evening language class meets on Tuesdays and Thursdays at seven o'clock.", "Are recordings included with the evening language class?", False),
    case("A16", "What should customers know about the farm produce share?", "The farm produce share is delivered before noon each Friday.", "Is everything in the farm produce share certified organic?", False),
]


def write(name, data):
    (ROOT / name).write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


assert len(fresh) == 16 and sum(label["positive"] for _, label in fresh) == 8
write("fresh-cases.json", [data for data, _ in fresh])
write("fresh-labels.json", [label for _, label in fresh])
floor = ROOT.parent / "floor-calibration-56"
prior_cases = {row["id"]: row for row in json.loads((floor / "calibration-cases.json").read_text())}
prior_labels = {row["id"]: row for row in json.loads((floor / "calibration-labels.json").read_text())}
controls = [case("known-lifetime", "What is the lifetime of a login session?", "After thirty minutes, the login session expires. Users must authenticate again before continuing. The expiry interval applies to each newly created session.", "Does a login session permit deleting other users?", False)]
controls += [(prior_cases[cid], prior_labels[cid]) for cid in ["C03", "C06", "C16"]]
write("control-cases.json", [data for data, _ in controls])
write("control-labels.json", [label for _, label in controls])
write("preregistration.json", {
    "fresh_cases": 16, "fresh_positive": 8, "fresh_negative": 8,
    "nonindependent_controls_after_fresh": ["known-lifetime", "C03", "C06", "C16"],
    "rule": "Only after all current nonliteral/nonexact semantic guards pass, novel_terms = terms(query) - terms(saved_question). For every novel term remove all original word spans mapping to that term under the existing stemming/stopword rules; rerank the unchanged answer prefix with that ablated query. Require full-query logit strictly greater than ablated-query logit for strictly more than half the novel terms. If none, preserve original acceptance. No epsilon, floor, threshold selection, residual/topic removal or score substitution.",
    "punctuation": "Replicate current lowercase/camelCase split and [a-z][a-z0-9]+ token spans with an original-character map. Use existing terms(token) for stopword/stem membership. Replace matching original spans with spaces, collapse whitespace, retain all punctuation and all other characters. Do not repair grammar or delete punctuation.",
    "rejection": "Any baseline-correct accepted positive loss, execution error, new false hit, or newly exposed unsupported candidate/source-fallback hit rejects the candidate. A changed (match_kind,id) false hit is newly exposed even if baseline already had another false hit.",
    "oracle": "Positive acceptance requires hit=true and every frozen marker in returned content/evidence; all other hits are unsupported. Negative hits are always unsupported. All misses/errors/costs retained.",
    "limitations": "Feature attribution hypothesis; cross-query logits may not share a reliable scale. Same author labels, no blind or general recall claim. Controls do not provide independent evidence.",
    "selection": "None. One fixed procedure. No adjustments, resampling or case exclusions.",
    "exclusions": [],
})
files = {name: ROOT / name for name in ["preregister.py", "diagnostic.py", "fresh-cases.json", "fresh-labels.json", "control-cases.json", "control-labels.json", "preregistration.json"]}
files["dependency/floor_runner"] = floor / "diagnostic.py"
files["dependency/model_files"] = floor / "model-files.json"
for name in ["store", "retrieval", "context", "validation", "models", "security"]:
    files[f"source/{name}"] = REPO / "src" / "colony" / f"{name}.py"
manifest = {name: {"path": str(path), "bytes": path.stat().st_size, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()} for name, path in files.items()}
write("frozen-manifest.json", manifest)
print(json.dumps({"frozen_manifest_sha256": hashlib.sha256((ROOT / "frozen-manifest.json").read_bytes()).hexdigest(), "fresh": 16, "controls": 4}))
