"""One preregistered evidence-free control template; no runtime modifications."""

import hashlib
import json
import sys
from pathlib import Path

DIRECTORY = Path(__file__).parent
TEMPLATE = "{saved_question}\nThe requested facts are not provided in this response."
EXAMPLES = [
    (
        "What is the schema migration rollback procedure?",
        "Run migrator rewind --one to restore the preceding schema revision. Rewinding preserves the migration audit history.",
        "How can the previous database layout be restored?",
        "Which encryption key protects migration audit records?",
    ),
    (
        "What enrollment permissions do guests receive?",
        "Guest identities can read the public roster. Changing group membership is forbidden for them.",
        "Can a guest add somebody to the group?",
        "Can guests approve refund payments?",
    ),
    (
        "How long do signed download links remain usable?",
        "A link is valid for twelve minutes. Once that interval ends, the server rejects it.",
        "Will a download link still work after a quarter of an hour?",
        "Does a download link disclose the creator's street address?",
    ),
    (
        "What happens during a suspended delivery?",
        "Messages wait in the outbox while the route is paused. Resuming the route sends every waiting message.",
        "Does pausing a delivery route throw away queued messages?",
        "Can a delivery route change the recipient's password?",
    ),
    (
        "Which image resolutions are accepted by the projector?",
        "The projector accepts 1280 by 720 and 1920 by 1080 images. Other dimensions are rejected.",
        "Can a 720p image be shown by the projector?",
        "Does the projector erase a connected computer's disk?",
    ),
    (
        "What is the behavior of an aborted purchase?",
        "An aborted purchase restores the full inventory reservation. The card is never charged if authorization has not completed.",
        "Is inventory made available again when a purchase is abandoned?",
        "Can an abandoned purchase grant loyalty membership automatically?",
    ),
    (
        "What is the minimum Python release for the converter?",
        "The converter requires Python 3.11 or later. Earlier runtimes fail the startup check.",
        "Will the converter start under Python 3.10?",
        "Will the converter upload source files to a public server?",
    ),
    (
        "Which storage devices can record audio samples?",
        "Recordings can be saved to a USB drive. An SD card is read-only and cannot receive recordings.",
        "Can the recorder write captured sound onto an SD card?",
        "Can a storage device verify the singer's identity?",
    ),
]


def prepare():
    rows = []
    for index, (saved, content, positive, negative) in enumerate(EXAMPLES):
        for supported, question in [(True, positive), (False, negative)]:
            rows.append(dict(origin="fresh-preregistered", pair=index + 1,
                             saved_question=saved, content=content, question=question,
                             expected_supported=supported))
    payload = (json.dumps(dict(template=TEMPLATE, rows=rows), indent=2) + "\n").encode()
    (DIRECTORY / "inputs.json").write_bytes(payload)
    digest = hashlib.sha256(payload).hexdigest()
    (DIRECTORY / "inputs.sha256").write_text(digest + "\n", encoding="utf-8")
    print(json.dumps(dict(fresh_pairs=8, fresh_cases=16, template=TEMPLATE, sha256=digest,
                         frozen_before_model_calls=True)))


def measure():
    import numpy as np
    from colony.retrieval import embed, fused_score, local_term_support, passage, rank, requires_procedure, terms
    payload = (DIRECTORY / "inputs.json").read_bytes()
    digest = hashlib.sha256(payload).hexdigest()
    assert digest == (DIRECTORY / "inputs.sha256").read_text().strip()
    inputs = json.loads(payload)
    cases = inputs["rows"]
    # Fresh cases are evaluated first; the existing regression is appended last.
    known = "After thirty minutes, the login session expires. Users must authenticate again before continuing. The expiry interval applies to each newly created session."
    for supported, question in [(True, "When does a login session end?"),
                                (False, "Does a login session permit deleting other users?")]:
        cases.append(dict(origin="existing-session-diagnostic", saved_question="What is the lifetime of a login session?",
                          content=known, question=question, expected_supported=supported))
    rows = []
    extra_pairs = 0

    def cosine(left, right):
        left, right = np.frombuffer(left, np.float32), np.frombuffer(right, np.float32)
        return float(left @ right / (np.linalg.norm(left) * np.linalg.norm(right)))

    for case in cases:
        question, saved, content = case["question"], case["saved_question"], case["content"]
        real_score, question_control = rank(question, [content[:4000], saved])
        literal = local_term_support(terms(question), content[:4000])
        exact = question.strip().casefold() == saved.strip().casefold()
        procedure = requires_procedure(question)
        baseline_semantic = exact or procedure or literal or real_score > max(0.0, question_control)
        query = embed(question, query=True)
        qcos = cosine(query, embed(saved, query=True))
        acos = cosine(query, embed(passage(saved, content)))
        relevance = fused_score(max(qcos, acos), real_score)
        eligibility = max(qcos, acos) >= .55 and (qcos >= (.70 if procedure else .65) or exact)
        eligibility = eligibility and (relevance >= .60 or exact)
        applies = baseline_semantic and not (literal or exact or procedure)
        negative_document = inputs["template"].format(saved_question=saved)
        negative_score = rank(question, [negative_document])[0] if applies else None
        extra_pairs += int(applies)
        revised_semantic = baseline_semantic and (not applies or real_score > negative_score)
        baseline, revised = eligibility and baseline_semantic, eligibility and revised_semantic
        rows.append(dict(
            **case, real_score=real_score, question_control_score=question_control,
            literal_support=literal, exact=exact, procedure=procedure,
            original_eligibility=eligibility, query_question_cosine=qcos,
            query_answer_cosine=acos, relevance=relevance,
            negative_control_document=negative_document, negative_control_score=negative_score,
            additional_guard_applied=applies, baseline_semantic=baseline_semantic,
            revised_semantic=revised_semantic, baseline_admitted=baseline, revised_admitted=revised,
            supported_semantic_regression=case["expected_supported"] and baseline_semantic and not revised_semantic,
            supported_admission_regression=case["expected_supported"] and baseline and not revised,
            remaining_false_admission=not case["expected_supported"] and revised,
            guard_context="Current scope/freshness/source checks held fixed, not replaced by this score test.",
        ))
    cost = dict(cases=len(rows), base_rank_pairs=2 * len(rows), extra_control_pairs=extra_pairs,
                query_or_passage_embeddings=3 * len(rows), provider_or_subject_calls=0)
    (DIRECTORY / "results.json").write_text(json.dumps(dict(inputs_sha256=digest, template=inputs["template"], cost=cost, rows=rows), indent=2) + "\n", encoding="utf-8")
    for row in rows:
        print(json.dumps({key: row[key] for key in [
            "origin", "question", "expected_supported", "real_score", "question_control_score",
            "literal_support", "negative_control_score", "original_eligibility",
            "baseline_semantic", "revised_semantic", "baseline_admitted", "revised_admitted",
            "supported_semantic_regression", "supported_admission_regression", "remaining_false_admission",
        ]}))
    print(json.dumps(dict(cost=cost,
                         supported_semantic_regressions=sum(row["supported_semantic_regression"] for row in rows),
                         supported_admission_regressions=sum(row["supported_admission_regression"] for row in rows),
                         remaining_false_admissions=sum(row["remaining_false_admission"] for row in rows))))


if __name__ == "__main__":
    prepare() if sys.argv[1:] == ["--prepare"] else measure()
