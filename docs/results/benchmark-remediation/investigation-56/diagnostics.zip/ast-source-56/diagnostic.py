"""Preregistered complete AST units under existing source retrieval thresholds."""

import ast
import hashlib
import json
import sys
import tempfile
from pathlib import Path

BASE = Path.cwd()
DIRECTORY = Path(__file__).parent
FIXTURES = [
    (
        "archive.py",
        '''def expire_record(record, now):
    """Enforce the archived record retention deadline."""
    if record.legal_hold:
        return "held"

    observed = now
    record.last_checked = observed
    deadline = record.retention_deadline
    record.check_count += 1
    record.last_action = "inspection"
    record.last_error = None
    record.audit_pending = True
    record.expiry_checked = True
    record.lifecycle_checked = True
    record.check_completed = True
    record.last_seen = now

    if now >= deadline:
        return "deleted"
    return "retained"

def encryption_notes():
    # Which encryption algorithm protects archived records?
    # This question is an index label; the algorithm is documented elsewhere.
    return "unspecified"
''',
        "What happens when archived records reach the retention deadline?",
        "Which encryption algorithm protects archived records?",
    ),
    (
        "encoder.py",
        '''def exported_formats(config):
    """Return the image encoder's enabled output formats."""
    formats = ("PNG", "WebP")

    if config.disable_images:
        return ()

    return formats

def upload_limit():
    """Upload capacity is a different attribute."""
    return 16_000_000
''',
        "Which image formats does the encoder export when enabled?",
        "Which encryption algorithm protects the exported images?",
    ),
    (
        "retry.py",
        '''def upload_retry_delay(attempt, server_retry):
    """Select an upload retry delay and enforce the attempt limit."""
    delay = 5

    if server_retry is not None:
        return server_retry

    observed_attempt = attempt
    diagnostics = {}
    diagnostics["attempt"] = observed_attempt
    diagnostics["delay"] = delay
    diagnostics["queued"] = True
    diagnostics["worker"] = "upload"
    diagnostics["state"] = "checked"
    diagnostics["reason"] = None
    diagnostics["complete"] = True

    if attempt >= 3:
        raise ValueError("Retry refused")
    return delay
''',
        "How long does an upload wait before a retry, and when is retry refused?",
        "Does an upload retry change account permissions?",
    ),
    (
        "specimen.py",
        '''def inspect_specimen(specimen):
    """Validate a laboratory specimen."""
    if specimen.expired:
        return "rejected"

    try:
        result = decode_specimen(specimen)
    except ValueError:
        return "invalid"

    if specimen.flagged:
        return "quarantined"
    return result
''',
        "What happens when a laboratory specimen expires or cannot be decoded?",
        "Which cipher encrypts laboratory specimen metadata?",
    ),
    (
        "renderer.py",
        '''class ThumbnailRenderer:
    """Thumbnail image rendering with independent retention metadata."""
    formats = ("PNG", "WebP")

    def supported_formats(self):
        return self.formats

    def retention_days(self):
        return 7

    def receipts(self):
        # Administrator permission receipts are metadata, not grants.
        return {"validation": "current"}
''',
        "Which image formats does the thumbnail renderer support?",
        "Can the thumbnail renderer grant administrator permissions?",
    ),
]


def prepare():
    archive = BASE / "docs/results/benchmark-remediation/attempt-55"
    corpus = BASE.parent / "benchmark-remediation-live-55-runtime/feat/repo"
    traces = json.loads((archive / "research-review.json").read_text(encoding="utf-8"))
    order = json.loads((archive / "feature/metadata.json").read_text(encoding="utf-8"))["task_order"]
    preceding = set(order[:order.index("stale-2")])
    trails = [op["arguments"]["sources"] for row in traces
              if row["arm"] == "feature" and row["task"] in preceding
              for op in row["ops"] if op["tool"] == "push"]
    files = {}
    for sources in trails:
        for source in sources:
            data = (corpus / source["ref"]).read_bytes()
            assert hashlib.sha256(data).hexdigest() == source["content_hash"]
            files[source["ref"]] = data.decode("utf-8")
    rows = [dict(origin="retained-current-source", question="What happens when repository evidence changes?",
                 expected_sufficient=True, files=files, trails=trails)]
    for ref, text, positive, negative in FIXTURES:
        ast.parse(text)
        proof = dict(ref=ref, content_hash=hashlib.sha256(text.encode()).hexdigest(), kind="file")
        for expected, question in [(True, positive), (False, negative)]:
            rows.append(dict(origin="independent-python", question=question, expected_sufficient=expected,
                             files={ref:text}, trails=[[proof]]))
    payload = (json.dumps(rows, indent=2) + "\n").encode()
    (DIRECTORY / "inputs.json").write_bytes(payload)
    digest = hashlib.sha256(payload).hexdigest()
    (DIRECTORY / "inputs.sha256").write_text(digest + "\n", encoding="utf-8")
    print(json.dumps(dict(examples=len(rows), sha256=digest, prepared_before_models=True)))


def measure():
    import numpy as np
    from colony.context import source_chunks, source_lines
    from colony.models import Source
    from colony.retrieval import embed, embed_passages, evidence_score, keyword_coverage, local_term_support, rank, terms
    payload = (DIRECTORY / "inputs.json").read_bytes()
    digest = hashlib.sha256(payload).hexdigest()
    assert digest == (DIRECTORY / "inputs.sha256").read_text().strip()

    def cosine(a,b):
        a,b = np.frombuffer(a,np.float32),np.frombuffer(b,np.float32)
        return float(a@b/(np.linalg.norm(a)*np.linalg.norm(b)))

    rows=[]
    for case in json.loads(payload):
        with tempfile.TemporaryDirectory(prefix="colony-ast-source-") as temp:
            root=Path(temp)
            for ref,text in case["files"].items():
                (root/ref).parent.mkdir(parents=True,exist_ok=True)
                (root/ref).write_bytes(text.encode())
            original,merged={},{}
            unit_inventory=[]
            for source_values in case["trails"]:
                sources=[Source(**s) for s in source_values]
                baseline=source_chunks(root,sources)
                candidates=[dict(kind="paragraph",ref=ref,line=line,text=text) for ref,line,text in baseline]
                additions=[]
                for source in sources[:8]:
                    if not source.ref.endswith(".py"):
                        continue
                    raw=case["files"][source.ref]
                    scrubbed=source_lines(root,source)
                    for node in ast.parse(raw).body:
                        if not isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)):
                            continue
                        start=min([node.lineno]+[d.lineno for d in node.decorator_list])
                        end=node.end_lineno
                        text="\n".join(scrubbed[start-1:end])
                        fits=end<=2000 and len(text)<=2400
                        unit_inventory.append(dict(ref=source.ref,name=node.name,start=start,end=end,
                                                   chars=len(text),fits=fits))
                        if fits and not any(c["ref"]==source.ref and c["line"]==start and c["text"]==text for c in candidates):
                            additions.append(dict(kind="ast",ref=source.ref,line=start,end=end,text=text))
                for c in candidates:
                    original[(c["ref"],c["line"],c["text"])]=c
                for c in (candidates+additions)[:96]:
                    # Distinct typed identities are diagnostic only; current DB keys
                    # cannot safely distinguish overlapping units sharing a start.
                    merged[(c["kind"],c["ref"],c["line"],c["text"])]=c
            question=case["question"]
            query=embed(question,query=True)

            def evaluate(pool):
                candidates=[dict(candidate) for candidate in pool.values()]
                vectors=embed_passages([f"{c['ref']}\n{c['text']}" for c in candidates])
                for c,v in zip(candidates,vectors,strict=True):
                    c["cosine"]=cosine(query,v)
                candidates.sort(key=lambda c:c["cosine"],reverse=True)
                lexical=keyword_coverage(question,[c["text"] for c in candidates])
                dense=[i for i,c in enumerate(candidates) if c["cosine"]>=.45][:24]
                sparse=[i for i in sorted(range(len(lexical)),key=lexical.__getitem__,reverse=True) if lexical[i]>=.15][:24]
                chosen=set(dense)|set(sparse)
                eligible=[i for i in chosen if lexical[i]>=.5 and local_term_support(terms(question),candidates[i]["text"])]
                scores=dict(zip(eligible,rank(question,[candidates[i]["text"] for i in eligible]),strict=True))
                accepted=[]
                for i,c in enumerate(candidates):
                    c.update(lexical=lexical[i],local_support=local_term_support(terms(question),c["text"]),
                             in_candidate_pool=i in chosen,prefilter_pass=i in eligible,score=scores.get(i))
                    c["admitted"]=i in scores and scores[i]>=-5.0
                    if c["admitted"]:
                        c["evidence_score"]=evidence_score(c["cosine"],scores[i],lexical[i])
                        accepted.append(c)
                accepted.sort(key=lambda c:c["evidence_score"],reverse=True)
                return dict(count=len(candidates),admitted=bool(accepted),ordered=accepted,candidates=candidates)

            baseline=evaluate(original)
            augmented=evaluate(merged)
            rows.append(dict(question=question,origin=case["origin"],expected_sufficient=case["expected_sufficient"],
                             units=unit_inventory,baseline=baseline,augmented=augmented,
                             new_unsupported_admission=not case["expected_sufficient"] and not baseline["admitted"] and augmented["admitted"],
                             new_supported_admission=case["expected_sufficient"] and not baseline["admitted"] and augmented["admitted"]))
    (DIRECTORY/"results.json").write_text(json.dumps(dict(inputs_sha256=digest,rows=rows),indent=2)+"\n",encoding="utf-8")
    for r in rows:
        print(json.dumps(dict(question=r["question"],expected=r["expected_sufficient"],
                              baseline_count=r["baseline"]["count"],augmented_count=r["augmented"]["count"],
                              baseline_admitted=r["baseline"]["admitted"],augmented_admitted=r["augmented"]["admitted"],
                              new_unsupported=r["new_unsupported_admission"],new_supported=r["new_supported_admission"],
                              ast_hits=[dict(ref=c["ref"],line=c["line"],score=c["score"],lexical=c["lexical"]) for c in r["augmented"]["ordered"] if c["kind"]=="ast"])))


if __name__=="__main__":
    prepare() if sys.argv[1:]==["--prepare"] else measure()
