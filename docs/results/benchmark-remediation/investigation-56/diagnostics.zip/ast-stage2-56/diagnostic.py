"""Preregistered paragraph-first/function-only fallback selection simulation."""

import hashlib
import json
import sys
from pathlib import Path

BASE = Path.cwd()
DIRECTORY = Path(__file__).parent
GAP = "\n".join(f'    audit["field_{i}"] = None' for i in range(18))
FRAME = '''def ingest_frame(frame):
    """Frame input processing."""
    if not frame.header_valid:
        return "invalid frame header rejected"

    audit = {}
GAP

    try:
        return decode_frame(frame.payload)
    except DecodeError:
        return "decoding error quarantined"
'''.replace("GAP", GAP)
OBJECT = '''def import_object(obj, storage):
    """Object input processing."""
    if obj.digest != obj.expected_digest:
        return "digest differs: rejected"

    audit = {}
GAP

    try:
        return storage.read()
    except OSError:
        return "storage cannot be read: quarantined"
'''.replace("GAP", GAP)
SEPARATED = '''def inspect_mode(mode):
    """Operational inspection."""
    if mode == "inspection":
        encryption_algorithm = "AES-256-GCM"
        return {"inspection_cipher": encryption_algorithm}

    audit = {}
GAP

    if mode == "backup":
        backup_records = read_backups()
        return {"record_count": len(backup_records)}
    return None
'''.replace("GAP", GAP)
UNREACHABLE = '''def export_batches(batches):
    """Batch export processing."""
    audit = {}
GAP

    if False:
        # Encryption of exported batches uses this cipher only in dead example code.
        cipher = "AES-256-GCM"
        return encrypt(batches, cipher)
    return batches
'''.replace("GAP", GAP)
EXTERNAL_DECORATOR = '''@external_policy
def erase_history(editor):
    """Editor document maintenance."""
    audit = {}
GAP

    return erase_document_history(editor)
'''.replace("GAP", GAP)
OVERSIZED = '''def rotate_entries(entries):
    """Entry rotation metadata."""
    audit = {}
''' + "\n".join(f'    audit["opaque_field_{i}"] = "diagnostic formatting information"' for i in range(70)) + '''
    return "rotation settings unspecified"
'''


def prepare():
    def case(name, question, source, sufficient, *, state="current", allowed=True):
        return dict(name=name, origin="fresh-preregistered", question=question,
                    files={"module.py":source}, trails=[[dict(ref="module.py", kind="file",
                    content_hash=hashlib.sha256(source.encode()).hexdigest())]],
                    expected_source_sufficient=sufficient, source_state=state, allowed=allowed,
                    expected_admissible=sufficient and state=="current" and allowed)
    rows = [
        case("frame-exceptions", "What happens on invalid frame headers and decoding errors?", FRAME, True),
        case("object-exceptions", "What happens if an object digest differs or storage cannot be read?", OBJECT, True),
        case("separated-mode-attributes", "Which encryption algorithm protects backup records?", SEPARATED, False),
        case("question-comment-echo", "Which cipher protects archived records?", '''def archive_record(record):
    # Which cipher protects archived records? This is an index question, not a cipher specification.
    return record
''', False),
        case("unreachable-cipher", "Which cipher encrypts exported batches?", UNREACHABLE, False),
        case("external-decorator", "Can a suspended editor erase document history?", EXTERNAL_DECORATOR, False),
        case("defined-decorator", "Can a viewer erase queued reports?", '''def only_supervisors(fn):
    def wrapped(actor):
        if actor.role != "supervisor":
            raise PermissionError("Supervisor required")
        return fn(actor)
    return wrapped

@only_supervisors
def erase_reports(actor):
    """Erase queued reports."""
    return erase(actor.reports)
''', True),
        case("external-helper", "Can suspended accounts renew subscriptions?", '''def renew_subscription(account):
    """Account subscription renewal."""
    return external_policy_allows(account.status, "renew")
''', False),
        case("external-limit", "How many uploads may a worker submit?", '''UPLOAD_LIMIT = settings.UPLOAD_ATTEMPTS

def submit_upload(worker, count):
    """Worker upload submission."""
    if count >= UPLOAD_LIMIT:
        return "rejected"
    return "queued"
''', False),
        case("defined-limit", "How many uploads may a worker submit?", '''UPLOAD_LIMIT = 4

def submit_upload(worker, count):
    """Worker upload submission."""
    if count >= UPLOAD_LIMIT:
        return "rejected"
    return "queued"
''', True),
        case("oversized-unspecified", "Which encryption algorithm protects rotated entries?", OVERSIZED, False),
        case("oversized-positive", "Are entries deleted during rotation?", OVERSIZED.replace('return "rotation settings unspecified"', 'return "entries are never deleted during rotation"'), True),
        case("unused-nested-permission", "Can a support user approve payments?", '''def support_report(user):
    """Support user reporting."""
    audit = {}
GAP

    def approve_payments():
        return True
    return audit
'''.replace("GAP", GAP), False),
        case("invoked-nested-permission", "Can a suspended support user obtain authorization?", '''def authorize_support(user):
    """Support user authorization."""
    def permitted():
        return user.role == "support" and not user.suspended
    return permitted()
''', True),
        case("stale-frame-source", "What happens on invalid frame headers and decoding errors?", FRAME, True, state="stale"),
        case("ungranted-frame-source", "What happens on invalid frame headers and decoding errors?", FRAME, True, allowed=False),
    ]
    # The motivating corpus is evaluated only AFTER all fresh controls.
    previous = json.loads((BASE/"work/ast-source-56/inputs.json").read_text(encoding="utf-8"))[0]
    previous.update(name="motivating-retained-source", origin="motivating-not-independent",
                    expected_source_sufficient=True, source_state="current", allowed=True, expected_admissible=True)
    rows.append(previous)
    design = dict(
        stage1="Unchanged original paragraphs/IDF/scoring/output first; no AST if validated evidence exists",
        stage2="Top-level complete functions/async-functions only; decorators included; no classes; <=2400 chars/end<=2000 lines",
        idf="Original paragraph reference only: 1+log((N+1)/(document_frequency+1)); absent frequency zero",
        selection="Same cosine .45/top24 and sparse .15/top24, coverage .5/local-majority, raw rank >=-5",
        budget="48 scored entries total; stage2 eligible candidates in cosine order capped by remaining entries",
        source="Matching cited sources only, <=8 per trail, scope/age/hash unchanged",
        identity="Ephemeral (ref,hash,start,end,function) identity only; no index migration",
        output="Stage1 payload reused byte-for-byte; stage2 emits whole selected functions within 2/2400/2800 limits",
        limitation="Read-only selection simulation, not Store integration or a new benchmark",
    )
    payload=(json.dumps(dict(design=design,rows=rows),indent=2)+"\n").encode()
    (DIRECTORY/"inputs.json").write_bytes(payload)
    digest=hashlib.sha256(payload).hexdigest()
    (DIRECTORY/"inputs.sha256").write_text(digest+"\n",encoding="utf-8")
    print(json.dumps(dict(fresh=16,motivating=1,sha256=digest,prepared_before_models=True)))


def measure():
    import ast
    import math
    import tempfile
    from collections import Counter
    import numpy as np
    from colony.context import excerpts, source_chunks, source_lines
    from colony.models import Source
    from colony.retrieval import embed, embed_passages, evidence_score, local_term_support, rank, terms
    from colony.validation import validate
    payload=(DIRECTORY/"inputs.json").read_bytes()
    digest=hashlib.sha256(payload).hexdigest()
    assert digest==(DIRECTORY/"inputs.sha256").read_text().strip()

    def cosine(a,b):
        a,b=np.frombuffer(a,np.float32),np.frombuffer(b,np.float32)
        return float(a@b/(np.linalg.norm(a)*np.linalg.norm(b)))

    rows=[]
    total_ce=0
    for case in json.loads(payload)["rows"]:
        with tempfile.TemporaryDirectory(prefix="colony-ast-stage2-") as temp:
            root=Path(temp)
            for ref,text in case["files"].items():
                (root/ref).parent.mkdir(parents=True,exist_ok=True)
                (root/ref).write_bytes(text.encode())
            if case["source_state"]=="stale":
                first=next(iter(case["files"]))
                (root/first).write_bytes(b"# Source replaced\n")
            all_sources={s["ref"]:Source(**s) for trail in case["trails"] for s in trail}
            checks=[validate(root,[Source(**s) for s in trail]) for trail in case["trails"]]
            source_ok=case["allowed"] and all(status=="validated" for status,_ in checks)
            original={}
            if source_ok:
                for trail in case["trails"]:
                    for ref,line,text in source_chunks(root,[Source(**s) for s in trail]):
                        original[(ref,line,text)]=dict(kind="paragraph",ref=ref,line=line,text=text)
            paragraphs=list(original.values())
            query_terms=terms(case["question"])
            frequency=Counter(t for c in paragraphs for t in terms(c["text"]))
            weights={t:1+math.log((len(paragraphs)+1)/(frequency[t]+1)) for t in query_terms}
            total=sum(weights.values())

            def coverage(text):
                return sum(weights[t] for t in query_terms & terms(text))/total if total else 0.0

            query=embed(case["question"],query=True) if source_ok else None

            def score(pool,limit):
                candidates=[dict(c) for c in pool]
                vectors=embed_passages([f"{c['ref']}\n{c['text']}" for c in candidates]) if candidates else []
                for c,v in zip(candidates,vectors,strict=True):
                    c.update(cosine=cosine(query,v),coverage=coverage(c["text"]),local_support=local_term_support(query_terms,c["text"]))
                candidates.sort(key=lambda c:c["cosine"],reverse=True)
                dense=[i for i,c in enumerate(candidates) if c["cosine"]>=.45][:24]
                sparse=[i for i in sorted(range(len(candidates)),key=lambda i:candidates[i]["coverage"],reverse=True) if candidates[i]["coverage"]>=.15][:24]
                eligible=[i for i in sorted(set(dense)|set(sparse)) if candidates[i]["coverage"]>=.5 and candidates[i]["local_support"]][:limit]
                scores=rank(case["question"],[candidates[i]["text"] for i in eligible])
                hits=[]
                for i,value in zip(eligible,scores,strict=True):
                    candidates[i]["score"]=value
                    if value>=-5:
                        c=candidates[i]
                        c["evidence_score"]=evidence_score(c["cosine"],value,c["coverage"])
                        hits.append(c)
                hits.sort(key=lambda c:c["evidence_score"],reverse=True)
                return dict(candidates=candidates,hits=hits,scored=len(eligible),unique_scored=len(set(candidates[i]["text"] for i in eligible)))

            first=score(paragraphs,48)
            original_packet=None
            if first["hits"]:
                best=first["hits"][0]["evidence_score"]
                preferred=[(c["ref"],c["line"]) for c in first["hits"] if c["evidence_score"]>=best-.15][:8]
                sources=list(all_sources.values())
                original_packet=excerpts(root,sources,case["question"],preferred=preferred,section_context=True)
            first_valid=bool(original_packet)
            second=dict(candidates=[],hits=[],scored=0,unique_scored=0)
            units=[]
            inventory=[]
            final_packet=original_packet
            if source_ok and not first_valid:
                for source in list(all_sources.values())[:8]:
                    if not source.ref.endswith(".py"):
                        continue
                    scrubbed=source_lines(root,source)
                    for node in ast.parse(case["files"][source.ref]).body:
                        if not isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
                            continue
                        start=min([node.lineno]+[d.lineno for d in node.decorator_list])
                        end=node.end_lineno
                        text="\n".join(scrubbed[start-1:end])
                        fits=end<=2000 and len(text)<=2400
                        inventory.append(dict(ref=source.ref,start=start,end=end,chars=len(text),fits=fits))
                        if fits:
                            units.append(dict(kind="function",ref=source.ref,line=start,end=end,text=text,
                                              identity=[source.ref,source.content_hash,start,end,"function"]))
                second=score(units[:96],48-first["scored"])
                if second["hits"]:
                    best=second["hits"][0]["evidence_score"]
                    chosen=[]
                    budget=2800
                    for c in second["hits"]:
                        if len(chosen)>=2:
                            break
                        if c["evidence_score"]<best-.15 or len(c["text"])>min(2400,budget):
                            continue
                        chosen.append(dict(ref=c["ref"],line=c["line"],text=c["text"],complete_file=False))
                        budget-=len(c["text"])
                    final_packet=chosen or None
            first_hash=hashlib.sha256(json.dumps(original_packet,sort_keys=True).encode()).hexdigest()
            final_hash=hashlib.sha256(json.dumps(final_packet,sort_keys=True).encode()).hexdigest()
            final_valid=bool(final_packet)
            assert first["scored"]+second["scored"]<=48
            assert not first_valid or first_hash==final_hash
            total_ce+=first["scored"]+second["scored"]
            rows.append(dict(name=case["name"],origin=case["origin"],question=case["question"],
                             expected_admissible=case["expected_admissible"],source_ok=source_ok,checks=checks,
                             idf_reference_count=len(paragraphs),idf_weights=weights,
                             stage1=first,stage2=second,units=inventory,
                             original_packet=original_packet,final_packet=final_packet,
                             original_payload_sha256=first_hash,final_payload_sha256=final_hash,
                             original_validated_success=first_valid,final_validated_success=final_valid,
                             new_false_hit=not case["expected_admissible"] and not first_valid and final_valid,
                             lost_positive=case["expected_admissible"] and first_valid and not final_valid,
                             recovery=case["expected_admissible"] and not first_valid and final_valid,
                             remaining_false_hit=not case["expected_admissible"] and final_valid,
                             limitation="Selection simulation; source eligibility fixed, no real Store/index implementation."))
    output=dict(inputs_sha256=digest,conservative_ce_entries=total_ce,rows=rows)
    (DIRECTORY/"results.json").write_text(json.dumps(output,indent=2)+"\n",encoding="utf-8")
    for r in rows:
        print(json.dumps({k:r[k] for k in ["name","origin","expected_admissible","source_ok","original_validated_success","final_validated_success","new_false_hit","lost_positive","recovery","remaining_false_hit"]}))
    print(json.dumps(dict(fresh=16,motivating=1,new_false_hits=sum(r["new_false_hit"] for r in rows),
                         lost_positives=sum(r["lost_positive"] for r in rows),recoveries=sum(r["recovery"] for r in rows),
                         remaining_false_hits=sum(r["remaining_false_hit"] for r in rows),conservative_ce_entries=total_ce,
                         production_changes=False,provider_calls=0)))


if __name__=="__main__":
    prepare() if sys.argv[1:]==["--prepare"] else measure()
