"""Descriptive paired arithmetic from retained trial56; no new samples or grading."""
import hashlib
import json
from pathlib import Path

root = Path('docs/results/benchmark-remediation/attempt-56')
paths = [root / arm / 'raw-measurements.jsonl' for arm in ('main', 'feature')]
paths.append(root / 'research-review.json')
before = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
arms = {
    arm: {r['task_id']: r for r in map(json.loads, (root / arm / 'raw-measurements.jsonl').read_text(encoding='utf-8').splitlines())}
    for arm in ('main', 'feature')
}
ops = {(r['arm'], r['task']): r['ops'] for r in json.loads(paths[-1].read_text(encoding='utf-8'))}
rows = []
assert arms['main'].keys() == arms['feature'].keys()
for task in arms['main']:
    row = {'task': task}
    for arm in ('main', 'feature'):
        raw = arms[arm][task]
        usage = raw['usage']
        row[arm] = {
            'gross': raw['tokens'],
            'uncached': usage['input_tokens'] - usage['cached_input_tokens'] + usage['output_tokens'],
            'seconds': raw['seconds'],
            'research_calls': sum(o['tool'] != 'push' for o in ops.get((arm, task), [])),
            'push_calls': sum(o['tool'] == 'push' for o in ops.get((arm, task), [])),
        }
    row['feature_minus_main'] = {key: row['feature'][key] - row['main'][key] for key in row['main']}
    rows.append(row)
rows.sort(key=lambda r: r['feature_minus_main']['gross'], reverse=True)
total_delta = sum(r['feature_minus_main']['gross'] for r in rows)
assert total_delta == 137825
assert sum(r['main']['research_calls'] for r in rows) == 18
assert sum(r['feature']['research_calls'] for r in rows) == 22
report = {
    'kind': 'Descriptive arithmetic only; every paired question retained, no new benchmark or causal attribution',
    'inputs_sha256': before,
    'rows': rows,
    'gross_delta': total_delta,
    'top_two_positive_delta_fraction_of_net': sum(r['feature_minus_main']['gross'] for r in rows[:2]) / total_delta,
    'qualification': 'Post-outcome ranking identifies follow-up priorities, not effects isolated from provider sampling, cache variation, generated saved wording or simultaneous runtime changes. Negative deltas remain included. No per-session resampling or analyzer invocation.',
    'new_embeddings': 0, 'new_CE_pairs': 0, 'new_subject_calls': 0,
}
assert before == {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
Path('work/cost-attribution-67.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'gross_delta': total_delta, 'top': [{'task': r['task'], **r['feature_minus_main']} for r in rows[:5]]}))
