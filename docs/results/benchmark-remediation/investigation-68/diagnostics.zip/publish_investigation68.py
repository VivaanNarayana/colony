"""Publish bounded post-trial56 diagnostics without changing runtime or historical evidence."""
import hashlib
import json
import subprocess
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path

used = int(sys.argv[1])
assert 20 <= used <= 100
paused = used >= 21
root = Path.cwd()
work = root / 'work'
out = root / 'docs/results/benchmark-remediation/investigation-68'
out.mkdir(exist_ok=False)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert head == '87aa5f0d34a139f8e063614ac9c4ff246ca998f7'
assert not subprocess.check_output(['git', 'diff', 'fec2c119', '--', 'src', 'tests', 'scripts'])
assert not subprocess.check_output(['git', 'diff', head, '--', 'docs/results/benchmark-remediation'])
diagnostic = json.loads((work / 'query-only-context-68/results.json').read_text(encoding='utf-8'))
review = json.loads((work / 'reconciliation-68.json').read_text(encoding='utf-8'))
cost = json.loads((work / 'cost-attribution-67.json').read_text(encoding='utf-8'))
summary = {
    'kind': 'Post-trial56 development checkpoint68; no production change or new native samples',
    'publication_parent': head,
    'measured_runtime': 'fec2c119d2964e99e01cf00239caab02625b34bb',
    'source_commit': '75b4af31ee7556b931a387de6762014ac6f4b44a',
    'latest_complete_comparison': 'trial56:3/8 strict gates',
    'unit_supplement_67': 'Rejected structurally: intact method can omit governing parent docstring or decorator definition; actual CE selection unmeasured, zero inference',
    'citation_policy_67': 'Unadopted optional wording clarification; legitimate verified anchors remain allowed, no demonstrated R29 remediation or reason for a benchmark',
    'query_only_68': 'Unadopted: improves R25 focus but misses required queue write/queued:true after display boundary; six fresh controls and two prior controls do not establish general safety',
    'query_only_cost': diagnostic['cost'],
    'independent_review': review,
    'additional_trial56_review': '12 additional nonblind post-label records agree; total independent selected scope20/48, coordinator48/48. No relabel/analyzer replay.',
    'paired_cost_arithmetic': {'gross_delta': cost['gross_delta'], 'top_two_positive_delta_fraction_of_net': cost['top_two_positive_delta_fraction_of_net'], 'qualification': cost['qualification']},
    'runtime_tests_harness_history_models_gates_unchanged': True,
    'new_native_samples': 0,
    'native_gross_50_51_53_54_55_56': 15497907,
    'usage': {'baseline_used':16, 'latest_observed_used':used, 'observed_points_consumed':used-16, 'stop_used':21, 'reset':1793382050, 'shared':True, 'reporting_may_lag':True},
    'state': 'Paused at shared budget threshold; unfinished' if paused else 'Active; unfinished, only bounded work within remaining shared allowance',
    'resume_checkpoint': 'Read this checkpoint plus trial56. Current runtime is measured and unchanged; no approved next patch. Known wrong-attribute false hit, wording/metadata misses, protocol and gross/uncached gates remain. Next native57 requires a meaningful reviewed general runtime change, fresh main and fresh directories; no identical-code retry.',
    'at_utc': datetime.now(timezone.utc).isoformat(),
}
(out / 'outcome.json').write_text(json.dumps(summary, indent=2)+'\n', encoding='utf-8', newline='\n')
with zipfile.ZipFile(out / 'diagnostics.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name in ['query-context-unit-67', 'query-only-context-68']:
        for path in sorted((work / name).iterdir()):
            if path.is_file() and path.suffix.lower() in {'.py', '.json', '.txt', '.md', '.sha256'}:
                archive.write(path, name+'/'+path.name)
    for name in ['citation-policy-review-67.json', 'independent-additional-review-67.json', 'reconciliation-68.json', 'cost_attribution_67.py', 'cost-attribution-67.json', 'publish_investigation68.py']:
        archive.write(work / name, name)
state = 'Paused at the shared usage threshold; task unfinished.' if paused else 'Active under the same shared allowance; task unfinished.'
(out / 'README.md').write_text(f'''# Post-trial56 checkpoint68

{state} Runtime remains **75b4af3**, measured as fec2c119 in [trial56](../attempt-56/README.md). No production patch, new benchmark, analyzer replay, relabeling or subject resampling followed that complete comparison. All historical evidence and costs remain unchanged.

Trial56 remains **3/8**: loaded implementations, local lookup and live time pass. Tests/lint, correctness, protocol, gross and uncached tokens fail. Time was8.50%lower with positive95%reductionCI; gross12.08%higher; uncached2.08%lower withCI crossing0. Core facts24/24both; citations19/24main and23/24feature. Full suite421passed/1knownwrong-attribute failure/1existingWindows skip; Ruff passed. These results do not isolate benefits of the recent source/index/retry fixes. Subjectgpt-6-luna/low and all retrieval models remain frozen.

Three bounded proposals were retained without integration:

| Proposal | Result and limit |
|---|---|
| Intact method supplement67 | Static rejection before inference. A method can return concrete channels while omitting its class's demonstration-only qualification; a decorated method can omit the separate permission policy. Twelve fresh controls plus R25 were frozen. No CE selection or precision/recall was measured; zero embeddings/CE/provider calls. |
| Citation fallback67 | Two reviewers identified an unspecified fallback when fresh reads supply only a ref/hash, but the proposed clarification still permits legitimate verified headings. R29's heading exists; its rejection by the frozen numeric-fragment oracle is not invented provenance. No runtime change or benchmark justified on that evidence. |
| Existing question-only context selection68 | Six fresh balanced cases plus R25 and two existing controls;46actual CE pairs,12rank calls,0embeddings/providers/errors. Current R25 ask excerpt reproduced. Candidate moves from ask59 to push84 but ends103, omitting actual queue write105 and queued:true106. Required motivating evidence still absent. No new required-context loss detected in the small controls; that is not general safety proof. Metadata and unresolved dependencies remain nonfacts. Exact-question route remains unchanged. No admission/weights/caps/model change, no retuning or production recommendation. |

An independent nonblind post-label review of12additional records found no label inconsistencies; its selected total scope is20/48, not independent blind grading of all48. Coordinator review covered48/48 before the original labels froze. Original labels and all failures remain unchanged.

Read-only paired arithmetic retains all24task deltas, including improvements. Net feature gross excess137,825tokens: mcp-2 adds59,261, scope-3 adds46,435, and outage-2 adds29,328. The first two account for76.69%of the net excess. This post-outcome ranking gives investigation priorities, not isolated causes; sampling, cache and generated wording remain alternatives. No new native token cost; cumulative native50/51/53/54/55/56gross remains15,497,907, with52native0 and earlier costs retained separately.

Archive includes frozen inputs/hashes, source copies, all scores/outputs, static counterexamples, scratch lint findings, the invalid initial shell-backtick extraction qualification, reviews and arithmetic. It excludes private runtime directories, databases and keys. Tests/source/harness/history1–56, eight strict required checks/ruleset25440133/no bypass, oracles/confidence/relevance/workload/prompts/budgets, taint including explicitfalse, exact actual-new-read fingerprints, encrypted queue/retry, authentication/scope/freshness are unchanged.

Shared allowance3: baseline16%used, latest{used}%, stop21%; observed+{used-16}points. Reset2026-10-30 17:40:50UTC. Prior costs remain and usage can lag; this is not a hard billing cap. PR#3 stays draft, unmerged, no auto-merge. No safe next runtime patch is approved; native57 requires a meaningful reviewed general change and fresh main/directories. Read [RESUME](../RESUME.txt) before continuing; no identical-runtime comparison retry.
''', encoding='utf-8', newline='\n')
(out / 'sha256.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(out.iterdir()) if p.name!='sha256.json'},indent=2)+'\n',encoding='utf-8',newline='\n')
resume = root / 'docs/results/benchmark-remediation/RESUME.txt'
prefix = 'PAUSED AT SHARED USAGE BUDGET THRESHOLD' if paused else 'ACTIVE ALLOWANCE3 — POST-TRIAL56 CHECKPOINT68'
resume.write_text(f'''{prefix}; TASK UNFINISHED.
Baseline16%used, latest{used}%, STOP21%; reset1793382050=2026-10-30 17:40:50UTC.
One shared5points, observed+{used-16}; previouscostsretained/reportingmaylag.
Read investigation68 README/outcome/archive and complete attempt56 evidence.
Runtime75b4af3 measuredasfec2c119 unchanged; trial56=3/8, no newbenchmark.
PASS loaded/local/time; FAIL tests/correctness/protocol/gross/uncached.
Tests421pass1knownwrongattribute failure1skip; Ruffpass. Models/harness/gates unchanged.
Unit67 structurallyrejected, citationfallbackunadopted, query-only68unadopted:
R25selectspushbutcuts103beforequeuewrite105/queuedtrue106;46CEpairs/0providers.
Extra independent12recordreview agrees; selectedtotal20/48, nonblind/postlabel.
Alloutcomes/costs/labels/history retained; new pairedarithmetic no causalclaim.
No approved nextpatch. Need generalanswerability/contextfix with qualifiers,
negativecontrols/guards intact; no unsafecompaction or oracle-specificcitationban.
Nextnative57 onlyaftermeaningfulreviewedruntimechange/freshmain/freshdirs;
never retryidenticalruntime orresample. PRdraft/unmerged/noauto.
{'All workers stopped; no benchmark active. Do not start further model work under this exhausted allowance.' if paused else 'Workers idle; no benchmark active. Continue only bounded work within remaining shared allowance; stop at21.'}

'''+resume.read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
budget = root / 'docs/results/benchmark-remediation/budget-allowance-3.json'
record = json.loads(budget.read_text(encoding='utf-8'))
record.update(last_observed_weekly_used_percent=used,observed_increase_percentage_points=used-16,last_phase='Post-trial56 checkpoint68; no new runtime/benchmark; all proposals retained',last_observed_utc=datetime.now(timezone.utc).isoformat())
if paused: record['status']='Paused at shared usage threshold; unfinished'
budget.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
body = (work / 'pr-body-trial56.md').read_text(encoding='utf-8')
body = body.replace('latest19%, STOP21%; observed+3points,2remain','latest'+str(used)+'%, STOP21%; observed+'+str(used-16)+'points')
body += f'\n\n[Checkpoint68](https://github.com/VivaanNarayana/colony/blob/feat/benchmark-independent-evaluation/docs/results/benchmark-remediation/investigation-68/README.md): {state} Static method supplement rejected for omitted governing context; citation fallback unadopted;46CE-pair question-only diagnostic improves focus but still omits the queue write/return. No production change or additional benchmark. Extra12record independent post-label review agrees; total selected20/48, not all48blind. Every outcome retained. Next native57 requires a meaningful reviewed runtime change; no identical-code retry.\n'
(work / 'pr-body-checkpoint68.md').write_text(body,encoding='utf-8',newline='\n')
print(json.dumps({'state':summary['state'],'archive_bytes':(out/'diagnostics.zip').stat().st_size,'source_unchanged':True}))
