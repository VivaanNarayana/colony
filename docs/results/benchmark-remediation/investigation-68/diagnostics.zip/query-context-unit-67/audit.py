"""Fixed postselection unit contract: static rejection, zero local inference."""

import ast
import hashlib
import json
import re
from pathlib import Path
from unittest.mock import patch

from colony import context
from colony.retrieval import keyword_coverage

BASE = Path.cwd()
DIRECTORY = Path(__file__).parent
RECEIPT = "def receipt():\n    return {'state': 'ready', 'format': 'opaque', 'revision': 3}\n"


def case(name,question,code,target,needed,dependency=None,source_ok=True):
    return dict(name=name,question=question,cached_source=code+"\n"*48+RECEIPT,
                broad_answer="The adapter supplies its documented operations and configuration. `receipt` returns `state`, `format`, and `revision` metadata.",
                target_unit=target,expected_unit_needed=needed,required_outside_text=dependency,
                source_eligible=source_ok)


def freeze(name,value):
    data = (json.dumps(value,indent=2)+"\n").encode()
    (DIRECTORY / f"{name}.json").write_bytes(data)
    digest = hashlib.sha256(data).hexdigest()
    (DIRECTORY / f"{name}.sha256").write_text(digest+"\n")
    return digest


def units(lines,first):
    tree = ast.parse("\n".join(lines))
    candidates = [(node,None) for node in tree.body if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef))]
    candidates += [(node,parent) for parent in tree.body if isinstance(parent,ast.ClassDef)
                   for node in parent.body if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef))]
    out = []
    remaining = 2800-len(first["text"])
    occupied_end = first["line"]+first["text"].count("\n")
    for node,parent in sorted(candidates,key=lambda pair:pair[0].lineno):
        start = min([node.lineno]+[d.lineno for d in node.decorator_list])
        while start>1 and lines[start-2].lstrip().startswith("#"):
            start -= 1
        end = node.end_lineno
        text = "\n".join(lines[start-1:end])
        if start<=occupied_end and end>=first["line"]:
            continue
        if len(text)>min(2400,remaining):
            continue
        if any(start<=other["end"] and end>=other["line"] for other in out):
            continue
        out.append(dict(name=node.name,line=start,end=end,text=text,
                        parent_docstring=ast.get_docstring(parent) if parent else None))
        if len(out)>=12:
            break
    return out


def main():
    fresh = [
        case("compression-fact","Which compression formats can the snapshot exporter write?",
             "def compression_formats():\n    return ('gzip', 'zstd')\n","compression_formats",True),
        case("qualified-temperature","What temperature range is supported by this sensor?",
             "class Sensor:\n    def temperature_range(self):\n        \"\"\"Dry indoor operation only; degrees Celsius.\"\"\"\n        return (-5, 40)\n","temperature_range",True),
        case("preceding-comment-qualification","How long are signed previews available?",
             "# Legal holds suspend this limit.\ndef preview_days():\n    return 14\n","preview_days",True),
        case("builtin-decorator","Which paper sizes can the postcard printer use?",
             "class Printer:\n    @staticmethod\n    def paper_sizes():\n        return ('A6', 'A5')\n","paper_sizes",True),
        case("numeric-page-limit","What is the report page size limit?",
             "def page_limit():\n    return 80\n","page_limit",True),
        case("async-fact","Which record encoding does the buffer writer use?",
             "async def record_encoding():\n    return 'UTF-8'\n","record_encoding",True),
        case("parent-class-qualification","Which channels are used for production alerts?",
             'class AlertAdapter:\n    """Demonstration only. Never used for production alerts."""\n    def alert_channels(self):\n        return ("sms", "mail")\n',
             "alert_channels",False,"Demonstration only. Never used for production alerts."),
        case("decorator-policy","Can suspended guests revise the shared calendar?",
             'def active_only(fn):\n    def wrapped(self, user):\n        if user.suspended:\n            return False\n        return fn(self, user)\n    return wrapped\n\nclass Calendar:\n    @active_only\n    def can_revise(self, user):\n        return True\n',
             "can_revise",False,"if user.suspended:"),
        case("external-helper","Which roles may change published annotations?",
             'def annotation_roles():\n    return external_policy.allowed_roles()\n',"annotation_roles",False,
             "external_policy.allowed_roles definition is absent"),
        case("metadata-reference-only","Which export formats are supported?",
             'def export_formats():\n    return {"catalog": "See the external format guide", "receipt_version": 2}\n',
             "export_formats",False,"Actual format values are absent"),
        case("denied-scope","Which compression formats can the snapshot exporter write?",
             "def compression_formats():\n    return ('gzip', 'zstd')\n","compression_formats",False,source_ok=False),
        case("stale-cache","What is the report page size limit?",
             "def page_limit():\n    return 80\n","page_limit",False,source_ok=False),
    ]
    mapping = json.loads((BASE.parent/"benchmark-remediation-live-56-results/review-mapping.json").read_text())
    packet = next(row for row in mapping if row.get("review_id")=="R25")["packets"][0]
    read = packet["current_repository_reads"][0]
    root = BASE.parent/"benchmark-remediation-live-56-runtime/feat/repo"
    cached = (root/read["path"]).read_text()
    motivating = dict(name="R25-nonindependent",question="Does an offline push get queued?",cached_source=cached,
                      broad_answer=packet["content"],first_excerpt=dict(line=read["start_line"],text=read["content"]),
                      target_unit="push",expected_unit_needed=True,source_eligible=True)
    rules = dict(preserve_first=True,same_cached_file_only=True,new_source_reads_in_supplement=0,
                 units="Direct top-level functions/direct class methods only; include decorators and contiguous preceding comments; no nested/conditional units",
                 fitting="Exact original contiguous text; <=2400 characters and remaining 2800 budget; disjoint; first12 source-order units",
                 scoring="Hypothetical unchanged CE(original question,unit), strict score>0, select top one; no embeddings or admission changes",
                 labels="Six fresh units needed, six none; labels frozen before any scoring; R25 is nonindependent",
                 static_stop="Reject before inference if fixed unit contract cannot preserve governing dependencies")
    digest = freeze("inputs",dict(rules=rules,fresh=fresh,motivating=motivating))
    freeze("manifest",dict(inputs_sha256=digest,script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                           context_sha256=hashlib.sha256((BASE/"src/colony/context.py").read_bytes()).hexdigest(),
                           frozen_before_scores=True,planned_ce_pair_cap=120,actual_inference_calls=0))
    rows = []
    with patch.object(context,"rank",side_effect=AssertionError("Static stop: no inference authorized")):
        for item in fresh+[motivating]:
            lines = item["cached_source"].splitlines()
            if "first_excerpt" in item:
                first = item["first_excerpt"]
            else:
                receipt = next(n for n in ast.parse(item["cached_source"]).body if isinstance(n,ast.FunctionDef) and n.name=="receipt")
                line,text = context.context_window("manual.py",lines,receipt.lineno,receipt.end_lineno-receipt.lineno+1)
                first = dict(line=line,text=text)
            eligible = units(lines,first) if item["source_eligible"] else []
            target = next((u for u in eligible if u["name"]==item["target_unit"]),None)
            outside = item.get("required_outside_text")
            rows.append(dict(name=item["name"],first_excerpt=first,remaining_budget=2800-len(first["text"]),
                             expected_unit_needed=item["expected_unit_needed"],eligible_units=eligible,target=target,
                             required_outside_text=outside,dependency_missing_from_target=bool(outside and target and outside not in target["text"]),
                             model_selection="Not measured; static rejection occurs before any CE invocation"))
    chunks = context.source_chunks(root,[__import__("colony.models",fromlist=["Source"]).Source(ref=read["path"],content_hash=read["sha256"])])
    code_claims = re.findall(chr(96)+"([^"+chr(96)+"\n]+)"+chr(96),packet["content"])
    query = keyword_coverage(motivating["question"],[c[2] for c in chunks])
    claims = keyword_coverage("\n".join(code_claims),[c[2] for c in chunks])
    lexical = [.2*q+.7*a for q,a in zip(query,claims,strict=True)]
    floor = max(lexical)-.15
    derivation = dict(code_claims=code_claims,floor=floor,first_excerpt_chars=len(read["content"]),
                      paragraphs=[dict(line=line,query_coverage=query[i],claim_coverage=claims[i],lexical=lexical[i],
                                       eligible_for_original_CE=lexical[i]+.1>=floor-1e-12)
                                  for i,(_,line,text) in enumerate(chunks) if 54<=line<=115],
                      initial_scratch_error="An earlier PowerShell command consumed literal backticks in its regex and mistakenly treated the whole answer as one code claim. That output is invalid, not an alternative outcome. Correct extraction here uses chr(96).",
                      initial_invalid_floor=0.05795375578667264,initial_invalid_claims=[packet["content"]])
    freeze("results",dict(inputs_sha256=digest,rows=rows,R25_lexical_derivation=derivation,
                          verdict="Reject fixed rule structurally: method unit omits governing parent qualifier and separate decorator/helper semantics; no dependency gate exists.",
                          CE_pairs=0,embeddings=0,providers=0,supplement_source_reads=0,
                          uncertainty="No model decisions, precision/recall counts, Store result changes, or native benefit measured. Static eligibility/omission is proven; whether CE would choose each negative unit is unknown. Boundary labels are inherited preconditions, not exercised Store race/auth tests."))
    print(json.dumps(dict(fresh=12,motivating=1,inputs_sha256=digest,CE_pairs=0,embeddings=0,
                          parent_target=next(r["target"] for r in rows if r["name"]=="parent-class-qualification"),
                          verdict="Reject structurally before inference")))


if __name__=="__main__":
    main()
