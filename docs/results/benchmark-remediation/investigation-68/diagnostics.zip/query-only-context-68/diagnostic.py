"""Fixed current-versus-query-only source context comparison; no admission changes."""
import hashlib
import json
import tempfile
from pathlib import Path
from unittest.mock import patch

from colony import context
from colony.retrieval import rank
from colony.validation import snapshot

BASE=Path.cwd()
OUT=Path(__file__).parent
ROWS=[
 dict(name="draft-send",positive=True,question="Does a broken connection leave a submitted draft waiting locally?",claims="`inspect` returns `missing` status. `submit` saves locally after connection errors. `replay` resends saved drafts.",
      source="class Drafts:\n    def inspect(self):\n        return {'missing': True}\n\n    def submit(self, draft):\n        try:\n            transmit(draft)\n        except ConnectionError:\n            self.waiting.append(draft)\n            return {'saved_locally': True}\n\n    def replay(self):\n        return send_waiting(self.waiting)\n",required=["except ConnectionError:","self.waiting.append(draft)"],forbidden=[]),
 dict(name="loan-reservation",positive=True,question="May a library loan be prolonged while the title is reserved?",claims="`lookup` reports `availability` and `record_id`. Loans may be renewed once unless another borrower has reserved the title.",
      source="## Lookup metadata\n\nThe lookup receipt includes availability and record_id.\n\n## Renewal policy\n\nA library loan may be prolonged once. However, a reservation by another borrower blocks every extension.\n",required=["reservation by another borrower blocks"],forbidden=[]),
 dict(name="parent-temperature-qualification",positive=True,question="What temperature interval is permitted for the calibration sensor?",claims="`receipt` returns `revision`, `state`, and `opaque`. The calibration sensor accepts minus five to forty degrees only in dry laboratories.",
      source='class Calibration:\n    """Only dry laboratory use is permitted."""\n'+"\n"*24+'    def temperature_interval(self):\n        return (-5, 40)\n'+"\n"*40+"def receipt():\n    return {'revision': 2, 'state': 'ready', 'opaque': True}\n",required=["Only dry laboratory use", "return (-5, 40)"],forbidden=[]),
 dict(name="metadata-reference",positive=False,question="Which encodings does the export writer support?",claims="`receipt` reports `encoding_catalog` and `revision`. Actual encodings are defined in an external guide.",source="def receipt():\n    return {'encoding_catalog': 'see external guide', 'revision': 2}\n",required=[],forbidden=[],note="Selected metadata does not establish any encoding fact."),
 dict(name="demonstration-scope",positive=False,question="Which channels send production alerts?",claims="`receipt` contains `revision` and `state`. The adapter is a demonstration and supplies no production alert channels.",source='class Demo:\n    """Demonstration only. Never used for production alerts."""\n'+"\n"*24+'    def alert_channels(self):\n        return ("sms", "mail")\n'+"\n"*40+"def receipt():\n    return {'revision': 2, 'state': 'ready'}\n",required=[],forbidden=[dict(value='return ("sms", "mail")',qualification="Never used for production alerts")]),
 dict(name="external-decorator-policy",positive=False,question="Can suspended reviewers revise published annotations?",claims="`receipt` contains `policy_name` and `revision`. Permissions are delegated to an external decorator whose policy is not provided.",source='class Annotations:\n    @external_policy\n    def may_revise(self, user):\n        return True\n'+"\n"*40+"def receipt():\n    return {'policy_name': 'external', 'revision': 2}\n",required=[],forbidden=[dict(value="return True",qualification="@external_policy")],note="Decorator presence identifies a dependency; it does not establish permission. No supported permission fact is available."),
 dict(name="existing-exact-qualification",positive=True,exact=True,question="What is the relay retention policy?",claims="The relay retains archives for 37 days. Legal holds suspend deletion.",source="## Relay\n\nThe relay retains archives for 37 days.\n\nHowever, legal holds suspend deletion.\n",required=["37 days","legal holds"],forbidden=[],origin="test_descriptive_receipts_preserve_dependent_context"),
 dict(name="existing-credential-dependency",positive=True,question="How do I rotate relay credentials?",claims="Rotate credentials before restarting the relay. Use the administrator-issued credential for the first restart.",source="## Rotation\n\nRotate credentials before restarting the relay.\n\nUse the administrator-issued credential for the first restart.\n",required=["administrator-issued","Rotate credentials"],forbidden=[],origin="test_procedural_request_keeps_recipe_even_for_prose_selection"),
]

def freeze(name,value):
 data=(json.dumps(value,indent=2)+"\n").encode(); (OUT/(name+".json")).write_bytes(data)
 digest=hashlib.sha256(data).hexdigest(); (OUT/(name+".sha256")).write_text(digest+"\n"); return digest

def main():
 mapping=json.loads((BASE.parent/"benchmark-remediation-live-56-results/review-mapping.json").read_text())
 packet=next(r for r in mapping if r.get("review_id")=="R25")["packets"][0]
 read=packet["current_repository_reads"][0]
 source=(BASE.parent/"benchmark-remediation-live-56-runtime/feat/repo"/read["path"]).read_text()
 rows=ROWS+[dict(name="R25-motivating-nonindependent",positive=True,question="Does an offline push get queued?",claims=packet["content"],source=source,required=['except httpx.TransportError:', 'queue.mkdir', '"queued": True'],forbidden=[])]
 design=dict(candidate="Existing context.excerpts(...,claims=None) only for non-exact reuse; exact context keeps original claims",fresh_balanced_cases=6,existing_controls=2,motivating=1,CE_cap=200,admission_changed=False,windows_caps_and_proofs_unchanged=True,negative_labels="Metadata/reference-only text is never counted as supporting facts. Forbidden values without governing qualification count unsafe context.")
 digest=freeze("inputs",dict(design=design,rows=rows))
 freeze("manifest",dict(inputs_sha256=digest,script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),context_sha256=hashlib.sha256((BASE/"src/colony/context.py").read_bytes()).hexdigest(),frozen_before_inference=True))
 cost=dict(rank_calls=0,pair_entries=0,actual_CE_pairs=0,embeddings=0,providers=0); calls=[]; results=[]; error=None
 def counted(question,passages):
  count=len(set(passages))
  if cost["actual_CE_pairs"]+count>200: raise RuntimeError("Fixed 200-pair cap reached before inference")
  values=rank(question,passages); cost["rank_calls"]+=1; cost["pair_entries"]+=len(passages); cost["actual_CE_pairs"]+=count
  calls.append(dict(question=question,passages=passages,scores=values)); return values
 with tempfile.TemporaryDirectory(prefix="colony-query-context-68-") as tmp,patch.object(context,"rank",counted):
  root=Path(tmp)
  for case in rows:
   try:
    path=root/"guide.py" if not case["source"].startswith("## ") else root/"guide.md"
    path.write_text(case["source"],encoding="utf-8"); proof=snapshot(root,path.name)
    outputs={}
    for arm in ["current","query-only"]:
     claims=case["claims"] if arm=="current" or case.get("exact") else None
     outputs[arm]=context.excerpts(root,[proof],case["question"],claims=claims,strict_sources=True)
    text={arm:"\n\n".join(x["text"] for x in output) for arm,output in outputs.items()}
    missing={arm:[marker for marker in case["required"] if marker not in value] for arm,value in text.items()}
    unsafe={arm:[pair for pair in case["forbidden"] if pair["value"] in value and pair["qualification"] not in value] for arm,value in text.items()}
    result=dict(name=case["name"],positive=case["positive"],source_sha256=proof.content_hash,outputs=outputs,missing_required=missing,unsafe_context=unsafe,new_required_loss=bool(set(missing["query-only"])-set(missing["current"])),candidate_missing_required=bool(case["positive"] and missing["query-only"]),new_unsafe_context=bool(unsafe["query-only"] and not unsafe["current"]),source_support_unavailable=not case["positive"],exact_preserved=not case.get("exact") or outputs["current"]==outputs["query-only"])
    results.append(result); print(json.dumps({k:v for k,v in result.items() if k not in ["outputs","source_sha256"]}))
   except Exception as exc:
    error=dict(case=case["name"],type=type(exc).__name__,message=str(exc)); print(json.dumps(dict(error=error))); break
 freeze("results",dict(inputs_sha256=digest,cost=cost,error=error,rows=results,calls=calls,limits="Source-context comparison only; no Store admission or native behavior measured. Negative metadata outputs remain nonfacts; decorator/helper facts cannot be inferred from their names."))
 print(json.dumps(dict(cost=cost,error=error,completed=len(results),new_required_losses=sum(r["new_required_loss"] for r in results),candidate_missing_required=sum(r["candidate_missing_required"] for r in results),new_unsafe_contexts=sum(r["new_unsafe_context"] for r in results))))

if __name__=="__main__": main()
