The integration region is us-west-11.
