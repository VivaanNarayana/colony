import sys,json
from pathlib import Path
sys.path.insert(0,'scripts')
from audit_lookup_local import audit_local
p=Path('../benchmark-remediation-local-50-results')
r=audit_local(json.loads((p/'lookup-summary.json').read_text()),p)
Path('work/local-50-audit.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r))
