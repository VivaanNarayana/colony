import json
from pathlib import Path
from colony.retrieval import rank
root=Path('work/retrieval-50')
cases=json.loads((root/'predicate-diagnostic-v2.json').read_text())
rows=[]
for c in cases:
 q,s,a=c['question'],c['saved_question'],c['content']
 reverse=rank(a[:4000],[q,s])
 new=c['old_gate'] and (c['literal_support'] or reverse[0]>max(0,reverse[1]))
 rows.append(dict(c,reverse_scores=reverse,new_gate=new))
(root/'reverse-diagnostic.json').write_text(json.dumps(rows,indent=2)+'\n')
for r in rows:
 if r['old_gate']!=r['new_gate'] or not r['expected_supported'] and r['new_gate']:
  print(json.dumps({k:r[k] for k in ['question','expected_supported','old_gate','new_gate','reverse_scores']}))
print('rows',len(rows))
