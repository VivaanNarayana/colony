"""Local pinned-ranker diagnostic; does not alter admission or run subjects."""

import json
import re
import runpy
from pathlib import Path

from colony.retrieval import local_term_support, rank, terms


def main():
    cases = runpy.run_path("tests/test_saved_wording_regression.py")["CASES"]
    records = []
    for saved, positive, negative, concise, explanatory in cases:
        for wording, answer in [("concise", concise), ("explanatory", explanatory)]:
            sentences = re.split(r"(?<=[.!?])\s+", answer)
            paragraphs = [paragraph for paragraph in answer.split("\n\n") if paragraph.strip()]
            for expected, question in [(True, positive), (False, negative)]:
                scores = rank(question, [answer, saved, *sentences, *paragraphs])
                full_score, question_score = scores[:2]
                sentence_scores = scores[2 : 2 + len(sentences)]
                paragraph_scores = scores[2 + len(sentences) :]
                bound = max(0.0, question_score)
                records.append(
                    {
                        "saved_question": saved,
                        "question": question,
                        "expected_supported": expected,
                        "wording": wording,
                        "answer": answer,
                        "literal_support": local_term_support(terms(question), answer),
                        "full_answer_score": full_score,
                        "saved_question_score": question_score,
                        "sentences": [
                            {"text": text, "score": score}
                            for text, score in zip(sentences, sentence_scores, strict=True)
                        ],
                        "paragraphs": [
                            {"text": text, "score": score}
                            for text, score in zip(paragraphs, paragraph_scores, strict=True)
                        ],
                        "existing_contrastive_rule_full": full_score > bound,
                        "existing_contrastive_rule_max_sentence": max(sentence_scores) > bound,
                        "existing_contrastive_rule_min_sentence": min(sentence_scores) > bound,
                        "note": "Scores assess relevance, not entailment. Rule variants are diagnostics only.",
                    }
                )
    destination = Path("work/retrieval-50/sentence-diagnostic.json")
    destination.write_text(json.dumps(records, indent=2) + "\n", encoding="utf-8")
    for row in records:
        print(
            json.dumps(
                {
                    key: row[key]
                    for key in [
                        "question",
                        "wording",
                        "expected_supported",
                        "full_answer_score",
                        "saved_question_score",
                        "sentences",
                        "existing_contrastive_rule_full",
                        "existing_contrastive_rule_max_sentence",
                        "existing_contrastive_rule_min_sentence",
                    ]
                }
            )
        )


if __name__ == "__main__":
    main()
