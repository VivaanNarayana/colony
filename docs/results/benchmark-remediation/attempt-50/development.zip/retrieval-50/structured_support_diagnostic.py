"""Predeclared structured representation comparison; no admission changes."""

import json
import sys
from pathlib import Path

BASE = Path.cwd()
sys.path.insert(0, str(BASE.parent / "benchmark-remediation-live-49-runtime/implementation/feature/src"))

from colony.retrieval import local_term_support, passage, rank, terms  # noqa: E402


def read(name):
    return json.loads((BASE / "work/retrieval-50" / name).read_text(encoding="utf-8"))


def main():
    cases = []
    for record in read("sentence-diagnostic.json"):
        cases.append(dict(
            origin="first-independent-wording", expected_supported=record["expected_supported"],
            question=record["question"], saved_question=record["saved_question"],
            content=record["answer"], wording=record["wording"],
        ))
    for record in read("independent-support-diagnostic.json"):
        cases.append(dict(
            origin="second-independent-wording", expected_supported=record["expected_supported"],
            question=record["question"], saved_question=record["saved_question"],
            content=record["answer"], domain=record["domain"],
        ))
    for record in read("retained-guard-diagnostic.json")["results"]:
        target = record["answers"][0]
        cases.append(dict(
            origin="retained-target", expected_supported=True,
            question=record["question"], saved_question=target["saved_question"],
            content=target["content"], retained_task=record["task"],
        ))
    results = []
    for case in cases:
        question, saved, content = case["question"], case["saved_question"], case["content"]
        structured_answer = passage(saved, content)
        structured_control = passage(saved, "")
        old_answer, old_control, new_answer, new_control = rank(
            question, [content[:4000], saved, structured_answer, structured_control]
        )
        literal = local_term_support(terms(question), content)
        old_semantic = old_answer > max(0.0, old_control)
        new_semantic = new_answer > max(0.0, new_control)
        results.append(dict(
            **case, literal_support=literal,
            original_answer_score=old_answer, original_control_score=old_control,
            original_positive_and_above_control=old_semantic,
            original_literal_or_semantic_gate=literal or old_semantic,
            structured_answer=structured_answer, structured_control=structured_control,
            structured_answer_score=new_answer, structured_control_score=new_control,
            structured_positive_and_above_control=new_semantic,
            hypothetical_literal_or_structured_gate=literal or new_semantic,
            interpretation="Local relevance scores only; no source, scope, dense or freshness gate changes.",
        ))
    output = BASE / "work/retrieval-50/structured-support-diagnostic.json"
    output.write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
    for result in results:
        print(json.dumps({key: result[key] for key in [
            "origin", "question", "expected_supported", "literal_support",
            "original_answer_score", "original_control_score",
            "original_positive_and_above_control", "structured_answer_score",
            "structured_control_score", "structured_positive_and_above_control",
        ]}))


if __name__ == "__main__":
    main()
