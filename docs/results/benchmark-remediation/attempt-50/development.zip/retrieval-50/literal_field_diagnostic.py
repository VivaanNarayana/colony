"""Exact-field pure-inline-literal diagnostic; retain all controls."""

import json
import re
import runpy
from pathlib import Path

BASE = Path.cwd()
helpers = runpy.run_path("work/retrieval-50/label_support_diagnostic.py")
relation, cosine = helpers["relation"], helpers["cosine"]

from colony.retrieval import (  # noqa: E402
    embed, embed_passages, keyword_coverage, local_term_support, rank, terms,
)


def literal_list(value):
    return bool(re.fullmatch(
        r"`[^`\n]+`(?:\s*(?:,\s*(?:and\s+|or\s+)?|and\s+|or\s+)`[^`\n]+`)*\.?",
        value.strip(),
    ))


def main():
    path = BASE / "work/retrieval-50"
    specifications = [
        ("Document converter", "Which MIME types does the conversion service accept when users import documents?",
         "MIME types", "`application/pdf`, `text/plain`", "Output encoding", "`utf-8`"),
        ("Integrity", "Which checksum algorithms does the package mirror compute before publishing a downloaded archive?",
         "Checksum algorithms", "`sha256` or `sha512`", "Compression", "`zstd`"),
        ("Worker API", "What status codes does the job endpoint return after rejecting a malformed submission?",
         "Status codes", "`400` and `422`", "Retry delay", "`5s`"),
        ("Localization", "Which locale identifiers does the message formatter recognize when selecting a customer's translation?",
         "Locale identifiers", "`en-US`, `fr-CA`, and `ja-JP`", "Encoding", "`utf-8`"),
    ]
    cases = []
    for heading, question, label, value, wrong, other in specifications:
        variants = [
            ("direct-code-values", f"{label}: {value}.", True),
            ("metadata-label", f"{label} metadata: `content_hash` and `checked_at`.", False),
            ("mixed-prose-pointer", f"{label}: See `catalog`.", False),
            ("wrong-field", f"{wrong}: {other}.", False),
            ("empty-value", f"{label}:", False),
            ("plain-values-existing-path", f"{label}: " + value.replace("`", "") + ".", True),
            # A code span can quote a pointer rather than provide any field value.
            ("pure-code-pointer", f"{label}: `See the separate catalog`.", False),
        ]
        for origin, paragraph, expected in variants:
            cases.append(dict(origin=origin, question=question, ref="guide.md",
                              text=f"Section: {heading}\n{paragraph}", expected_sufficient=expected))
    retained = json.loads((path / "label-support-diagnostic.json").read_text(encoding="utf-8"))[0]
    cases.append({key: retained[key] for key in ["origin", "question", "ref", "text", "expected_sufficient"]})
    coverage = keyword_coverage("", [])  # Each query gets its own complete predeclared candidate set below.
    results = []
    texts = [row["text"] for row in cases]
    vectors = embed_passages([f"{row['ref']}\n{row['text']}" for row in cases])
    for i, (case, vector) in enumerate(zip(cases, vectors, strict=True)):
        structure = relation(case["question"], case["text"])
        for label in structure["labels"]:
            label["pure_inline_literal_list"] = literal_list(label["value"])
        exact_literal = any(row["eligible"] and row["pure_inline_literal_list"] for row in structure["labels"])
        query = embed(case["question"], query=True)
        dense = cosine(query, vector)
        score = rank(case["question"], [case["text"]])[0]
        lexical = keyword_coverage(case["question"], texts)[i]
        local = local_term_support(terms(case["question"]), case["text"])
        old_eligible = lexical >= 0.5 and local and score >= -5.0
        new_eligible = exact_literal and dense >= 0.45 and score > 0.0
        results.append(dict(
            **case, **structure, exact_literal_match=exact_literal,
            cosine=dense, rank_score=score, lexical=lexical, local_support=local,
            original_descriptive_admission=old_eligible,
            literal_alternative_eligible=new_eligible,
            newly_eligible=new_eligible and not old_eligible,
            new_insufficient_case=new_eligible and not old_eligible and not case["expected_sufficient"],
            coverage_scope="IDF computed across all29 predeclared diagnostic paragraphs, not a production corpus.",
            baseline_definitive_rejection=not local,
        ))
    (path / "literal-field-diagnostic.json").write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
    for row in results:
        print(json.dumps({key: row[key] for key in [
            "origin", "question", "expected_sufficient", "exact_literal_match", "cosine",
            "rank_score", "lexical", "local_support", "literal_alternative_eligible",
            "newly_eligible", "new_insufficient_case",
        ]}))


if __name__ == "__main__":
    main()
