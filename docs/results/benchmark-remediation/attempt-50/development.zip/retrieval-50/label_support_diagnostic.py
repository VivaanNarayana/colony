"""Exact source-label relation diagnostic; no index, cutoff or runtime changes."""

import json
import re
import sys
from pathlib import Path

import numpy as np

BASE = Path.cwd()
sys.path.insert(0, str(BASE.parent / "benchmark-remediation-live-49-runtime/implementation/feature/src"))

from colony.retrieval import embed, embed_passages, local_term_support, rank, terms  # noqa: E402


def cosine(left, right):
    left, right = np.frombuffer(left, np.float32), np.frombuffer(right, np.float32)
    return float(np.dot(left, right) / (np.linalg.norm(left) * np.linalg.norm(right)))


def relation(question, text):
    first, *lines = text.splitlines()
    heading = first.removeprefix("Section: ") if first.startswith("Section: ") else ""
    match = re.match(
        r"^(?:which|what)\s+(.+?)\s+(?:do|does|did|is|are|was|were|can|could|will|would|"
        r"shall|should|has|have|had|must|may|might)\b", question, re.I,
    )
    head = match[1] if match else ""
    head_terms, heading_terms = terms(head), terms(heading)
    residual = head_terms - heading_terms
    labels = []
    for line in lines:
        if ":" not in line:
            continue
        label, value = line.split(":", 1)
        label, value = label.strip(), value.strip()
        label_terms = terms(label)
        labels.append(dict(
            label=label, value=value, label_terms=sorted(label_terms),
            exact_label_match=bool(residual) and label_terms == residual,
            complete_head=head_terms <= label_terms | heading_terms,
            nonempty_value=bool(value),
            eligible=bool(residual) and label_terms == residual
            and head_terms <= label_terms | heading_terms and bool(value),
        ))
    return dict(head=head, head_terms=sorted(head_terms), heading=heading,
                heading_terms=sorted(heading_terms), residual_head_terms=sorted(residual),
                labels=labels, structural_match=any(label["eligible"] for label in labels))


def main():
    directory = BASE / "work/retrieval-50"
    retained = json.loads((directory / "retained-guard-diagnostic.json").read_text(encoding="utf-8"))
    mcp = next(row for row in retained["results"] if row["task"] == "mcp-2")
    declaration = next(row for row in mcp["readme_candidates"] if row["line"] == 74)
    cases = [dict(
        origin="retained-declaration", question=mcp["question"], ref="README.md",
        text=declaration["text"], expected_sufficient=True,
    )]
    specifications = [
        ("Image renderer", "Which image formats does the renderer support?", "Formats", "PNG and WebP",
         "Color profiles", "sRGB"),
        ("Backup replicator", "Which regions does the backup replicator use?", "Regions",
         "eu-west-1 and us-east-2", "Compression", "zstd"),
        ("Audit archive", "What retention period does the audit archive enforce?", "Retention period",
         "Thirty days, unless a legal hold is active", "Encryption", "AES-256-GCM"),
        ("Command gateway", "Which authentication methods does the command gateway accept?",
         "Authentication methods", "Client certificates and security keys", "Retry interval", "Five seconds"),
    ]
    for heading, question, label, value, other_label, other_value in specifications:
        variants = [
            ("direct-fact", f"{label}: {value}.", True),
            ("metadata-label", f"{label} metadata: Receipts record validation status and opaque identifiers.", False),
            ("different-attribute", f"{other_label}: {other_value}.", False),
            ("empty-value", f"{label}:", False),
            # Exact labels can still defer all requested facts to absent text.
            ("exact-label-reference-only", f"{label}: The requested values are listed elsewhere; consult the separate catalog.", False),
        ]
        for origin, paragraph, expected in variants:
            cases.append(dict(origin=origin, question=question, ref="guide.md",
                              text=f"Section: {heading}\n{paragraph}", expected_sufficient=expected))
    results = []
    for case in cases:
        query = embed(case["question"], query=True)
        vector = embed_passages([f"{case['ref']}\n{case['text']}"])[0]
        dense = cosine(query, vector)
        score = rank(case["question"], [case["text"]])[0]
        structural = relation(case["question"], case["text"])
        results.append(dict(
            **case, **structural, cosine=dense, rank_score=score,
            dense_guard=dense >= 0.45, source_rank_guard=score >= -5.0,
            existing_local_term_support=local_term_support(terms(case["question"]), case["text"]),
            unweighted_query_term_fraction=len(terms(case["question"]) & terms(case["text"]))
            / len(terms(case["question"])),
            hypothetical_eligible=structural["structural_match"] and dense >= 0.45 and score >= -5.0,
            interpretation="Exact label relation is a diagnostic, not certification of fact completeness.",
        ))
    (directory / "label-support-diagnostic.json").write_text(
        json.dumps(results, indent=2) + "\n", encoding="utf-8"
    )
    for row in results:
        print(json.dumps({key: row[key] for key in [
            "origin", "question", "expected_sufficient", "residual_head_terms", "labels",
            "structural_match", "cosine", "rank_score", "hypothetical_eligible",
        ]}))


if __name__ == "__main__":
    main()
