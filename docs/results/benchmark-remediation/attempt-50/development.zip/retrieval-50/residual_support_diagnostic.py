"""Predeclared query-vocabulary subtraction diagnostic; no runtime changes."""

import json
import re
import sys
from pathlib import Path

BASE = Path.cwd()
sys.path.insert(0, str(BASE.parent / "benchmark-remediation-live-49-runtime/implementation/feature/src"))

from colony.retrieval import rank, terms  # noqa: E402


def main():
    path = BASE / "work/retrieval-50"
    cases = json.loads((path / "structured-support-diagnostic.json").read_text(encoding="utf-8"))
    results = []
    for case in cases:
        original = case["question"]
        topic = terms(case["saved_question"])
        removed = []

        def subtract(match):
            token = match[0]
            if terms(token) & topic:
                removed.append(token)
                return ""
            return token

        residual = re.sub(r"[A-Za-z][A-Za-z0-9_-]*", subtract, original)
        residual = re.sub(r"\s+", " ", residual).strip()
        residual = re.sub(r"\s+([?.!,;:])", r"\1", residual)
        meaningful = sorted(terms(residual))
        scores = rank(residual, [case["content"][:4000], case["saved_question"]])
        support = scores[0] > max(0.0, scores[1])
        old_gate = case["original_literal_or_semantic_gate"]
        results.append(dict(
            origin=case["origin"], question=original, saved_question=case["saved_question"],
            content=case["content"], expected_supported=case["expected_supported"],
            original_literal_support=case["literal_support"],
            original_answer_score=case["original_answer_score"],
            original_control_score=case["original_control_score"],
            original_gate=old_gate, residual_query=residual, removed_query_tokens=removed,
            residual_meaningful_terms=meaningful,
            residual_answer_score=scores[0], residual_control_score=scores[1],
            residual_positive_and_above_control=support,
            tightening_only_gate=old_gate and (support if meaningful else True),
            interpretation="Diagnostic only; existing source/dense/scope/freshness gates unchanged.",
        ))
    output = path / "residual-support-diagnostic.json"
    output.write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
    for result in results:
        print(json.dumps({key: result[key] for key in [
            "question", "expected_supported", "residual_query", "residual_meaningful_terms",
            "original_gate", "residual_answer_score", "residual_control_score",
            "residual_positive_and_above_control", "tightening_only_gate",
        ]}))


if __name__ == "__main__":
    main()
