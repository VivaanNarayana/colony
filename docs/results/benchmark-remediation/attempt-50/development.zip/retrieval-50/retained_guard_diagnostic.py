"""Direct recomputation from archived prior pushes; never opens a benchmark DB."""

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

BASE = Path.cwd()
RUNTIME = BASE.parent / "benchmark-remediation-live-49-runtime"
sys.path.insert(0, str(RUNTIME / "implementation/feature/src"))

from colony.context import source_chunks  # noqa: E402
from colony.models import Source  # noqa: E402
from colony.retrieval import (  # noqa: E402
    embed,
    embed_passages,
    fused_score,
    keyword_coverage,
    local_term_support,
    passage,
    rank,
    terms,
)


def cosine(left, right):
    left, right = np.frombuffer(left, np.float32), np.frombuffer(right, np.float32)
    return float(np.dot(left, right) / (np.linalg.norm(left) * np.linalg.norm(right)))


def main():
    archive = BASE / "docs/results/benchmark-remediation/attempt-49"
    reviews = json.loads((archive / "research-review.json").read_text(encoding="utf-8"))
    order = json.loads((archive / "feature/metadata.json").read_text(encoding="utf-8"))["task_order"]
    pushes = {}
    for review in reviews:
        if review["arm"] == "feature":
            pushes[review["task"]] = [
                op["arguments"] for op in review["ops"] if op["tool"] == "push"
            ]
    questions = {
        "stale-2": "What happens when repository evidence changes?",
        "mcp-2": "Which tools does the MCP wrapper expose?",
    }
    results = []
    for task, question in questions.items():
        prior = [p for t in order[: order.index(task)] for p in pushes.get(t, [])]
        query = embed(question, query=True)
        answers = []
        for saved in prior:
            qcos = cosine(query, embed(saved["question"], query=True))
            acos = cosine(query, embed(passage(saved["question"], saved["content"])))
            score, control = rank(question, [saved["content"][:4000], saved["question"]])
            literal = local_term_support(terms(question), saved["content"])
            relevance = fused_score(max(qcos, acos), score)
            answers.append(
                dict(
                    saved_question=saved["question"], content=saved["content"],
                    question_cosine=qcos, answer_cosine=acos, dense=max(qcos, acos),
                    full_score=score, control_score=control, literal_support=literal,
                    dense_guard=max(qcos, acos) >= 0.55,
                    question_guard=qcos >= 0.65,
                    semantic_guard=literal or score > max(0.0, control),
                    relevance=relevance, relevance_guard=relevance >= 0.60,
                )
            )
        # Grouping mirrors permitted source identities; no unseen files are searched.
        sources = {}
        for saved in prior:
            for source in saved.get("sources", []):
                sources[(source["ref"], source["content_hash"])] = Source(**source)
        descriptors = []
        for source in sources.values():
            descriptors.extend(source_chunks(RUNTIME / "feat/repo", [source]))
        vectors = embed_passages([f"{ref}\n{text}" for ref, _, text in descriptors])
        candidates = sorted(
            [dict(ref=ref, line=line, text=text, cosine=cosine(query, vector))
             for (ref, line, text), vector in zip(descriptors, vectors, strict=True)],
            key=lambda row: row["cosine"], reverse=True,
        )
        lexical = keyword_coverage(question, [row["text"] for row in candidates])
        dense = [i for i, row in enumerate(candidates) if row["cosine"] >= 0.45][:24]
        sparse = [i for i in sorted(range(len(lexical)), key=lexical.__getitem__, reverse=True)
                  if lexical[i] >= 0.15][:24]
        selected = set(dense) | set(sparse)
        survivors = [i for i in selected if lexical[i] >= 0.5
                     and local_term_support(terms(question), candidates[i]["text"])]
        survivor_scores = dict(zip(
            survivors, rank(question, [candidates[i]["text"] for i in survivors]), strict=True
        ))
        all_source_guards = [dict(
            **row, lexical=lexical[i],
            local_support=local_term_support(terms(question), row["text"]),
            dense_or_sparse_candidate=i in selected,
            descriptive_prefilter=i in survivors,
            score_if_actually_ranked=survivor_scores.get(i),
        ) for i, row in enumerate(candidates)]
        # Rank diagnostic README paragraphs even if prefilters reject them.
        readme_indices = [i for i, row in enumerate(candidates) if row["ref"] == "README.md"]
        scores = rank(question, [candidates[i]["text"] for i in readme_indices])
        readme = []
        for i, score in zip(readme_indices, scores, strict=True):
            row = candidates[i]
            support = local_term_support(terms(question), row["text"])
            readme.append(dict(
                **row, lexical=lexical[i], local_support=support, score=score,
                dense_or_sparse_candidate=i in selected,
                descriptive_prefilter=lexical[i] >= 0.5 and support,
                source_rank_guard=score >= -5.0,
            ))
        results.append(dict(task=task, question=question, prior_count=len(prior),
                            prior_questions=[p["question"] for p in prior],
                            answers=sorted(answers, key=lambda row: row["dense"], reverse=True),
                            readme_candidates=readme, source_candidate_count=len(candidates),
                            all_source_guards=all_source_guards))
    output = BASE / "work/retrieval-50/retained-guard-diagnostic.json"
    output.write_text(json.dumps(dict(
        method="Direct archived-prior-push recomputation; no DB opened or changed",
        source_modules={name: str(getattr(sys.modules[f"colony.{name}"], "__file__"))
                        for name in ["retrieval", "context"]},
        module_hashes={name: hashlib.sha256(Path(sys.modules[f"colony.{name}"].__file__).read_bytes()).hexdigest()
                       for name in ["retrieval", "context"]},
        results=results,
    ), indent=2) + "\n", encoding="utf-8")
    print(str(output))


if __name__ == "__main__":
    main()
