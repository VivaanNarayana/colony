"""Predeclared independent local-ranker cases; retain every outcome."""

import json
import re
from pathlib import Path

from colony.retrieval import local_term_support, rank, terms


CASES = [
    {
        "domain": "lease-renewal",
        "saved_question": "When must a job lease be renewed?",
        "positive": "When does a lease need renewal?",
        "negative": "Which encryption algorithm protects a job lease?",
        "answer": "A job reservation has a forty-five-second lifetime. "
        "It must be extended before that time elapses.",
    },
    {
        "domain": "cache-freshness",
        "saved_question": "What is the cache freshness policy?",
        "positive": "How long do cached responses remain valid?",
        "negative": "Which encryption algorithm protects cached responses?",
        "answer": "The cache uses a freshness interval. Its configured value is ninety seconds. "
        "A response older than that interval is evicted.",
    },
    {
        "domain": "upload-quota",
        "saved_question": "What is the hourly upload quota?",
        "positive": "How many files may a user submit per hour?",
        "negative": "Which file formats may execute scripts after upload?",
        "answer": "Each account has an hourly upload allowance. That quota is twelve files. "
        "Requests above that allowance are rejected.",
    },
    {
        "domain": "runtime-version",
        "saved_question": "What version does the runtime require?",
        "positive": "Which minimum runtime version is supported?",
        "negative": "Which operating systems does this runtime support?",
        "answer": "The runtime requirement is v3.12. Versions below it are rejected. "
        "Newer patch releases in that series are accepted.",
    },
    {
        "domain": "resolver-timeout",
        "saved_question": "What is the DNS resolver timeout?",
        "positive": "What is the default delay before the resolver times out?",
        "negative": "Which transport encrypts requests to the resolver?",
        "answer": "The DNS resolver uses a timeout, i.e. a bounded wait for each upstream reply. "
        "Its default is 1.5 seconds. Retries have a separate budget.",
    },
    {
        "domain": "retained-session-false-hit",
        "saved_question": "What is the lifetime of a login session?",
        "negative": "Does a login session permit deleting other users?",
        "answer": "After thirty minutes, the login session expires. "
        "Users must authenticate again before continuing. "
        "The expiry interval applies to each newly created session.",
    },
]


def main():
    records = []
    for case in CASES:
        answer = case["answer"]
        # This is the same deliberately simple splitter as the first diagnostic,
        # recorded explicitly so abbreviation/decimal behavior is visible.
        sentences = re.split(r"(?<=[.!?])\s+", answer)
        pairs = [" ".join(sentences[i : i + 2]) for i in range(len(sentences) - 1)]
        for label in ["positive", "negative"]:
            if label not in case:
                continue
            question = case[label]
            passages = [answer, case["saved_question"], *sentences, *pairs]
            scores = rank(question, passages)
            full, control = scores[:2]
            single_scores = scores[2 : 2 + len(sentences)]
            pair_scores = scores[2 + len(sentences) :]
            bound = max(0.0, control)
            records.append(
                {
                    "domain": case["domain"],
                    "expected_supported": label == "positive",
                    "question": question,
                    "saved_question": case["saved_question"],
                    "answer": answer,
                    "literal_support": local_term_support(terms(question), answer),
                    "full_score": full,
                    "control_score": control,
                    "full_gate": full > bound,
                    "sentences": [
                        {"text": text, "score": score}
                        for text, score in zip(sentences, single_scores, strict=True)
                    ],
                    "adjacent_pairs": [
                        {"text": text, "score": score}
                        for text, score in zip(pairs, pair_scores, strict=True)
                    ],
                    "single_support": any(score > bound for score in single_scores),
                    "adjacent_pair_support": any(score > bound for score in pair_scores),
                    "splitter": r"(?<=[.!?])\s+",
                }
            )
    destination = Path("work/retrieval-50/independent-support-diagnostic.json")
    destination.write_text(json.dumps(records, indent=2) + "\n", encoding="utf-8")
    for row in records:
        print(json.dumps(row, sort_keys=True))


if __name__ == "__main__":
    main()
