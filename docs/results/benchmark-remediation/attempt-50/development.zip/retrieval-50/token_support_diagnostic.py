"""Frozen CLS-trained BGE token alignment diagnostic, not a ColBERT model."""

import json
import re
import sys
from pathlib import Path

import numpy as np

BASE = Path.cwd()
sys.path.insert(0, str(BASE.parent / "benchmark-remediation-live-49-runtime/implementation/feature/src"))

from colony.retrieval import STOP_WORDS, models, terms  # noqa: E402


def normalized(vector):
    return vector / max(float(np.linalg.norm(vector)), 1e-12)


def main():
    directory = BASE / "work/retrieval-50"
    cases = json.loads((directory / "predicate-diagnostic-v2.json").read_text(encoding="utf-8"))
    assert len(cases) <= 39
    embedding, _ = models()
    engine = embedding.model
    cache = {}

    def document(text):
        if text in cache:
            return cache[text]
        encoding = engine.tokenize([text])[0]
        assert len(encoding.ids) <= 512
        output = engine.onnx_embed([text]).model_output
        assert output.ndim == 3 and output.shape[0] == 1
        hidden = output[0]
        words, vectors = [], []
        for match in re.finditer(r"[A-Za-z][A-Za-z0-9]*", text):
            word = match[0]
            if word.casefold() in STOP_WORDS:
                continue
            indices = [i for i, (begin, end) in enumerate(encoding.offsets)
                       if end > begin and begin < match.end() and end > match.start()
                       and encoding.attention_mask[i]]
            if not indices:
                continue
            vectors.append(normalized(hidden[indices].mean(axis=0)))
            words.append(dict(text=word, start=match.start(), end=match.end(),
                              normalized_terms=sorted(terms(word)), wordpiece_indices=indices,
                              wordpieces=[encoding.tokens[i] for i in indices]))
        packed = dict(
            text=text, words=words,
            tokenization=[dict(token=token, offset=list(offset), attention=attention)
                          for token, offset, attention in zip(
                              encoding.tokens, encoding.offsets, encoding.attention_mask, strict=True)],
            matrix=np.stack(vectors) if vectors else np.empty((0, hidden.shape[-1])),
            cls=normalized(hidden[0]),
        )
        cache[text] = packed
        return packed

    results = []
    for case in cases:
        query = document(case["question"])
        answer = document(case["content"][:4000])
        saved = document(case["saved_question"])
        answer_scores = query["matrix"] @ answer["matrix"].T
        saved_scores = query["matrix"] @ saved["matrix"].T
        reverse = answer_scores.argmax(axis=0)
        records, semantic, exact = [], [], []
        for i, word in enumerate(query["words"]):
            ai, si = int(answer_scores[i].argmax()), int(saved_scores[i].argmax())
            ac, sc = float(answer_scores[i, ai]), float(saved_scores[i, si])
            mutual = int(reverse[ai]) == i
            supported = ac > sc and mutual
            exact_indices = [j for j, other in enumerate(answer["words"])
                             if set(word["normalized_terms"]) & set(other["normalized_terms"])]
            if supported:
                semantic.append((set(word["normalized_terms"]), answer["words"][ai]["start"]))
            for j in exact_indices:
                exact.append((set(word["normalized_terms"]), answer["words"][j]["start"]))
            records.append(dict(
                query_word=word, best_answer_word=answer["words"][ai], best_answer_cosine=ac,
                best_saved_question_word=saved["words"][si], best_saved_question_cosine=sc,
                strict_answer_above_saved=ac > sc, mutual_nearest=mutual,
                contrastive_mutual_support=supported,
                exact_lexical_answer_words=[answer["words"][j] for j in exact_indices],
            ))
        query_terms = terms(case["question"])
        sentences = list(re.finditer(r"[^.!?]+(?:[.!?]+|$)", answer["text"]))

        def coverage(matches, local):
            if not local:
                found = set().union(*(item[0] for item in matches)) if matches else set()
                return dict(matched_terms=sorted(found), count=len(found), passes=len(found) > len(query_terms) / 2)
            sets = []
            for index, sentence in enumerate(sentences):
                high = sentences[min(index + 1, len(sentences) - 1)].end()
                group = [item[0] for item in matches if sentence.start() <= item[1] < high]
                sets.append(set().union(*group) if group else set())
            found = max(sets, key=len, default=set())
            return dict(matched_terms=sorted(found), count=len(found), passes=len(found) > len(query_terms) / 2)

        methods = dict(
            contrastive_mutual_global=coverage(semantic, False),
            exact_or_contrastive_mutual_global=coverage(exact + semantic, False),
            contrastive_mutual_two_sentence=coverage(semantic, True),
            exact_or_contrastive_mutual_two_sentence=coverage(exact + semantic, True),
        )
        results.append(dict(
            origin=case["origin"], question=case["question"], saved_question=case["saved_question"],
            content=case["content"], expected_supported=case["expected_supported"],
            original_gate=case["old_gate"], original_literal_support=case["literal_support"],
            original_rank_scores=case["original_scores"], query_terms=sorted(query_terms),
            query_word_alignments=records, methods=methods,
            raw_context_cls_answer_cosine=float(query["cls"] @ answer["cls"]),
            raw_context_cls_saved_question_cosine=float(query["cls"] @ saved["cls"]),
            answer_words=answer["words"], saved_question_words=saved["words"],
            query_tokens=query["tokenization"], answer_tokens=answer["tokenization"],
            saved_question_tokens=saved["tokenization"],
            answer_word_cosine_matrix=answer_scores.tolist(), saved_question_word_cosine_matrix=saved_scores.tolist(),
        ))
    metadata = dict(
        model="BAAI/bge-small-en-v1.5", training_caveat="CLS-trained BGE; not token-retrieval-trained ColBERT",
        model_path=str(engine._model_dir), tokenizer_truncation=engine.tokenizer.truncation,
        tokenizer_padding=engine.tokenizer.padding, unique_contexts=len(cache), batch_size=1,
        no_runtime_changes=True, cases=results,
    )
    (directory / "token-support-diagnostic.json").write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")
    for name in results[0]["methods"]:
        errors = [dict(question=row["question"], expected=row["expected_supported"], original=row["original_gate"],
                       predicted=row["methods"][name]["passes"], origin=row["origin"])
                  for row in results if row["methods"][name]["passes"] != row["expected_supported"]]
        print(json.dumps(dict(method=name, count=len(results), errors=errors)))


if __name__ == "__main__":
    main()
