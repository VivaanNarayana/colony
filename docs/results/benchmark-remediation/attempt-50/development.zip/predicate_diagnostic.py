import json
import re
from pathlib import Path
from colony.retrieval import STOP_WORDS, local_term_support, rank, terms

def focus(question, saved):
    tokens=list(re.finditer(r"[A-Za-z][\w'-]*",question))
    if not tokens or tokens[0][0].casefold() not in {'can','could','do','does','did','is','are','was','were','will','would','should','has','have','may','must'}:
        return None
    topic=terms(saved)
    consumed=False
    for token in tokens[1:]:
        if token[0].casefold() in STOP_WORDS:
            continue
        if terms(token[0]) & topic:
            consumed=True
            continue
        text=question[token.start():].rstrip().rstrip('?')
        return text if consumed and terms(text) else None
    return None

root=Path(__file__).parent/'retrieval-50'
cases=json.loads((root/'structured-support-diagnostic.json').read_text())
for saved,answer,question,supported in [
    ('What is the age limit for a user account?', 'Account records are retained for thirty days. Account owners can erase their records at any time.', 'Can an account owner delete the account records?', True),
    ('What is the duration of a service lease?', 'Service leases last for forty minutes. Operators can extend them before expiry.', 'Can service operators renew their lease?', True),
    ('What access does a contributor have?', 'Contributors may create proposals. They cannot erase published releases.', 'Can a contributor remove published releases?', True),
    ('What can project viewers inspect?', 'Project viewers can open reports. They have no permission to edit them.', 'Can project viewers modify reports?', True),
    ('How long is a database snapshot retained?', 'Snapshots remain for nine days. Snapshots are encrypted only with AES-256.', 'Does a database snapshot use ChaCha20 encryption?', True),
    ('What is the duration of a service lease?', 'Service leases last for forty minutes. Operators can extend them before expiry.', 'Can service leases grant administrative permissions?', False),
    ('What access does a contributor have?', 'Contributors may create proposals. They cannot erase published releases.', 'Can contributors approve financial transfers?', False),
    ('What can project viewers inspect?', 'Project viewers can open reports. They have no permission to edit them.', 'Can project viewers bypass account authentication?', False),
]:
    cases.append(dict(saved_question=saved,content=answer,question=question,expected_supported=supported,origin='independent-polar'))
rows=[]
for c in cases:
    question,saved,content=c['question'],c['saved_question'],c['content']
    original=rank(question,[content[:4000],saved])
    f=focus(question,saved)
    focused=rank(f,[content[:4000],saved]) if f else None
    literal=local_term_support(terms(question),content)
    old=literal or original[0]>max(0,original[1])
    new=old and (literal or not f or focused[0]>max(0,focused[1]))
    rows.append(dict(origin=c['origin'],question=question,saved_question=saved,content=content,expected_supported=c['expected_supported'],literal_support=literal,original_scores=original,focus=f,focus_scores=focused,old_gate=old,new_gate=new))
(root/'predicate-diagnostic.json').write_text(json.dumps(rows,indent=2)+'\n')
for r in rows:
    if r['focus']:
        print(json.dumps({k:v for k,v in r.items() if k not in {'content'}}))
