"""Inspect retained tool traces and taint outcomes; assigns no quality labels."""
import hashlib
import json
import sqlite3
import sys
from pathlib import Path

from cryptography.fernet import Fernet

work = Path.cwd().parent
root = work / "colony"
results = work / "benchmark-remediation-live-50-results"
runtime = work / "benchmark-remediation-live-50-runtime"
records = json.loads((results / "review-mapping.json").read_text(encoding="utf-8"))
research = []
errors = []


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def payload(call):
    try:
        return json.loads(call["result"]["content"][0]["text"])
    except (KeyError, TypeError, ValueError):
        return None


for record in records:
    arm, task = record["arm"], record["task_id"]
    corpus = runtime / ("main" if arm == "main" else "feat") / "repo"
    manifest = read(results / arm / "corpus-sha256.json")
    events = [json.loads(line) for line in (results / arm / f"{task}.colony.events.jsonl").read_text(encoding="utf-8").splitlines()]
    calls = [e["item"] for e in events if e.get("type") == "item.completed" and e["item"].get("type") == "mcp_tool_call"]
    reads = {}
    ops = []
    for call in calls:
        if call["server"] == "colony" and call["tool"] != "push":
            continue
        data = payload(call)
        op = {"tool": call["tool"], "arguments": call["arguments"], "status": call.get("status"), "error": call.get("error")}
        if call["server"] == "colony" and call["tool"] == "push":
            attempted = call["arguments"].get("sources", [])
            proof_valid = bool(attempted) and all(s.get("content_hash") == reads.get(s.get("ref")) == manifest.get(s.get("ref")) for s in attempted)
            op["sources_match_actual_new_reads"] = proof_valid
            if not proof_valid:
                errors.append([arm, task, "attempted push fingerprint does not match preceding read"])
        if not isinstance(data, dict):
            op["raw_result"] = call.get("result")
            ops.append(op)
            continue
        if call["server"] == "repository":
            op["reported_budget"] = data.get("research_budget")
        if call["server"] == "repository" and call["tool"] == "search" and "matches" in data:
            needle = call["arguments"]["text"].lower()
            expected = []
            for path in [corpus / "README.md", corpus / "pyproject.toml", *sorted((corpus / "src/colony").glob("*.py"))]:
                expected.extend({"path": path.relative_to(corpus).as_posix(), "line": n, "text": line} for n, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1) if needle in line.lower())
            op["matches"] = data["matches"]
            op["matches_equal_frozen_source"] = data["matches"] == expected[:50]
            if not op["matches_equal_frozen_source"]:
                errors.append([arm, task, "search lines differ"])
        elif call["server"] == "repository" and call["tool"] == "read_file" and "source" in data:
            source = data["source"]
            actual = (corpus / source["ref"]).read_bytes()
            valid = actual == data["content"].encode("utf-8") and hashlib.sha256(actual).hexdigest() == source["content_hash"] == manifest[source["ref"]]
            op.update(source=source, content=data["content"], bytes_and_hash_match_frozen_source=valid)
            if valid:
                reads[source["ref"]] = source["content_hash"]
            else:
                errors.append([arm, task, "read bytes/hash differ"])
        elif call["server"] == "colony" and call["tool"] == "push":
            sources = call["arguments"].get("sources", [])
            valid = bool(sources) and all(s.get("content_hash") == reads.get(s.get("ref")) == manifest.get(s.get("ref")) for s in sources)
            op.update(sources_match_actual_new_reads=valid, result=call.get("result"))
            if not valid:
                errors.append([arm, task, "push fingerprint does not match preceding read"])
        else:
            op["raw_result"] = call.get("result")
        ops.append(op)
    if ops:
        research.append({"id": record["review_id"], "arm": arm, "task": task, "ops": ops})

taint = {}
for arm, folder in (("main", "main"), ("feature", "feat")):
    arm_runtime = runtime / folder
    databases = list((arm_runtime / "server").glob("*.db")) + list((arm_runtime / "server").glob("*.sqlite*"))
    databases = [p for p in databases if p.suffix in {".db", ".sqlite", ".sqlite3"}]
    assert len(databases) == 1, databases
    with sqlite3.connect(f"file:{databases[0].as_posix()}?mode=ro", uri=True) as db:
        db.row_factory = sqlite3.Row
        stored = [dict(row) for row in db.execute("SELECT question,tainted FROM trails ORDER BY question")]
    queued = []
    paths = list((arm_runtime / "agent/queue").glob("*.enc"))
    if paths:
        cipher = Fernet((arm_runtime / "agent/queue.key").read_bytes())
        for path in paths:
            trail = json.loads(cipher.decrypt(path.read_bytes()))["trail"]
            queued.append({"question": trail["question"], "tainted": trail["tainted"]})
    taint[arm] = {"stored": stored, "queued": queued, "all_tainted": all(row["tainted"] in (1, True) for row in stored + queued)}
report = {"raw_trace_errors": errors, "research_save_traces": len(research), "taint": taint}
(work / "benchmark-remediation-research-review-50.json").write_text(json.dumps(research, indent=2) + "\n", encoding="utf-8", newline="\n")
(work / "benchmark-remediation-tool-audit-50.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps({"trace_count": len(research), "raw_trace_errors": errors, "taint_stored_queued": {k: {"stored": len(v["stored"]), "queued": len(v["queued"]), "all_tainted": v["all_tainted"]} for k, v in taint.items()}}, indent=2))
