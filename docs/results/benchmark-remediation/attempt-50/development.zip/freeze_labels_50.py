import json,hashlib,shutil
from datetime import datetime,timezone
from pathlib import Path
from colony.security import scrub
root=Path.cwd(); work=root/'work'; results=root.parent/'benchmark-remediation-live-50-results'; runtime=root.parent/'benchmark-remediation-live-50-runtime'
records=json.loads((results/'review-mapping.json').read_text())
assert len(records)==48 and not (results/'comparison.json').exists()
labels={'main':{},'feature':{}}
errors=[]
for r in records:
 corpus=runtime/('main' if r['arm']=='main' else 'feat')/'repo'
 manifest=json.loads((results/r['arm']/'corpus-sha256.json').read_text())
 for p in r['packets']:
  for e in p.get('current_repository_reads',[]):
   data=(corpus/e['path']).read_bytes()
   whole='\n'.join(scrub(data.decode()).splitlines()[e['start_line']-1:])
   if hashlib.sha256(data).hexdigest()!=e['sha256'] or manifest[e['path']]!=e['sha256'] or not whole.startswith(e['content']):errors.append([r['review_id'],e['path']])
 labels[r['arm']][r['task_id']+'.colony']=dict(correct=True,citation_valid=r['citation_valid'],relevant_asks=[False if r['review_id']=='R21' else bool(p.get('hit')) for p in r['packets']])
assert not errors
for arm,ls in labels.items():
 assert len(ls)==24
 (results/arm/'reviews.json').write_text(json.dumps(ls,indent=2)+'\n',encoding='utf-8')
frozen={arm+'/reviews.json':hashlib.sha256((results/arm/'reviews.json').read_bytes()).hexdigest() for arm in labels}
(work/'frozen-labels-50.json').write_text(json.dumps(frozen,indent=2)+'\n')
shutil.copyfile(work/'verification-50.json',results/'verification.json')
manual=dict(role='Primary coordinator review of all48 shuffled answers/current packets and14 research/save traces; not independent blind review. Zero novel current excerpt byte sequences versus retained attempts24-49.',answers_reviewed=48,novel_current_contexts=0,core_facts_correct={a:sum(r['correct'] for r in ls.values()) for a,ls in labels.items()},valid_citations={a:sum(r['citation_valid'] for r in ls.values()) for a,ls in labels.items()},incorrect_core_fact_review_ids=[],invalid_citation_review_ids=[r['review_id'] for r in records if not r['citation_valid']],relevant_packet_exceptions=[dict(id='R21',arm='feature',task='mcp-2',relevant=False,reason='Validated receipt metadata at README96 lacks requested tool signatures; research required.')],current_source_bytes_and_hashes_verified=True,source_searches_and_completed_reads_verified=True,proof_failures=[dict(id='R36',arm='feature',task='scope-3',attempts=2,submitted_hash='35ddf149763227dcd443f3c9aee9bb2889a996be',actual_hash='35ddf149763227dcd443f3c9aee9bb2889a996be5aae47cf65604f6f19a60a36',outcome='Both strict schema rejections retained; intervening new reread returned full actual hash; no proof repaired or retried by coordinator; final discloses save failure.')],mcp2='Four research calls then valid stored push; same insufficient initial metadata packet. Single sample does not isolate policy effect.',taint=dict(feature_stored=7,feature_queued=0,feature_all_true=True,main_stored=6,main_queued=4,main_all_true=True,limit='No feature offline queue or explicit-false override in this run; unchanged enforcement regression tests cover them.'),supplemental_audit_correction='Initial reused helper skipped push proof audit when receipt was non-JSON error text; rawtraceerrors initially empty. Added unconditional attempted-push check before payload handling. Both initial outputs and corrected failure audit retained. Historical evidence/harness/native traces unchanged.',rubric_unchanged=True,labels_frozen_before_analyzer=True,frozen_utc=datetime.now(timezone.utc).isoformat())
(work/'manual-review-50.json').write_text(json.dumps(manual,indent=2)+'\n')
print(json.dumps(dict(facts=manual['core_facts_correct'],citations=manual['valid_citations'],bad=manual['invalid_citation_review_ids'],proof_failures=manual['proof_failures'],frozen=frozen),indent=2))
