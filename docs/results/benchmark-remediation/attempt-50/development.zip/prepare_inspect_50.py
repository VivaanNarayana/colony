from pathlib import Path
p=Path('../inspect_trial49.py').read_text()
p=p.replace('work = Path(__file__).parent','work = Path.cwd().parent').replace('-49-','-50-').replace('-49.json','-50.json')
Path('work/inspect_50.py').write_text(p,encoding='utf-8')
