import json
from pathlib import Path
from colony.retrieval import rank

root=Path(__file__).parent/'retrieval-50'
cases=json.loads((root/'structured-support-diagnostic.json').read_text())
rows=[]
for c in cases:
    q=c['question'].rstrip().rstrip('?')
    scores=rank(q,[c['content'][:4000],c['saved_question']])
    rows.append({
        'question':c['question'],'expected_supported':c['expected_supported'],
        'literal_support':c['literal_support'],
        'original_answer_score':c['original_answer_score'],
        'original_control_score':c['original_control_score'],
        'normalized_answer_score':scores[0],'normalized_control_score':scores[1],
        'original_gate':c['original_literal_or_semantic_gate'],
        'normalized_gate':c['literal_support'] or scores[0]>max(0,scores[1]),
    })
(root/'query-normalization-diagnostic.json').write_text(json.dumps(rows,indent=2)+'\n')
for r in rows:
    print(json.dumps(r))
