import json
import math
import struct
from pathlib import Path

from colony.retrieval import embed, passage

def cosine(a, b):
    a, b = (struct.unpack('384f', v) for v in (a, b))
    return sum(x*y for x,y in zip(a,b)) / math.sqrt(sum(x*x for x in a)*sum(y*y for y in b))

root = Path(__file__).parent / 'retrieval-50'
cases = json.loads((root/'sentence-diagnostic.json').read_text()) + json.loads((root/'independent-support-diagnostic.json').read_text())
rows = []
for c in cases:
    question, answer, saved = c['question'], c['answer'], c['saved_question']
    q = embed(question, query=True)
    rows.append({
        'question': question, 'answer': answer, 'supported': c['expected_supported'],
        'answer_only_cosine': cosine(q, embed(answer)),
        'existing_passage_cosine': cosine(q, embed(passage(saved, answer))),
        'saved_question_cosine': cosine(q, embed(saved, query=True)),
    })
(root/'dense-diagnostic.json').write_text(json.dumps(rows, indent=2)+'\n')
for r in rows:
    print(json.dumps({k:v for k,v in r.items() if k!='answer'}))
