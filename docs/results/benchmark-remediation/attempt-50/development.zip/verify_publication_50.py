from pathlib import Path
import zipfile,json,hashlib,subprocess
root=Path.cwd();out=root/'docs/results/benchmark-remediation/attempt-50';w=root/'work'
with zipfile.ZipFile(out/'development.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in sorted(w.rglob('*')):
  if f.is_file() and '__pycache__' not in f.parts:z.write(f,f.relative_to(w).as_posix())
with zipfile.ZipFile(out/'development.zip') as z:assert z.testzip() is None
(out/'sha256.json').write_text(json.dumps({f.relative_to(out).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(out.rglob('*')) if f.is_file() and f.name!='sha256.json'},indent=2)+'\n',encoding='utf-8')
assert not subprocess.check_output(['git','diff','156658ee5baca2eb7dff4562b4dc01ff2b48eb02','--','scripts',*[f'docs/results/benchmark-remediation/attempt-{i}' for i in range(1,50)]])
print('Historical attempts1-49 and harness unchanged; archive verifies.')
