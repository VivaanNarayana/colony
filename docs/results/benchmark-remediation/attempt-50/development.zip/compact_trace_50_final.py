import json
from pathlib import Path
rs=json.loads(Path('../benchmark-remediation-research-review-50.json').read_text())
for r in rs:
 ops=[]
 for op in r['ops']:
  d={k:v for k,v in op.items() if k not in ['content','matches','arguments','result','raw_result']}
  d['arguments']={k:v for k,v in op['arguments'].items() if k!='content'}
  if 'matches' in op:d['match_count']=len(op['matches'])
  if 'result' in op:d['result']=op['result']
  if 'raw_result' in op:d['raw_result']=op['raw_result']
  ops.append(d)
 print(json.dumps(dict(id=r['id'],arm=r['arm'],task=r['task'],ops=ops)))
