from pathlib import Path
import shutil
p=Path('work/inspect_50.py')
shutil.copy2(p,Path('work/inspect_50_initial.py'))
for name in ['tool-audit','research-review']:
 shutil.copy2(Path(f'../benchmark-remediation-{name}-50.json'),Path(f'work/{name}-50-initial.json'))
s=p.read_text()
needle='        if not isinstance(data, dict):\n'
insert='''        if call["server"] == "colony" and call["tool"] == "push":
            attempted = call["arguments"].get("sources", [])
            proof_valid = bool(attempted) and all(s.get("content_hash") == reads.get(s.get("ref")) == manifest.get(s.get("ref")) for s in attempted)
            op["sources_match_actual_new_reads"] = proof_valid
            if not proof_valid:
                errors.append([arm, task, "attempted push fingerprint does not match preceding read"])
'''
assert s.count(needle)==1
p.write_text(s.replace(needle,insert+needle),encoding='utf-8')
