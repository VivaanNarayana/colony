"""Section context is additional evidence under the original read budgets."""

from colony.context import excerpts
from colony.validation import snapshot


def document(introduction, fact):
    return (
        "## Retention\n\n"
        + introduction
        + "\n\n"
        + "\n\n".join(
            f"Diagnostic detail {i} preserves opaque field names and result formatting metadata."
            for i in range(40)
        )
        + "\n\n"
        + fact
        + "\n"
    )


def test_section_context_keeps_definitions_qualifications_redaction_and_line_identity(tmp_path):
    introduction = (
        "Archives normally expire after 17 days.\n\n"
        "Legal holds suspend expiry.\n\napi_key = 'private-material'"
    )
    fact = "Diagnostic receipts preserve the current archive policy identifier."
    text = document(introduction, fact)
    path = tmp_path / "policy.md"
    path.write_text(text)
    proof = snapshot(tmp_path, "policy.md")
    line = text.splitlines().index(fact) + 1
    result = excerpts(
        tmp_path, [proof], "Archive policy?", preferred=[("policy.md", line)], section_context=True
    )
    assert len(result) == 2
    assert result[0]["line"] == 1
    assert "17 days" in result[0]["text"] and "Legal holds" in result[0]["text"]
    assert "[REDACTED]" in result[0]["text"] and "private-material" not in str(result)
    assert fact in result[1]["text"]
    for item in result:
        assert item["ref"] == "policy.md" and item["complete_file"] is False
        assert len(item["text"]) <= 2400
    assert sum(len(item["text"]) for item in result) <= 2800
    path.write_text("The policy changed.\n")
    assert (
        excerpts(
            tmp_path,
            [proof],
            "Archive policy?",
            preferred=[("policy.md", line)],
            section_context=True,
        )
        == []
    )


def test_section_context_never_evicts_a_second_ranked_source(tmp_path):
    sources, preferred = [], []
    for name in ["alpha", "beta"]:
        fact = f"The requested {name} fact is documented here."
        text = document(f"Introduction for {name}.", fact)
        ref = f"{name}.md"
        (tmp_path / ref).write_text(text)
        sources.append(snapshot(tmp_path, ref))
        preferred.append((ref, text.splitlines().index(fact) + 1))
    result = excerpts(
        tmp_path, sources, "Requested facts?", preferred=preferred, section_context=True
    )
    assert len(result) == 2
    assert [item["ref"] for item in result] == ["alpha.md", "beta.md"]
    assert all("requested" in item["text"] for item in result)
    assert sum(len(item["text"]) for item in result) <= 2800


def test_oversized_section_context_never_clips_selected_fact(tmp_path):
    fact = "Selected fact: " + "B" * 1300
    text = document("A" * 1600, fact)
    (tmp_path / "policy.md").write_text(text)
    result = excerpts(
        tmp_path,
        [snapshot(tmp_path, "policy.md")],
        "Requested fact?",
        preferred=[("policy.md", text.splitlines().index(fact) + 1)],
        section_context=True,
    )
    assert len(result) == 1 and fact in result[0]["text"]
    assert sum(len(item["text"]) for item in result) <= 2800


def pressure_excerpt(tmp_path, introduction, *, earlier_section=""):
    fact = "Receipt metadata preserves the diagnostic field names. " + "M" * 1320
    text = earlier_section + document(introduction, fact)
    (tmp_path / "policy.md").write_text(text, encoding="utf-8")
    line = text.splitlines().index(fact) + 1
    result = excerpts(
        tmp_path,
        [snapshot(tmp_path, "policy.md")],
        "What is the archive policy?",
        preferred=[("policy.md", line)],
        section_context=True,
    )
    assert any(fact in item["text"] for item in result)
    assert sum(len(item["text"]) for item in result) <= 2800
    assert all(len(item["text"]) <= 2400 for item in result)
    for item in result:
        original = text.splitlines()[item["line"] - 1 :]
        for offset, displayed in enumerate(item["text"].splitlines()):
            assert displayed == original[offset] or "[REDACTED]" in displayed
        assert item["text"].count("```") % 2 == 0
    return result


def test_budget_pressure_keeps_complete_definition_qualification_and_closed_fence(tmp_path):
    introduction = (
        "Archives normally expire after seventeen days.\n\n"
        "Legal holds suspend automatic expiry until released.\n\n"
        "```text\nretention_days = 17\nhold = manual_release\n```\n\n"
        "api_key = 'private-material'\n\n"
        + "\n\n".join("Background formatting detail: " + "x" * 140 for _ in range(8))
    )
    result = pressure_excerpt(tmp_path, introduction)
    assert len(result) == 2
    intro = result[0]
    assert intro["line"] == 1
    assert "seventeen days" in intro["text"]
    assert "until released" in intro["text"]
    assert "retention_days = 17\nhold = manual_release\n```" in intro["text"]
    assert "[REDACTED]" in intro["text"]
    assert "private-material" not in str(result)
    # Every displayed paragraph remains whole, including the final one.
    assert intro["text"].split("\n\n")[-1] in introduction.split("\n\n")


def test_budget_pressure_does_not_cross_an_earlier_section(tmp_path):
    previous = "## Historical policy\n\nObsolete archives expire after two days.\n\n"
    result = pressure_excerpt(
        tmp_path,
        "Current archives remain available for seventeen days.\n\n"
        + "\n\n".join("Formatting details: " + "z" * 140 for _ in range(9)),
        earlier_section=previous,
    )
    assert len(result) == 2
    assert "seventeen days" in result[0]["text"]
    assert "Obsolete" not in str(result)
    assert result[0]["line"] == len(previous.splitlines()) + 1


def test_budget_pressure_never_returns_a_fragment_of_an_oversized_first_paragraph(tmp_path):
    result = pressure_excerpt(tmp_path, "Definition: " + "q" * 1700)
    assert len(result) == 1
    assert "Definition:" not in str(result)


def test_budget_pressure_never_splits_an_oversized_intro_fence(tmp_path):
    introduction = (
        "Archives expire after seventeen days.\n\n"
        "```text\n" + "oversized configuration line\n" * 80 + "```\n\n"
        "This qualification follows the complete code block."
    )
    result = pressure_excerpt(tmp_path, introduction)
    assert len(result) == 2
    assert "seventeen days" in result[0]["text"]
    assert "oversized configuration" not in result[0]["text"]
    assert "qualification follows" not in result[0]["text"]
