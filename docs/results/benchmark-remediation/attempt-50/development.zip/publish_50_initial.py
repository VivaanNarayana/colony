import json,hashlib,zipfile,subprocess,shutil
from datetime import datetime,timezone
from pathlib import Path
root=Path.cwd(); w=root/'work'; p=root.parent; out=root/'docs/results/benchmark-remediation/attempt-50'
assert not out.exists();out.mkdir()
source='d5a8669a0f354a33bbdaca470c6f26fab230eacf';baseline='6fa6826aa4c835001c0d2bc8f3bec838499e5b5d'
live=p/'benchmark-remediation-live-50-results'; local=p/'benchmark-remediation-local-50-results'; runtime=p/'benchmark-remediation-live-50-runtime'
def put(name,obj):(out/name).write_text(json.dumps(obj,indent=2)+'\n',encoding='utf-8')
def copy(src,name):
 dst=out/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
comparison=json.loads((live/'comparison.json').read_text());assert comparison['blocking_gates']==['evidence_integrity']
assert int((w/'analyzer-50.exit.txt').read_text())==1
rows={a:[json.loads(x) for x in (live/a/'raw-measurements.jsonl').read_text().splitlines()] for a in ['main','feature']}
totals={}
for arm,rr in rows.items():
 assert len(rr)==24
 totals[arm]={k:sum(r[k] for r in rr) for k in ['tokens','seconds','tool_calls','ask_calls']}
 totals[arm]['uncached_input_plus_output']=sum(r['tokens']-r['usage']['cached_input_tokens'] for r in rr)
 totals[arm]['research_calls']=sum(sum(e['item'].get('server')=='repository' for e in [json.loads(s) for s in (live/arm/(r['task_id']+'.colony.events.jsonl')).read_text().splitlines()] if e.get('type')=='item.completed' and e.get('item',{}).get('type')=='mcp_tool_call') for r in rr)
put('raw-totals.json',dict(descriptive_only=True,not_a_gate_verdict=True,all_48_sessions_included=True,totals=totals))
for src,name in [(live/'comparison.json','comparison.json'),(live/'completed.json','completed.json'),(live/'protocol.json','protocol.json'),(live/'review-mapping.json','review-records.json'),(w/'manual-review-50.json','manual-review.json'),(w/'frozen-labels-50.json','frozen-labels.json'),(w/'verification-50.json','verification.json'),(w/'preflight-50.json','preflight.json'),(w/'required-gates-50.json','required-gates.json'),(w/'local-50-audit.json','local-raw-audit.json'),(w/'usage-budget.json','usage-budget.json'),(w/'usage-samples.jsonl','usage-samples.jsonl'),(p/'benchmark-remediation-tool-audit-50.json','tool-audit.json'),(p/'benchmark-remediation-research-review-50.json','research-review.json')]:copy(src,name)
for a in ['main','feature']:
 for n in ['raw-measurements.jsonl','loaded-implementations.json','metadata.json','corpus-sha256.json','reviews.json']:copy(live/a/n,a+'/'+n)
for f in local.iterdir():
 if f.is_file():copy(f,f.name)
for n in ['local-50.stdout.txt','local-50-awake.json','local-50.exit.txt','live-50.stdout.txt','live-50-awake.json','live-50.exit.txt','analyzer-50.stdout.txt','analyzer-50.stderr.txt','analyzer-50.exit.txt','full-50-final.stdout.txt','full-50-final.xml','full-50-final.exit.txt','full-50-final-awake.json']:copy(w/n,n)
for kind in ['local','live']:assert json.loads((w/f'{kind}-50-awake.json').read_text())['request_released']
# Preserve exact bytes, including all prior failed development experiments, separately from normalized public text copies.
with zipfile.ZipFile(out/'development.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in sorted(w.rglob('*')):
  if f.is_file() and '__pycache__' not in f.parts:z.write(f,f.relative_to(w).as_posix())
with zipfile.ZipFile(out/'live-native.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in sorted(live.rglob('*')):
  if f.is_file():z.write(f,'results/'+f.relative_to(live).as_posix())
 for a in ['main','feature']:
  for f in sorted((runtime/'implementation'/a).rglob('*.py')):z.write(f,'implementation/'+a+'/'+f.relative_to(runtime/'implementation'/a).as_posix())
 for a,folder in [('main','main'),('feature','feat')]:
  for f in sorted((runtime/folder/'repo').rglob('*')):
   if f.is_file():z.write(f,'corpus/'+a+'/'+f.relative_to(runtime/folder/'repo').as_posix())
for n in ['development.zip','live-native.zip']:
 with zipfile.ZipFile(out/n) as z:assert z.testzip() is None
codes={name:hashlib.sha256(subprocess.check_output(['git','show',f'{source}:{name}'])).hexdigest() for name in subprocess.check_output(['git','ls-tree','-r','--name-only',source,'--','src','scripts','tests'],text=True).splitlines()}
put('code-hashes.json',dict(source=source,basis='Committed Git blobs; final tests ran on these file contents before commit. Native/local loaded-source proofs retained.',sha256=codes))
put('outcome.json',dict(trial=50,source=source,baseline=baseline,all_gates_passed=False,current_complete_eight_gate_verdict_available=False,blocking_gates=['evidence_integrity','tests_and_lint_pass'],analyzer_exit_code=1,official_analyzer_invocations=1,local_invocations=1,native_invocations=1,native_sessions_completed=48,native_gross_tokens=2599693,benchmark_or_subject_session_restarts=0,all_attempts_and_costs_retained=True,proof_repair=False,tests_passed=322,tests_failed=1,tests_skipped=1,ruff_passed=True,models_harness_and_gates_unchanged=True,usage=dict(baseline=5,last_observed=6,stop=13,observed_increase=1,reset=1793294233),status='Published intermediate checkpoint; authorized budgeted remediation continues. No comparison retry is authorized for identical runtime.',draft=True,merged=False,auto_merge=False))
print(json.dumps(dict(out=str(out),totals=totals,files=len(list(out.rglob('*')))),indent=2))
