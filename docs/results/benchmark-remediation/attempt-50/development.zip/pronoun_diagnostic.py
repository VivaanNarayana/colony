import json,re,importlib.util
from pathlib import Path
from colony.retrieval import rank, terms, STOP_WORDS, local_term_support
root=Path('work/retrieval-50')
cases=json.loads((root/'predicate-diagnostic-v2.json').read_text())
rows=[]
for c in cases:
 q,s,a=c['question'],c['saved_question'],c['content']
 f=c.get('focus')
 if not f:
  continue
 aux=re.match(r'\w+',q)[0]
 rewritten=aux+' it '+f
 scores=rank(rewritten,[a[:4000],s])
 old=c['old_gate']
 new=old and (c['literal_support'] or scores[0]>max(0,scores[1]))
 rows.append(dict(c,rewritten=rewritten,rewritten_scores=scores,new_gate=new))
(root/'pronoun-diagnostic.json').write_text(json.dumps(rows,indent=2)+'\n')
for r in rows:
 print(json.dumps({k:r[k] for k in ['question','rewritten','expected_supported','old_gate','new_gate','rewritten_scores']}))
