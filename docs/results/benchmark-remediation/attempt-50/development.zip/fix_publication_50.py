from pathlib import Path
p=Path('work/publish_50.py');s=p.read_text(encoding='utf-8-sig')
s=s.replace('assert not out.exists();out.mkdir()','assert not out.exists() or not list(out.iterdir());out.mkdir(exist_ok=True)')
s=s.replace('.read_text()',".read_text(encoding='utf-8-sig')")
p.write_text(s,encoding='utf-8')
