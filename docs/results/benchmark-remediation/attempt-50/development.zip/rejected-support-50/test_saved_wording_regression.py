"""Bounded unrelated prose variants, with real-model diagnostics on every case."""

import json
import uuid

import pytest
import sqlite_vec

from colony.models import Trail
from colony.retrieval import local_term_support, rank, terms
from colony.validation import snapshot

CASES = [
    (
        "What is the archive retention interval?",
        "How long do archived records stay available?",
        "Which encryption algorithm protects the archives?",
        "Archive retention interval is fifty-seven days.",
        "The archive service keeps historical records available for fifty-seven days. "
        "This period starts when a record is archived. Records are then removed automatically.",
    ),
    (
        "What is the lifetime of a login session?",
        "When does a login session end?",
        "Does a login session permit deleting other users?",
        "A login session expires after thirty minutes.",
        "After thirty minutes, the login session expires. Users must authenticate again "
        "before continuing. The expiry interval applies to each newly created session.",
    ),
    (
        "What is the maximum attachment size?",
        "How large may an uploaded attachment be?",
        "Which attachment formats can execute scripts?",
        "Attachments are limited to sixteen megabytes.",
        "The upload service accepts attachments no larger than sixteen megabytes. "
        "Larger attachments are rejected before storage, so users should reduce their size.",
    ),
]


@pytest.mark.parametrize("saved_question,question,unrelated,concise,explanatory", CASES)
@pytest.mark.parametrize("wording", ["concise", "explanatory"])
def test_sufficient_saved_wording_and_unsupported_attribute_control(
    team, saved_question, question, unrelated, concise, explanatory, wording
):
    app, _, repo, _, key = team
    content = concise if wording == "concise" else explanatory
    (repo / "policy.md").write_text(content + "\n", encoding="utf-8")
    store = app.state.store
    store.push(
        Trail(
            id=uuid.uuid4().hex,
            namespace="team",
            question=saved_question,
            content=content,
            sources=[snapshot(repo, "policy.md")],
        ),
        key.grant,
    )
    diagnostic = {
        "wording": wording,
        "question": question,
        "literal_support": local_term_support(terms(question), content),
        "answer_and_control_scores": rank(question, [content, saved_question]),
        "unsupported_attribute_question": unrelated,
        "unsupported_attribute_literal_support": local_term_support(terms(unrelated), content),
        "unsupported_attribute_answer_and_control_scores": rank(
            unrelated, [content, saved_question]
        ),
    }
    result = store.ask(question, ["team"], 604800, 0.60)
    negative = store.ask(unrelated, ["team"], 604800, 0.60)
    diagnostic.update(result=result, unsupported_attribute_result=negative)
    print(json.dumps(diagnostic, sort_keys=True))
    # Evaluate the negative control even when a sufficient answer is missed.
    assert not negative["hit"], diagnostic
    assert result["hit"] and result["status"] == "validated", diagnostic
    assert any(content in item["text"] for item in result["evidence"]), diagnostic


@pytest.mark.parametrize(
    "full_score,control_score,statement_scores,expected,score_statements",
    [
        (4.0, 1.0, [2.0, -3.0], True, True),
        (4.0, 1.0, [1.0, -3.0], False, True),
        (4.0, -2.0, [0.0, -3.0], False, True),
        (4.0, -2.0, [-1.0, -3.0], False, True),
        (0.0, -8.0, [3.0, 4.0], False, False),
        (-2.0, -8.0, [3.0, 4.0], False, False),
        (4.0, 4.0, [7.0, 8.0], False, False),
        (4.0, 6.0, [7.0, 8.0], False, False),
    ],
)
def test_statement_corroboration_only_tightens_existing_nonliteral_admission(
    team, monkeypatch, full_score, control_score, statement_scores, expected, score_statements
):
    import colony.store

    app, _, repo, _, key = team
    store = app.state.store
    question = "How large may an uploaded attachment be?"
    saved_question = "What is the maximum attachment size?"
    statements = [
        "Attachments are limited to sixteen megabytes.",
        "Larger files are rejected before storage.",
    ]
    content = " ".join(statements)
    assert not local_term_support(terms(question), content)
    (repo / "policy.md").write_text(content, encoding="utf-8")
    store.push(
        Trail(
            id=uuid.uuid4().hex,
            namespace="team",
            question=saved_question,
            content=content,
            sources=[snapshot(repo, "policy.md")],
        ),
        key.grant,
    )
    vector = sqlite_vec.serialize_float32([1.0] + [0.0] * 383)
    with store.connect() as db:
        db.execute("UPDATE trail_vectors SET embedding=?", (vector,))
        db.execute("UPDATE trail_questions SET embedding=?", (vector,))
    scored = []
    by_text = {content: full_score, saved_question: control_score}
    by_text.update(zip(statements, statement_scores, strict=True))

    def controlled_rank(query, passages):
        assert query == question
        scored.extend(passages)
        return [by_text[text] for text in passages]

    monkeypatch.setattr(colony.store, "rank", controlled_rank)
    result = store.find_answer(question, ["team"], 604800, 0.60, query_vector=vector)
    assert result["hit"] is expected
    assert scored == (
        [content, saved_question, *statements]
        if score_statements
        else [content, saved_question] if full_score > 0 else [content]
    )
    if expected:
        # Corroboration never substitutes a fragment for the complete saved answer.
        assert result["content"] == content
        assert result["status"] == "validated"


def test_single_statement_answer_reuses_its_existing_full_score(team, monkeypatch):
    import colony.store

    app, _, repo, _, key = team
    store = app.state.store
    question = "How large may an uploaded attachment be?"
    saved_question = "What is the maximum attachment size?"
    content = "Attachments are limited to sixteen megabytes."
    assert not local_term_support(terms(question), content)
    (repo / "policy.md").write_text(content, encoding="utf-8")
    store.push(
        Trail(
            id=uuid.uuid4().hex,
            namespace="team",
            question=saved_question,
            content=content,
            sources=[snapshot(repo, "policy.md")],
        ),
        key.grant,
    )
    vector = sqlite_vec.serialize_float32([1.0] + [0.0] * 383)
    with store.connect() as db:
        db.execute("UPDATE trail_vectors SET embedding=?", (vector,))
        db.execute("UPDATE trail_questions SET embedding=?", (vector,))
    calls = []

    def controlled_rank(query, passages):
        assert query == question
        calls.append(passages)
        return [4.0 if text == content else 1.0 for text in passages]

    monkeypatch.setattr(colony.store, "rank", controlled_rank)
    result = store.find_answer(question, ["team"], 604800, 0.60, query_vector=vector)
    assert result["hit"] and result["content"] == content
    assert calls == [[content], [saved_question]]
