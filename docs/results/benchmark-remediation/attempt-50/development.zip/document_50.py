from pathlib import Path
import json,hashlib
root=Path.cwd();out=root/'docs/results/benchmark-remediation/attempt-50'
readme='''# Trial50 — completed sessions; evidence integrity fails

Measured feature `d5a8669a0f354a33bbdaca470c6f26fab230eacf` against freshly fetched main `6fa6826aa4c835001c0d2bc8f3bec838499e5b5d`, rechecked unchanged afterward. Exactly one local invocation and one native invocation completed; no benchmark or subject-session restart, resampling or proof repair occurred. PR3 remains draft, unmerged, without auto-merge.

**The unchanged official analyzer exits1 with `evidence_integrity`: feature/scope-3 submitted a push fingerprint that does not match an actual source read. There is no complete eight-gate verdict for this trial.** No native gate is promoted from descriptive totals. All eight original strict required checks remain active under ruleset25440133 with no bypass or main exemption. Trial49's historical 4/8 remains its own result.

## Changes and tests

The MCP policy puts the conditional research/save obligation and successful non-error receipt confirmation before research-free reuse guidance, including initialization's first512 characters. Sufficiency guidance now explicitly requires no new research before skipping a push. This preserves strict new-read proof admission, server-forced research taint (including explicit false), encrypted offline queue/retry, authentication, scope and freshness. Official MCP guidance recommends important initialization instructions within the first512 characters; that is not proof this Codex client truncates there or caused trial49's omission.

Saved-answer literal support now examines the same explicit first4000-character prefix already used for embedding content, reranking input and bounded MCP answer display. An unrelated real-Store control demonstrated an invisible index-label tail could authorize an otherwise rejected answer while prefix bytes, vectors and model scores stayed identical. The fix removes that bypass. It does not align with the reranker's internal token truncation or establish answer completeness. Supported prefix reuse and supported-tail current-source fallback remain tested; answers supported only beyond4000 can lose their saved-answer hit.

Final tested source: **322 passed, one failed, one existing Windows skip**; Ruff and whitespace pass. The failure is preserved: an explanatory login-expiry answer falsely matches a question about permission to delete other users. All six sufficient wording positives reuse successfully. The initial full suite (313passed/1failed/1skip), intermediate test/setup failures and final complete JUnit/logs are retained. Focused protocol84pass and answer-window49pass are supplemental, not a waiver of the failing full suite. Scripted SDK tests cannot prove model adherence.

Three requested development/review workers were used without nesting: SolHigh retrieval and protocol investigators; AstraHigh independent reviewer. Investigations began read-only, file ownership was separated, findings reconciled, and the final patch reviewed before measurement. Workers were idle during timed comparisons. Benchmark subjects remain frozen gpt-6-luna/low; all retrieval models and snapshots remain unchanged.

## Native review and failure

The coordinator reviewed all48 shuffled answers/current packets and14 research/save traces; this is primary review, not independent blind grading. Both arms have24/24 core facts. Citations are19/24 main and24/24 feature under the unchanged rubric. Labels were frozen before the analyzer. No novel current-source excerpt byte sequences appeared versus retained attempts24–49; actual excerpt bytes, lines and original hashes were checked against the frozen corpus.

Feature mcp-2 still receives irrelevant validated receipt metadata at README96, so its packet remains labeled irrelevant. It performs four research calls (three reads, one search), then a successful stored push with an actual new-read fingerprint. That differs from trial49's missing push, but one combined sample cannot isolate policy causality. Stale-2 reuses a differently worded prior answer without research; no retrieval mechanism improvement is claimed from that stochastic wording change.

Feature scope-3 obtains the full64-character SHA-256 from a successful new server.py read, submits only its first40 characters and receives strict SDK rejection. It rereads the file, receives the same complete hash, then submits the identical short value and is rejected again. The final answer reports the save failure. Both attempts, the redundant read, error messages and all costs remain untouched. Neither malformed proof was repaired, padded, reconstructed or substituted by the coordinator. These calls fail before Client.push and never reach storage/queue.

There are15 push attempts: six main successful receipts (two stored/four queued), seven feature stored receipts and two feature schema rejections. Thirteen successful attempted proofs match preceding new reads; the two malformed attempts do not. The storage audit finds six main rows/four encrypted main queue entries and seven feature rows/no feature queue; all actual rows/queued trails are tainted. This run does not exercise feature explicit-false override or offline queue; unchanged regression tests cover those paths.

The first supplementary trace helper incorrectly skipped proof auditing when a push returned non-JSON error text. Its initial empty-error report is retained in development.zip. The corrected helper audits all attempted pushes before parsing receipts and records both mismatches. The official analyzer and historical evidence were never changed. A publication helper's initial Windows default-decoding failure is also retained; UTF-8 reading corrected only publication, not measurements.

## Counts and limits

Both local arms pass117/117 oracle checks; all234 raw rows reconstruct exactly. Main lookup takes2.402378599625081s versus feature1.8543914000620134s:22.810193% lower, with95% reduction interval +12.851162% to +34.146423%. This standalone local result is valid; it does not override native integrity failure.

Native descriptive totals include all48 sessions:

| Measurement | Main | Feature |
| --- | ---: | ---: |
| Gross input+output tokens | 1,148,103 | 1,451,590 |
| Uncached input+output | 143,943 | 193,990 |
| Summed subject seconds | 257.099 | 252.168 |
| Research calls | 17 | 30 |
| Total tool calls | 47 | 63 |

These are costs, not passing performance gates. No confidence requirement, oracle, source/freshness/scope standard, workload, prompt, rubric, model, context/research/token/time budget or harness changed. Native gross total is2,599,693. The public development tasks and sampling/cache variability cannot establish held-out production savings.

## Retention and active checkpoint

`live-native.zip` contains exact original native results/events/prompts/answers/packets/labels and pinned implementation/corpus text, excluding private databases and queue credentials. `development.zip` retains raw diagnostic scripts, matrices, rejected candidate tests, all test phases/failures and operational logs. Both ZIP member checks passed. No offline analyzer replay is claimed. Public text copies normalize line endings; exact original bytes remain archived. `sha256.json` covers every other published file. Attempts1–49 and their manifests are byte-unchanged.

Rejected candidates include paragraph-prefix compaction (qualifier-loss risk), sentence/adjacent-pair support (valid compositional-answer misses), structured answer/control scoring (new wrong-attribute hit), residual/pronoun/reciprocal queries (new legitimate misses), label/literal-field admission (reference-only false hits), untrained token-level embedding checks (many misses), and dense answer-contribution scoring (false hit remains). Complete diagnostics are retained; none was integrated. No auxiliary model was added; the user explicitly required all retrieval models unchanged.

Weekly baseline5%, last observed6%, stop13%; observed increase1 percentage point, account-wide and possibly lagged. Reset is2026-10-29 17:17:13UTC. This intermediate publication does not reset the combined allowance. Authorized remediation is still active; RESUME.txt holds the current checkpoint. Next general protocol candidate: front-load full64-character copying/no reconstruction and avoid repeating rejected arguments, without weakening strict admission. No identical-runtime native retry is permitted.
'''
(out/'README.md').write_text(readme,encoding='utf-8',newline='\n')
resume=root/'docs/results/benchmark-remediation/RESUME.txt'
old=resume.read_text(encoding='utf-8-sig')
new='''ACTIVE BUDGETED REMEDIATION — TRIAL50 PUBLISHED CHECKPOINT, October22,2026 Pacific.
The current explicit resume request supersedes the older documentation-only pause below.
Task remains unfinished and active; no automatic job is scheduled. PR3 stays draft/unmerged.

BUDGET: initial weekly5% (recorded before agents/work); last observed6%; STOP13%.
Combined observed consumption1 percentage point for coordinator+allworkers+subjects.
Reset1793294233 =2026-10-29 17:17:13UTC. Preserve consumed allowance across any reset.
No reset credits/API billing/account switch used. Check usage before any further phase.
All retrieval models MUST remain unchanged (explicit user clarification); no auxiliary model.

Runtime/tested commit d5a8669a0f354a33bbdaca470c6f26fab230eacf.
Main freshly fetched/rechecked6fa6826aa4c835001c0d2bc8f3bec838499e5b5d.
Read attempt-50/README.md, comparison.json, outcome.json, manual-review.json,
research-review.json, tool-audit.json, raw-totals.json, verification.json and archives.
Trial50: one local+one native invocation,48sessions,2,599,693gross tokens, no retry.
Official analyzer exit1 EVIDENCE_INTEGRITY: feature/scope-3 submitted first40 of actual64
hash twice; both schema-rejected, redundant reread and failed saves retained untouched.
NO COMPLETE EIGHT-GATE VERDICT exists for50; all8 remain strictly required, no bypass.
Full suite322pass/1fail/1existing Windows skip; Ruff/whitespace pass. Red test remains
explanatory session-expiry answer falsely matching deletion permission question.
Local117/117both,22.81% lowerfeaturetime with positiveCI; native descriptivecosts
are not a gate verdict. Both core facts24/24, citations19/24main and24/24feature.

Safe scoped changes: mcp conditional save/reuse priority+non-error receipt confirmation;
store literal support restricted to explicit4000-char prefix alreadyindexed/ranked/displayed.
No store/context/model/ranking threshold expansion. Taint/proof/scope/freshness unchanged.
All three requested workers used, no nestedagents, read-only first and bounded reviews.
Workers idle during measurement. Coordinator owns commits/push/PR/checks/fullcomparisons.

EXACT NEXT CHECKPOINT: inspect40-char repeated proof failure and missing early full64-copy
instruction; propose/review general policy placement change with unrelated proof tests.
Do not repair traces/hashes or retry identical runtime. Keep all retrieval models frozen.
Wrong-attribute false hit, metadata selection and saved-wording misses remain unresolved.
Many fixed-model heuristics were disconfirmed by independent controls; diagnostics retained
in development.zip. Do not reinstate them or remove/xfail the red regression to get green.
Trial50 mcp-2 nowresearches+saves, but its metadata packet is still irrelevant. Stale-2
reuse changed with authored wording; do not call this a proven retrieval improvement.

HISTORICAL PAUSE/HANDOFF BELOW — superseded only by current authorized budgeted work.

'''
resume.write_text(new+old,encoding='utf-8',newline='\n')
index=root/'docs/results/benchmark-remediation/README.md'
text=index.read_text(encoding='utf-8-sig');first,rest=text.split('\n',1)
index.write_text(first+'\n\nLatest: **[trial50](attempt-50/README.md) fails evidence integrity** after all48 sessions. No complete eight-gate verdict; one full-suite regression remains red. Exact rejected proofs and all costs retained. Shared weekly usage baseline5%, observed6%, stop13%; remediation continues within that same allowance. PR3 remains draft/unmerged.\n\n'+rest,encoding='utf-8',newline='\n')
# Canonical exported text; exact raw originals remain in ZIPs.
for f in out.rglob('*'):
 if f.is_file() and f.suffix in {'.json','.jsonl','.txt','.md','.xml'}:
  f.write_text(f.read_text(encoding='utf-8-sig'),encoding='utf-8',newline='\n')
manifest={f.relative_to(out).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(out.rglob('*')) if f.is_file() and f.name!='sha256.json'}
(out/'sha256.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Published file hashes:',len(manifest))
