import json
import math
import struct
from pathlib import Path

from colony.retrieval import embed, passage

def cosine(a, b):
    return sum(x*y for x,y in zip(a,b))/math.sqrt(sum(x*x for x in a)*sum(y*y for y in b))

def vector(text, query=False):
    return struct.unpack('384f', embed(text,query=query))

root=Path(__file__).parent/'retrieval-50'
cases=json.loads((root/'predicate-diagnostic-v2.json').read_text())
rows=[]
for c in cases:
    q=vector(c['question'],True)
    saved=vector(c['saved_question'],True)
    answer=vector(passage(c['saved_question'],c['content']))
    qa,qs,sa=cosine(q,answer),cosine(q,saved),cosine(saved,answer)
    gain=qa-qs*sa
    old=c['old_gate']
    rows.append({**c,'query_answer_cosine':qa,'query_saved_question_cosine':qs,'saved_question_answer_cosine':sa,'answer_contribution':gain,'contribution_gate':old and (c['literal_support'] or gain>0)})
(root/'dense-contribution-diagnostic.json').write_text(json.dumps(rows,indent=2)+'\n')
for r in rows:
    if r['old_gate'] != r['contribution_gate'] or not r['literal_support']:
        print(json.dumps({k:r[k] for k in ['question','expected_supported','literal_support','old_gate','answer_contribution','contribution_gate']}))
