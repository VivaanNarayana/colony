import json
from pathlib import Path
p=Path('../benchmark-remediation-research-review-50.json')
for r in json.loads(p.read_text()):
 ops=[]
 for op in r['ops']:
  data=dict(op)
  if 'content' in data: data['content']='[source bytes retained]'
  if data['tool']=='push':
   data['arguments']=dict(data['arguments']);data['arguments']['content']='[answer retained]'
  ops.append(data)
 print(json.dumps(dict(id=r['id'],arm=r['arm'],task=r['task'],ops=ops)))
