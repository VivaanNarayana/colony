"""Prospective combined-runtime study: fixed77 plus unchanged serialized representation73."""
import hashlib,json,re,sqlite3,time
from pathlib import Path
import sqlite_vec
from colony import retrieval as r
O=Path(__file__).parent
PAIRS=[
 ('campus-parking','When may a campus parking permit be renewed?','A campus parking permit can be renewed during its final month. Outstanding parking charges must be paid before renewal.','Can a campus parking permit be renewed while charges remain unpaid?','Which vehicles may park in an accessible campus space?'),
 ('inspection-booking','When does an inspection booking become final?','An inspection booking becomes final after the supervisor approves it. Payment alone leaves the request provisional.','Does paying for an inspection make the booking final without approval?','Which safety equipment must be brought to an inspection?'),
 ('ticket-transfer','Can a concert ticket be transferred?','A concert ticket can be transferred once before the doors open. The new attendee must be named in the ticket record.','May a concert ticket be transferred twice?','Where does a concert ticket holder collect a wristband?'),
 ('equipment-return','What happens if a borrowed drill is returned late?','A late drill return incurs a fee of four credits per day. The fee is waived when the lending office was closed on the due date.','Is the late fee charged when the office was closed on the due date?','Which drill bits may be used for masonry?'),
 ('audio-resume','What happens when playback is paused?','Pausing an audio recording preserves its position. Closing the player also saves that position unless private mode is enabled.','Does private mode retain the position after the player closes?','Can the player transcribe an audio recording?'),
 ('drawing-export','Which formats does the drawing editor write?','The drawing editor exports SVG or PDF. Raster previews use PNG and cannot be selected as the export format.','Can a drawing be exported as PNG?','How many pages may a drawing contain?'),
 ('maintenance-alert','When does a maintenance reminder repeat?','A maintenance reminder repeats after five days unless a technician marks the work complete. Completed work stops all further reminders.','Will reminders continue after a technician records completion?','Who may assign a technician to maintenance work?'),
 ('voucher-refund','When can a gift voucher be refunded?','A gift voucher can be refunded within four days if none of its value has been spent. A partially used voucher cannot be refunded.','Is a partially spent gift voucher refundable?','Which products may be bought using a gift voucher?'),
]
rows=[]
for n,s,c,p,q in PAIRS:rows += [dict(name=n+'-positive',saved=s,content=c,query=p,expected=True,fresh=True),dict(name=n+'-negative',saved=s,content=c,query=q,expected=False,fresh=True)]
previous=json.loads(Path('work/paired-rerank-73/inputs.json').read_text(encoding='utf-8'))
rows += [dict(x,name='retained-'+x['name'],fresh=False) for x in previous['rows'] if x['name'] in ['known-lifetime-positive','known-deletion-negative','garden-access-wrong-attribute']]
m=json.loads(Path('../benchmark-remediation-live-57-results/review-mapping.json').read_text(encoding='utf-8'));p=next(x for x in m if x.get('review_id')=='R25')['packets'][0];rows.append(dict(name='retained-native57-offline-sufficient',saved='What happens when the server is down?',content=p['content'],query='Does an offline push get queued?',expected=True,fresh=False))
design={'candidate':'On reviewed runtime77 baseline, change only answer CE passage from content[:4000] to existing retrieval.passage(saved_question,content), byte-identical representation formula to rejected73. Preserve complete local lexical bypass, current positive/discriminating semantic check, dense thresholds/weights/order rules, exact singleton shortcut/procedure guard and all display/source safeguards.','why_new_baseline':'Independent77tightened lexical bypass after73was rejected for an unsupported control through that bypass. No representation/threshold retuning;73original rejection retained. This combined runtime has no native evidence yet.','reject_if':'Any baseline-admitted sufficient answer lost; any new false hit; any fresh negative or known deletion/garden negative admitted; error. One pass, no retuning. Source/Store/multi-candidate/native safety still needs regression/review.','caps':{'embedding_items':60,'CE_pairs':60},'rows':rows};raw=(json.dumps(design,indent=2)+'\n').encode();(O/'inputs.json').write_bytes(raw);(O/'manifest.json').write_text(json.dumps({'inputs_sha256':hashlib.sha256(raw).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'frozen_before_inference':True,'baseline_commit':'ba77687804a7d7a49b182c75fc2e50995ef50e45'},indent=2)+'\n',encoding='utf-8',newline='\n')
cost={'embedding_items':0,'CE_pairs':0,'providers':0,'subjects':0};rowsout=[];error=None;start=time.perf_counter()
try:
 with sqlite3.connect(':memory:') as db:
  db.enable_load_extension(True);sqlite_vec.load(db)
  for c in rows:
   assert cost['embedding_items']+3<=60 and cost['CE_pairs']+3<=60
   q=r.embed(c['query'],query=True);a=r.embed(r.passage(c['saved'],c['content']));s=r.embed(c['saved'],query=True);cost['embedding_items']+=3;ad,sd=db.execute('SELECT vec_distance_cosine(?,?),vec_distance_cosine(?,?)',(q,a,q,s)).fetchone();sim=1-min(ad,sd);old,new,topic=r.rank(c['query'],[c['content'][:4000],r.passage(c['saved'],c['content']),c['saved']]);cost['CE_pairs']+=3
   literal=r.local_term_support(r.terms(c['query']),c['content'][:4000],complete=True);dense=sim>=.55 and 1-sd>=.65
   def admit(v):return dense and r.fused_score(sim,v)>=.6 and (literal or v>max(0,topic))
   rowsout.append(dict(name=c['name'],expected=c['expected'],fresh=c['fresh'],full_literal=literal,old_logit=old,new_logit=new,topic_logit=topic,baseline=admit(old),candidate=admit(new)))
except Exception as e:error={'type':type(e).__name__,'message':str(e)}
lost=[x['name'] for x in rowsout if x['expected'] and x['baseline'] and not x['candidate']];false=[x['name'] for x in rowsout if not x['expected'] and x['candidate']];newfalse=[x['name'] for x in rowsout if not x['expected'] and x['candidate'] and not x['baseline']]
out={'error':error,'cost':cost,'elapsed_seconds':time.perf_counter()-start,'rows':rowsout,'lost_positives':lost,'candidate_false_hits':false,'new_false_hits':newfalse,'baseline_positive_misses':[x['name'] for x in rowsout if x['expected'] and not x['baseline']],'baseline_false_hits':[x['name'] for x in rowsout if not x['expected'] and x['baseline']],'rejected':bool(error or lost or false or newfalse)};(O/'results.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps({k:v for k,v in out.items() if k!='rows'},indent=2))
