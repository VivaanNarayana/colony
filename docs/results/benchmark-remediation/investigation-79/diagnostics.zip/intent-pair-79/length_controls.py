"""Additional frozen near-limit intent/answer controls, candidate unchanged."""
from pathlib import Path
import json,hashlib,sqlite3
import sqlite_vec
from colony import retrieval as r
O=Path('work/intent-pair-79');base=[('How many revisions does the document editor retain?','The document editor retains twenty revisions. Older revisions are removed when another revision is saved.','What is the revision retention limit in the document editor?','Who may delete a document editor revision?'),('How long is an audio edit undo history retained?','Audio edit undo history is retained for eight days. Exporting the recording does not erase this history.','Does exporting a recording erase its undo history?','Which cipher encrypts audio edit undo history?'),('Which output formats can the diagram tool write?','The diagram tool writes SVG and EPS output. Bitmap images can be imported but cannot be exported.','Can the diagram tool export bitmap images?','What is the largest diagram the tool can store?')];rows=[]
for i,(s,c,p,n) in enumerate(base):
 for mode in ['short','long']:
  saved=s if mode=='short' else (s+'\n'+('Operational review of '+s+' includes revision identifiers and administrative notes. ')*30)[:2000]
  for positive,q in [(True,p),(False,n)]:rows.append({'name':f'{i}-{mode}-{positive}','saved':saved,'content':c,'query':q,'expected':positive})
raw=(json.dumps({'scope':'Additional prospective length/wording controls, unchanged candidate. No threshold or template tuning.','rows':rows},indent=2)+'\n').encode();(O/'length-inputs.json').write_bytes(raw);(O/'length-inputs.sha256').write_text(hashlib.sha256(raw).hexdigest(),encoding='utf-8');out=[];cost={'embedding_items':0,'CE_pairs':0,'providers':0,'subjects':0}
with sqlite3.connect(':memory:') as db:
 db.enable_load_extension(True);sqlite_vec.load(db)
 for x in rows:
  q=r.embed(x['query'],query=True);a=r.embed(r.passage(x['saved'],x['content']));s=r.embed(x['saved'],query=True);cost['embedding_items']+=3;ad,sd=db.execute('SELECT vec_distance_cosine(?,?),vec_distance_cosine(?,?)',(q,a,q,s)).fetchone();sim=1-min(ad,sd);old,new,topic=r.rank(x['query'],[x['content'],r.passage(x['saved'],x['content']),x['saved']]);cost['CE_pairs']+=3;literal=r.local_term_support(r.terms(x['query']),x['content'],complete=True);dense=sim>=.55 and 1-sd>=.65
  def good(v):return dense and r.fused_score(sim,v)>=.60 and (literal or v>max(0,topic))
  out.append({'name':x['name'],'expected':x['expected'],'question_chars':len(x['saved']),'literal':literal,'dense':dense,'old_score':old,'new_score':new,'topic':topic,'baseline':good(old),'candidate':good(new)})
result={'rows':out,'cost':cost,'lost_positives':[x['name'] for x in out if x['expected'] and x['baseline'] and not x['candidate']],'new_false_hits':[x['name'] for x in out if not x['expected'] and x['candidate'] and not x['baseline']],'baseline_positive_misses':[x['name'] for x in out if x['expected'] and not x['baseline']]};result['rejected']=bool(result['lost_positives'] or result['new_false_hits']);(O/'length-results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps({k:v for k,v in result.items() if k!='rows'},indent=2))
