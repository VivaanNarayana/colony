"""Hold a reversible system-idle wake request only while a specific benchmark runs."""
import ctypes
import json
import sys
from ctypes import wintypes
from datetime import datetime, timezone
from pathlib import Path

pid = int(sys.argv[1])
log = Path(sys.argv[2])
kernel = ctypes.WinDLL('kernel32', use_last_error=True)
kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
kernel.OpenProcess.restype = wintypes.HANDLE
kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
kernel.WaitForSingleObject.restype = wintypes.DWORD
kernel.SetThreadExecutionState.argtypes = [wintypes.DWORD]
kernel.SetThreadExecutionState.restype = wintypes.DWORD
kernel.CloseHandle.argtypes = [wintypes.HANDLE]
handle = kernel.OpenProcess(0x00100000, False, pid)
if not handle:
    raise ctypes.WinError(ctypes.get_last_error())
started = datetime.now(timezone.utc).isoformat()
previous = kernel.SetThreadExecutionState(0x80000001)
if not previous:
    raise ctypes.WinError(ctypes.get_last_error())
data = {'role':'Operational prevention of future idle sleep only; no clock adjustment or outcome exclusion','benchmark_pid':pid,'started_utc':started,'request':'ES_CONTINUOUS | ES_SYSTEM_REQUIRED; display sleep remains allowed','persistent_power_configuration_changed':False}
log.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
print(json.dumps(data),flush=True)
try:
    while True:
        result = kernel.WaitForSingleObject(handle,30000)
        if result == 0:
            break
        if result != 258:
            raise ctypes.WinError(ctypes.get_last_error())
finally:
    kernel.SetThreadExecutionState(0x80000000)
    kernel.CloseHandle(handle)
    data['ended_utc'] = datetime.now(timezone.utc).isoformat()
    data['request_released'] = True
    log.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
