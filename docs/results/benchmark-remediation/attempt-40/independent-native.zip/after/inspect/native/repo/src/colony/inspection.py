from pathlib import Path
import typer

app = typer.Typer()

@app.command()
def inspect(
    root: Path = typer.Option(...),
    log: Path = typer.Option(...),
    mode: str = typer.Option('quick'),
):
    check(root, log, mode)
