from pathlib import Path
import typer

app = typer.Typer()

@app.command()
def mirror(
    origin: Path = typer.Option(...),
    cache: Path = typer.Option(...),
    host: str = typer.Option('127.0.0.1'),
):
    start(origin, cache, host)
