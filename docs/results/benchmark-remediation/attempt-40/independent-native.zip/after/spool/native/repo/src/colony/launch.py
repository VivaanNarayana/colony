from pathlib import Path
import typer

app = typer.Typer()

@app.command()
def spool(
    journal: Path = typer.Option(...),
    checkpoint: Path = typer.Option(...),
    limit: int = typer.Option(17),
):
    replicate(journal, checkpoint, limit)
