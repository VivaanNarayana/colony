The active zone is pink-6. The standby is defined in src/colony/placement.py.
