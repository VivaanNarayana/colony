ACTIVE_ZONE = 'pink-6'
STANDBY_ZONE = 'taupe-4'
