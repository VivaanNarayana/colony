REGIONS = {"sandbox": "eu-west-2", "primary": "us-east-2"}
