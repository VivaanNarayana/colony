from .regions import REGIONS

def region(tenant):
    return REGIONS[tenant]
