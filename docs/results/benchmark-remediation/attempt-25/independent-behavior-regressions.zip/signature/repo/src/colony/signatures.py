from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

def verify_signature(message, signature, public_key):
    Ed25519PublicKey.from_public_bytes(public_key).verify(signature, message)
