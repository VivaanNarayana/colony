from .signatures import verify_signature

def receive(message, signature, public_key):
    verify_signature(message, signature, public_key)
    return accept(message)
