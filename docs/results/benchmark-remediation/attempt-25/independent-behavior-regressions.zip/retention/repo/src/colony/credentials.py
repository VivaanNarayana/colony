def validate_ticket(ticket):
    if ticket.audience != "records":
        raise ValueError("wrong audience")
