from .credentials import validate_ticket

RETENTION_DAYS = 37

def retention(ticket):
    validate_ticket(ticket)
    return RETENTION_DAYS
