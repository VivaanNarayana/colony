def verify_job(job):
    if job.queue != "internal":
        raise ValueError("wrong queue")
