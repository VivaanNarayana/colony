from .job_access import verify_job

RECONCILIATION_PERIOD_SECONDS = 19

def run(job):
    verify_job(job)
    schedule(job, every_seconds=RECONCILIATION_PERIOD_SECONDS)
