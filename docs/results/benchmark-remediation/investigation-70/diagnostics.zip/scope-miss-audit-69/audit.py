"""Historical scope miss audit from preceding successful receipts, never final DB."""
import hashlib
import json
import os
import sys
from pathlib import Path

BASE=Path.cwd()
OUT=Path(__file__).parent
RESULTS=BASE.parent/"benchmark-remediation-live-56-results/feature"
RUNTIME=BASE.parent/"benchmark-remediation-live-56-runtime"
FROZEN=RUNTIME/"implementation/feature/src"
sys.path.insert(0,str(FROZEN))

def main():
 from colony.context import source_chunks
 from colony.models import Source
 from colony.retrieval import embed,fused_score,local_term_support,passage,rank,terms,keyword_coverage
 import numpy as np
 reads={}; errors=[]
 def read(path):
  data=path.read_bytes(); reads[str(path)]=hashlib.sha256(data).hexdigest(); return data.decode("utf-8-sig")
 metadata=json.loads(read(RESULTS/"metadata.json")); order=metadata["task_order"]; before=order[:order.index("scope-3")]
 pushes=[]; attempted=[]
 for task in before:
  for line in read(RESULTS/(task+".colony.events.jsonl")).splitlines():
   event=json.loads(line); item=event.get("item",{})
   if event.get("type")!="item.completed" or item.get("server")!="colony" or item.get("tool")!="push": continue
   reply=None
   try:
    reply=json.loads(item["result"]["content"][0]["text"])
   except Exception as exc: errors.append(dict(task=task,error=repr(exc)))
   row=dict(task=task,arguments=item.get("arguments"),reply=reply,status=item.get("status"),error=item.get("error"))
   attempted.append(row)
   if item.get("status")=="completed" and not item.get("error") and isinstance(reply,dict) and reply.get("stored") is True and reply.get("duplicate") is False: pushes.append(row)
 target_events=[json.loads(line) for line in read(RESULTS/"scope-3.colony.events.jsonl").splitlines()]
 initial=next(e["item"] for e in target_events if e.get("type")=="item.completed" and e.get("item",{}).get("server")=="colony" and e.get("item",{}).get("tool")=="ask")
 query=initial["arguments"]["question"]; namespace=initial["arguments"]["namespace"]
 corpus=RUNTIME/"feat/repo"; source_checks=[]; indexed={}
 for row in pushes:
  sources=[Source(**s) for s in row["arguments"].get("sources",[])]
  for source in sources:
   data=(corpus/source.ref).read_bytes(); digest=hashlib.sha256(data).hexdigest(); reads[str(corpus/source.ref)]=digest
   source_checks.append(dict(task=row["task"],ref=source.ref,expected=source.content_hash,actual=digest,matches=digest==source.content_hash))
  for ref,line,text in source_chunks(corpus,sources):
   digest=next(s.content_hash for s in sources if s.ref==ref)
   indexed.setdefault((namespace,ref,digest,line),text)
 for module in ["store.py","context.py","retrieval.py"]: read(FROZEN/"colony"/module)
 read(BASE/"scripts/live_benchmark.py")
 state=dict(initial_store_evidence=metadata["method"],seed_code_evidence="scripts/live_benchmark.py setup initializes issuer/grant/repo but never pushes seed trails; metadata states independent empty stores",
            tasks_before_target=before,preceding_push_attempts=attempted,successful_preceding_pushes=pushes,initial_ask=initial,
            source_checks=source_checks,unique_indexed_descriptors=len(indexed),input_read_hashes=reads,
            limitations="No final database, identity, queue or key access. Receipt history supplies payloads, not generated row IDs/timestamps. No exact source dense/tie order retained.")
 payload=(json.dumps(state,indent=2)+"\n").encode(); (OUT/"historical-state.json").write_bytes(payload)
 input_hash=hashlib.sha256(payload).hexdigest(); (OUT/"historical-state.sha256").write_text(input_hash+"\n")
 cost=dict(embeddings=0,CE_pairs=0,rank_calls=0,providers=0)
 def vector(text,query_mode):
  if cost["embeddings"]>=10: raise RuntimeError("10 embedding cap before inference")
  cost["embeddings"]+=1; return embed(text,query=query_mode)
 def cosine(a,b):
  a,b=np.frombuffer(a,np.float32),np.frombuffer(b,np.float32)
  return float(a@b/(np.linalg.norm(a)*np.linalg.norm(b)))
 def score(texts):
  if cost["CE_pairs"]+len(set(texts))>60: raise RuntimeError("60 CE pair cap before inference")
  cost["CE_pairs"]+=len(set(texts)); cost["rank_calls"]+=1; return rank(query,texts)
 assert len(pushes)==8 and all(c["matches"] for c in source_checks)
 qvector=vector(query,True); question_candidates=[]
 for row in pushes:
  args=row["arguments"]; qcos=cosine(qvector,vector(args["question"],True))
  question_candidates.append(dict(task=row["task"],saved_question=args["question"],question_cosine=qcos,passes_saved_question_floor=qcos>=.65,literal_support=local_term_support(terms(query),args["content"][:4000])))
 scope=next(row for row in pushes if row["task"]=="scope-2")["arguments"]
 full,control=score([scope["content"][:4000],scope["question"]]); acos=cosine(qvector,vector(passage(scope["question"],scope["content"]),False))
 qcos=next(row["question_cosine"] for row in question_candidates if row["task"]=="scope-2")
 scope_answer=dict(saved_question=scope["question"],content=scope["content"],question_cosine=qcos,answer_cosine=acos,
                   raw_answer_logit=full,saved_question_control_logit=control,literal_support=local_term_support(terms(query),scope["content"][:4000]),
                   dense_pass=max(qcos,acos)>=.55,question_floor_pass=qcos>=.65,relevance=fused_score(max(qcos,acos),full),
                   positive_and_above_control=full>max(0,control))
 descriptors=list(indexed); texts=list(indexed.values()); lexical=keyword_coverage(query,texts)
 source_rows=[dict(ref=key[1],line=key[3],text=text,lexical_coverage=coverage,local_support=local_term_support(terms(query),text)) for key,text,coverage in zip(descriptors,texts,lexical,strict=True)]
 possible=[row for row in source_rows if row["lexical_coverage"]>=.5 and row["local_support"]]
 if len(possible)<=58:
  for row,value in zip(possible,score([row["text"] for row in possible]),strict=True): row["raw_score"]=value
 else: errors.append(dict(stage="source scoring",error="Too many possible passages for fixed CE cap; no source model calls"))
 output=dict(historical_state_sha256=input_hash,question=query,namespace=namespace,cost=cost,errors=errors,
             successful_prior_trails=len(pushes),answer_question_candidates=question_candidates,scope_answer=scope_answer,
             source_descriptors=source_rows,source_prefilter_possible=possible,
             uncertainty="Source dense/sparse order not replayed; global prefilter and score exclusions are conservative bounds. Freshness inferred from same short run, exact server timestamps unobserved. No whole Store/native replay.",
             setup_read_errors="Earlier scratch searches used unsupported PowerShell glob paths and returned rg path errors; corrected by direct filenames. No input or subject outcome changed.")
 (OUT/"results.json").write_text(json.dumps(output,indent=2)+"\n")
 print(json.dumps(dict(history=input_hash,cost=cost,prior_trails=len(pushes),question_candidates=question_candidates,scope_answer=scope_answer,
                       source_prefilter_possible=[{k:v for k,v in row.items() if k!="text"} for row in possible],errors=errors),indent=2))

if __name__=="__main__": main()
