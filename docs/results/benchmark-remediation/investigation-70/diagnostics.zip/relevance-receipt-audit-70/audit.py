"""Two zero-neural actual Store calls; isolate only the historical score shortcut."""
import difflib
import hashlib
import json
import math
import subprocess
import sys
import types
from pathlib import Path

import sqlite_vec
import colony.context as context
import colony.retrieval as retrieval
from colony.models import Grant, Scope, Trail
from colony.validation import snapshot

ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[1]
SOURCE=REPO/'src/colony/store.py'
assert not (ROOT/'results.json').exists(), 'No retry'
raw=SOURCE.read_bytes()
source=raw.decode('utf-8')
old='scores = [0.0] if exact_singleton else rank(question, [c[:4000] for c in contents])'
assert source.count(old)==1
without=source.replace(old,'scores = rank(question, [c[:4000] for c in contents])')
(ROOT/'isolated.diff').write_text(''.join(difflib.unified_diff(source.splitlines(True),without.splitlines(True),fromfile='current/store.py',tofile='isolated-pre-shortcut/store.py')),encoding='utf-8')
(ROOT/'historical-change.txt').write_bytes(subprocess.check_output(['git','show','b2fb0b7','--','src/colony/store.py'],cwd=REPO))
calls=[]
def forbidden(*args,**kwargs):
    raise AssertionError('Models forbidden')
retrieval.models=forbidden
def vector(cosine):
    return sqlite_vec.serialize_float32([cosine,math.sqrt(1-cosine*cosine)]+[0.0]*382)
def rank(question,passages):
    calls.append(dict(question=question,passages=passages,explicit_scores=[5.0]*len(passages)))
    return [5.0]*len(passages)
context.rank=rank
engines={}
for name,code in [('current',source),('without-shortcut',without)]:
    mod=types.ModuleType('colony.relevance_audit_'+name.replace('-','_'))
    sys.modules[mod.__name__]=mod
    exec(compile(code,str(SOURCE), 'exec'),mod.__dict__)
    mod.models=lambda:None
    mod.index_version=lambda:'explicit-384-relevance-receipt-only'
    mod.embed=lambda *a,**k:vector(1)
    mod.embed_passages=lambda texts:[vector(1) for _ in texts]
    mod.rank=rank
    engines[name]=mod
folder=ROOT/'private-runtime'
assert not folder.exists(), 'No retry'
repo=folder/'repo'
repo.mkdir(parents=True)
question='What is the archive retention?'
answer='Archive retention is 17 days.'
(repo/'archive.txt').write_text(answer+'\n',encoding='utf-8')
proof=snapshot(repo,'archive.txt')
store=engines['current'].Store(folder/'data',repo)
grant=Grant(member_id='fixture',name='Synthetic fixture',server='http://127.0.0.1',expires_at=4102444800,scopes=[Scope(namespace='public',push=True,pull=True)])
store.push(Trail(id='1'*32,namespace='public',question=question,content=answer,sources=[proof]),grant)
with store.connect() as db:
    db.execute('UPDATE trail_vectors SET embedding=?',[vector(.8)])
    db.execute('UPDATE trail_questions SET embedding=?',[vector(.8)])
results={}
for name,mod in engines.items():
    instance=object.__new__(mod.Store)
    instance.__dict__.update(store.__dict__)
    offset=len(calls)
    receipt=instance.find_answer(question,['public'],1000,.99,query_vector=vector(1))
    results[name]=dict(receipt=receipt,rank_stub_calls=calls[offset:])
report=dict(source_sha256=hashlib.sha256(raw).hexdigest(),historical_introduction='b2fb0b792d4ba1ac2f6c8766b8c381dbf033b697',comparison='Current source vs same source with only score shortcut removed; history exported separately, not a full historical runtime replay.',inputs=dict(question=question,answer=answer,namespace='public',threshold=.99,cosine=.8,rank_stub=5.0,source=proof.model_dump()),outputs=results,find_answer_calls=2,fixture_pushes=1,neural_calls=0,production_unchanged=SOURCE.read_bytes()==raw)
(ROOT/'results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report),flush=True)
