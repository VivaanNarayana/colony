Exact-singleton relevance receipt audit70: completed, no production patch.

Historical introduction: b2fb0b792d4ba1ac2f6c8766b8c381dbf033b697, exported in
historical-change.txt. It replaces unconditional answer rank() with [0.0] for a
sole exact-question candidate. Current src/colony/store.py624-627 retains it;
644-646 fuse that value and724 returns rounded relevance in the full Store/API
receipt. server.py71-83 returns Store.ask directly. The earlier-source diff
proves this numeric change was introduced by that optimization.

Two actual Store.find_answer calls compare current source with an isolated copy
removing only that score shortcut. This is not a whole historical runtime replay.
Actual SQLite384d float32 vector cosine .8; fixed rank stub5.0; exact stored
question; valid real synthetic source hash; threshold .99 deliberately exceeds
both heuristic scores. Both calls return the same validated answer/source/evidence
and dense score .8. Current relevance=.7400, without shortcut=.8387.
Current answer-rank calls0, comparison1. All exact inputs/outputs/proof retained
in results.json; output.txt and exit.txt retain the successful single execution.
Costs2 find_answer calls,1 fixture Store.push, zero neural/provider calls.

Why selection stays the same: one eligible exact row cannot be reordered, the
exact-match threshold exception remains, semantic support excludes exact matches,
and repository validation/age/excerpt checks remain. Current unchanged test
tests/test_lookup_work.py89-130 verifies hit/exact behavior, decryption count and
no answer reranking. It does not assert numeric relevance equivalence.

relevance=0.8*cosine+0.2*sigmoid(logit); substituting0 adds exactly .1 rather
than a real cross-encoder contribution. The number can move either direction
by approximately .1 before receipt rounding depending on the omitted logit.
retrieval.py134-136 explicitly calls it a ranking heuristic, never a correctness
probability. README.md159-163 describes the80/20 formula and exact eligibility;
it does not currently explain the singleton score surrogate. The optimization's
selection equivalence should not be described as full numeric receipt identity.

MCP mcp.py102-118 selects fields without relevance; its hit projection omits this
number, so no direct MCP packet numeric change follows from this mechanism.
The full HTTP API retains it. Possible downstream use by a client exists, but no
actual consumer dependency, workload frequency, native compliance/token impact
or trial55/56 causality is demonstrated here. Treat as an observable compatibility
tradeoff/documentation gap, not an established retrieval selection bug or breach
of a documented calibrated-probability contract.

Proper general response: qualify optimization/equivalence claims and document the
surrogate if retained. If exact historical numeric compatibility is a requirement,
it requires retaining actual reranking (or an explicitly versioned scoring
contract), not claiming the fabricated0 is the historical measurement. No patch
or expanded workload measurement is authorized/performed in this phase.

Do not publish private-runtime/ databases or generated storage.key files.
