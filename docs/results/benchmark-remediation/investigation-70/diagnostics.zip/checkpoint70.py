import hashlib
import json
import subprocess
import zipfile
from datetime import datetime, timezone
from pathlib import Path

root = Path.cwd()
work = root / 'work'
out = root / 'docs/results/benchmark-remediation/investigation-70'
out.mkdir(exist_ok=False)
assert not subprocess.check_output(['git', 'diff', 'fec2c119', '--', 'src', 'tests', 'scripts'])
review = json.loads((work / 'review-audit69.json').read_text(encoding='utf-8'))
outcome = {
    'state': 'Checkpoint requested by user; task unfinished; all workers idle; no benchmark active',
    'latest_complete_comparison': 'trial56:3/8; runtime fec2c119 equivalent to75b4af3',
    'scope_audit69': 'Eight preceding successful saves reconstructed from original receipts/task order, not finalDB; eight matching source references across five distinct files. Sufficient saved answer rejected by strict positivity despite beating question-only control; no source passage passes descriptive lexical/local guards.',
    'scope_numbers': {'question_cosine':0.758034,'answer_cosine':0.735351,'fused_relevance':0.615623,'answer_logit':-3.032512,'question_control_logit':-9.416141,'distinct_source_descriptors':103},
    'scope_cost': {'embeddings':10,'CE_pairs':2,'providers':0},
    'scope_limits': 'Not complete Store replay or isolated causal attribution of46435gross-token difference. No source-vector/tie-order/timestamp replay claimed; zero globally qualifying passages makes source candidate ordering immaterial.',
    'review': review,
    'relevance_audit70': 'Exact-singleton shortcut introduced b2fb0b7 substitutes zero logit in returned fullAPI relevance. Two explicit vector/rank-stub Store calls:0.7400 current vs0.8387 without shortcut; same answer/dense/sources/evidence; zero neural/provider work. Not full historical replay or demonstrated selection bug. MCP omits field; consumer dependence/native impact unknown.',
    'change': 'README documents surrogate/numeric compatibility tradeoff only; no runtime or test change',
    'new_native_samples':0,
    'native_gross_50_51_53_54_55_56':15497907,
    'usage': {'baseline_used':16,'latest_observed_used':20,'observed_points_consumed':4,'stop_used':21,'observed_points_remaining':1,'reset':1793382050,'shared':True,'reporting_may_lag':True,'threshold_observed':False},
    'next': 'Read reliable usage first; original16→21 allowance remains. No approved safe runtime patch. Do not lower relevance safeguards based on this observed miss. Next native57 requires meaningful reviewed general runtime change and fresh main/fresh directories. No identical-code retry.',
    'at_utc':datetime.now(timezone.utc).isoformat(),
}
(out/'outcome.json').write_text(json.dumps(outcome,indent=2)+'\n',encoding='utf-8',newline='\n')
with zipfile.ZipFile(out/'diagnostics.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name in ['scope-miss-audit-69','relevance-receipt-audit-70']:
        for path in sorted((work/name).iterdir()):
            if path.is_file() and path.suffix.lower() in {'.py','.json','.txt','.md','.sha256'}:
                archive.write(path,name+'/'+path.name)
    archive.write(work/'review-audit69.json','review-audit69.json')
    archive.write(work/'checkpoint70.py','checkpoint70.py')
(out/'README.md').write_text('''# Checkpoint70: retained retrieval and receipt diagnoses

Task unfinished. [Trial56](../attempt-56/README.md) remains3/8 on unchanged runtime75b4af3, measured asfec2c119. No new benchmark, analyzer replay, label change or runtime patch followed it. Full tests remain421passed/1knownwrong-attribute failure/1existingWindows skip; Ruff passed. All prior outcomes and costs remain.

Audit69 reconstructs eight preceding successful saves using original native task order and stored=true/duplicate=false receipts, without accessing final databases. Eight matching source references represent five distinct files. A sufficient namespace answer passes dense/question/fused gates, with question cosine.758034 and relevance.615623. Its answer logit−3.032512 beats the saved-question control−9.416141, but fails the strict positive-logit guard when literal support is false. None of103historical deduplicated source descriptors passes the descriptive lexical/local prefilter, so source candidate ordering cannot rescue it. Cost:10embeddings,2CEpairs,0providers. Astra found no blocker in this narrow diagnosis. This is not a complete Store replay or an isolated explanation of the46,435token delta; source-vector/tie-order/timestamp behavior was not reconstructed. No guard relaxation or candidate retuning is proposed.

Audit70 identifies a numeric compatibility tradeoff introduced by the exact-singleton shortcut inb2fb0b7. Two explicit vector/rank-stub Store calls return the same validated answer, dense score, sources and evidence, but relevance differs:0.7400with the zero-logit surrogate versus0.8387with fixed rank-stub5. Zero neural/provider calls. The comparison removes only the shortcut from current source; it is not a full historical runtime replay. Relevance is explicitly heuristic, and MCP omits it. No consumer dependence, selection regression or native impact is demonstrated. The public README now documents the surrogate; Astra found no wording blocker. No runtime change or new test/benchmark was warranted for this documentation clarification.

The archive retains scripts, historical reconstruction, hashes, every output/error/cost and independent review. Only curated top-level text files are included; private runtime directories, databases and keys are excluded. History1–56/checkpoints56–68, models/weights, subjectgpt-6-luna/low, harness/config/workload/prompts/rubrics/oracles, all strict eight gates/ruleset25440133/no bypass, confidence/relevance/context/research/token/time budgets, taint/proofs/auth/scope/freshness and encrypted retry safeguards remain unchanged. Native gross50/51/53/54/55/56remains15,497,907,52native0; earlier costs remain separately retained.

Shared allowance3 baseline16%used, latest20%, stop21%;4observed points consumed,1observed remains. The threshold has **not** been observed. Reserve headroom for in-flight work/reporting lag and read reliable usage before resuming; this checkpoint grants no new allowance. Reset2026-10-30 17:40:50UTC. All workers idle; no benchmark active. PR#3 stays draft/unmerged/noauto. No approved safe next runtime patch; next native57 needs a meaningful reviewed general change and fresh main/directories, never an identical-runtime retry. See [RESUME](../RESUME.txt).
''',encoding='utf-8',newline='\n')
(out/'sha256.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(out.iterdir()) if p.name!='sha256.json'},indent=2)+'\n',encoding='utf-8',newline='\n')
resume = root/'docs/results/benchmark-remediation/RESUME.txt'
resume.write_text('''CHECKPOINT70 — USER REQUESTED RESUME UPDATE; TASK UNFINISHED.
Baseline16%used, latest20%, STOP21%; observed+4points,1remains; thresholdNOTobserved.
Reset1793382050=2026-10-30 17:40:50UTC. Same shared5point allowance, no renewal.
Reserve headroom for in-flight costs/reporting lag; read reliableusage before continuation.
All three workers idle; no benchmark active. PR3draft/unmerged/noauto.
Runtime75b4af31ee7556b931a387de6762014ac6f4b44a unchanged;
measuredasfec2c119d2964e99e01cf00239caab02625b34bb, latestcomplete trial56=3/8.
PASS loaded/local/time; FAIL tests/correctness/protocol/gross/uncached.
Gross+12.08%; uncached-2.08%CIcrosses0; time-8.50%CI+3.15to+14.63%reduction.
Core24/24both; citations19main/23feature; namedanchororaclefailure retained.
Tests421pass1knownwrongattribute falsehit failure1Windows skip;Ruffpass.
Read attempt56full evidence, investigation68, investigation70outcome/archive.
67unit supplement structurallyrejected(parent/decorator qualifications omitted).
68query-only improvesR25focusbutends103beforewrite105/queuedtrue106; no patch.
69scope miss:8precedingstoredreceipts,8sourcerefs/5files; sufficientanswer
logit-3.032512beatscontrol-9.416141butpositivityrejects;0/103sourceguards pass.
10embeddings/2CEpairs/0providers; reconstructionNOTfullStore/nativecausalreplay.
70exactsingleton relevance surrogate0.7400vs0.8387rankstub;selectionunchanged.
2stubStorecalls/0neural/providers;READMEclarificationonly, no runtimepatch.
Astrareview agrees with narrowdiagnosis/qualification. Alloutcomes/costs retained.
No approved safe nextpatch. Do not relaxguards or banlegitimateanchors for oracle.
Nextnative57 onlyaftermeaningfulgeneral reviewed runtimechange,freshmain/freshdirs.
No identicalcoderetry/resampling. Models/harness/gates/proofs/taint/scope unchanged.
At21stopallworkers/benchmark, preservepartialcosts, updatecheckpoint andpause.

'''+resume.read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
budget = root/'docs/results/benchmark-remediation/budget-allowance-3.json'
record = json.loads(budget.read_text(encoding='utf-8'))
record.update(last_observed_weekly_used_percent=20,observed_increase_percentage_points=4,last_phase='User-requested checkpoint70: diagnoses archived; workers idle; no new runtime/benchmark',last_observed_utc=datetime.now(timezone.utc).isoformat())
budget.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
body = (work/'pr-body-checkpoint68.md').read_text(encoding='utf-8')
body += '\n\n[Checkpoint70](https://github.com/VivaanNarayana/colony/blob/feat/benchmark-independent-evaluation/docs/results/benchmark-remediation/investigation-70/README.md) updates RESUME at the human request. Scope miss reconstructed from preceding receipts: sufficient negative-logit answer fails positivity;0/103source guards pass. This is not full replay or isolated cost causality. Exact-singleton API relevance surrogate documented; two rank-stub calls show numeric tradeoff, selection unchanged. No runtime change/new benchmark. All outcomes retained; workers idle. Usage20%observed vs21%stop (16%baseline); threshold not observed, reserve remaining headroom and reread usage before continuation. Same allowance, no renewal.\n'
(work/'pr-body-checkpoint70.md').write_text(body,encoding='utf-8',newline='\n')
print(json.dumps({'checkpoint':70,'usage':20,'threshold_observed':False,'archive_bytes':(out/'diagnostics.zip').stat().st_size}))
