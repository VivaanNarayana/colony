import hmac

def verify_stamp(body, stamp, key):
    expected = hmac.digest(key, body, "sha256")
    if not hmac.compare_digest(expected, stamp):
        raise ValueError("invalid stamp")
