from .shards import TENANT_SHARDS

def route(tenant):
    return TENANT_SHARDS[tenant]
