TENANT_SHARDS = {"archive": "amber-4", "sandbox": "violet-2"}
