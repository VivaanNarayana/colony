from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

def validate_context(context):
    Ed25519PublicKey.from_public_bytes(context.public_key).verify(context.signature, context.body)
    if context.expired:
        raise ValueError("expired context")
