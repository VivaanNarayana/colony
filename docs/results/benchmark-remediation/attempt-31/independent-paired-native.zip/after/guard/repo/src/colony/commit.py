from .contexts import validate_context

def commit(request):
    validate_context(request.context)
    if request.version != 7:
        raise ValueError("unsupported version")
    return commit_record(request)
