import hmac

def verify_ticket(ticket):
    expected = hmac.digest(ticket.issuer_key, ticket.body, "sha256")
    if not hmac.compare_digest(expected, ticket.signature):
        raise ValueError("bad ticket")
