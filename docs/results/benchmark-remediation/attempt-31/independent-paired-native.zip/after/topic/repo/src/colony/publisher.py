from .tickets import verify_ticket

def publish(topic, ticket, message):
    verify_ticket(ticket)
    if topic not in ticket.topics:
        raise PermissionError("topic denied")
    return append(topic, message)
