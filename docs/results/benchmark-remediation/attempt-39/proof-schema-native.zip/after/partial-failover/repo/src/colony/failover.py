PRIMARY = 'indigo-7'
STANDBY = 'copper-3'
