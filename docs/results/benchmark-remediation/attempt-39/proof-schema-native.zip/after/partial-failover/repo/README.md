The primary is indigo-7. Standby configuration lives in src/colony/failover.py.
