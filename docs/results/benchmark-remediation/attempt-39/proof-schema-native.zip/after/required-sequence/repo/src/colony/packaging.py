# First package the release with `relay package --verify`. Verification is mandatory before publishing.
