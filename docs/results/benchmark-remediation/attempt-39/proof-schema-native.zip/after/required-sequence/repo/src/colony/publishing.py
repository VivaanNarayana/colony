# Then publish the verified release with `relay publish --lane dev`. Production publishing is prohibited.
