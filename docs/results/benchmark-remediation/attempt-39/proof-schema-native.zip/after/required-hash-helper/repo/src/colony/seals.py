import hmac

def check_seal(doc):
    actual = hmac.digest(doc.key, doc.body, 'sha3_512')
    if not hmac.compare_digest(actual, doc.seal):
        raise ValueError('bad seal')
