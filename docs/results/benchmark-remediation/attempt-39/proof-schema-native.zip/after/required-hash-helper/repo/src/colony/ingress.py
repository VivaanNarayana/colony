from .seals import check_seal

def receive(doc):
    check_seal(doc)
