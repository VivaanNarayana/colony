Archives expire after 93 days. A legal hold prevents expiry until the hold is released.
