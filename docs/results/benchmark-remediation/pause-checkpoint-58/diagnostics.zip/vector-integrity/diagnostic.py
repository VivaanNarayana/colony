"""Persistence-only reproduction using deterministic storage vectors, no inference."""

import hashlib
import json
import tempfile
import time
from pathlib import Path
from unittest.mock import patch

import sqlite_vec

from colony import store as module
from colony.context import source_chunks
from colony.models import Grant, Scope, Source, Trail
from colony.store import Store
from colony.validation import validate

DIRECTORY = Path(__file__).parent
CONTENT = b"The observatory exposure timer waits twenty-three seconds before closing the shutter.\n"
VECTOR = sqlite_vec.serialize_float32([1.0] + [0.0] * 383)


def main():
    version = ["integrity-storage-stub-v1"]
    rank_calls = []

    def no_inference_rank(question, passages):
        rank_calls.append(dict(question=question, passages=passages))
        assert not passages, "No nonempty scoring is authorized in this persistence audit"
        return []

    def state(store, sources):
        with store.connect() as db:
            counts = {table: db.execute(f"SELECT count(*) FROM {table}").fetchone()[0]
                      for table in ["trails", "trail_vectors", "trail_questions", "trail_sources", "source_chunks", "source_vectors"]}
            counts["index_version"] = db.execute("SELECT value FROM settings WHERE key='index_version'").fetchone()[0]
        return dict(counts=counts, current_validation=validate(store.repo, sources),
                    current_chunk_count=len(source_chunks(store.repo, sources)))

    output = dict(inference_calls=0, production_changes=False,
                  limitation="Deterministic placeholder vectors test SQL/index lifecycle only; no semantic score or admission-quality claims.")
    with tempfile.TemporaryDirectory(prefix="colony-vector-integrity-57-") as temp, patch.multiple(
        module, models=lambda: None, index_version=lambda: version[0],
        embed=lambda *args, **kwargs: VECTOR,
        embed_passages=lambda passages: [VECTOR for _ in passages], rank=no_inference_rank,
    ):
        root = Path(temp)
        repo = root / "repo"
        repo.mkdir()
        sources = [Source(ref="observatory.md", content_hash=hashlib.sha256(CONTENT).hexdigest())]
        grant = Grant(member_id="audit", name="audit", server="http://localhost",
                      expires_at=int(time.time()) + 3600,
                      scopes=[Scope(namespace="team", push=True, pull=True)])
        trail = Trail(id="a" * 32, namespace="team", question="What colors are painted on the observatory?",
                      content="The observatory walls are white.", sources=sources)
        store = Store(root / "data", repo)
        output["missing_source_push"] = store.push(trail, grant)
        output["after_missing_push"] = state(store, sources)
        (repo / "observatory.md").write_bytes(CONTENT)
        output["after_exact_source_restored"] = state(store, sources)
        with store.connect() as db:
            immutable_before = dict(db.execute("SELECT * FROM trails WHERE id=?", (trail.id,)).fetchone())
        output["same_id_retry"] = store.push(trail, grant)
        with store.connect() as db:
            immutable_after = dict(db.execute("SELECT * FROM trails WHERE id=?", (trail.id,)).fetchone())
        assert immutable_before == immutable_after
        output["duplicate_does_not_mutate_trail_payload_or_age"] = True
        output["after_same_id_retry"] = state(store, sources)
        store = Store(root / "data", repo)
        output["after_same_version_restart"] = state(store, sources)
        output["evidence_after_restore"] = store.find_evidence(
            "How long does the observatory exposure timer wait?", ["team"], 604800, query_vector=VECTOR)
        assert output["evidence_after_restore"] is None
        assert output["after_exact_source_restored"]["current_validation"][0] == "validated"
        assert output["after_exact_source_restored"]["current_chunk_count"] == 1
        assert output["after_same_version_restart"]["counts"]["source_chunks"] == 0
        version[0] = "integrity-storage-stub-v2"
        store = Store(root / "data", repo)
        output["after_changed_version_with_current_source"] = state(store, sources)
        assert output["after_changed_version_with_current_source"]["counts"]["source_chunks"] == 1

        # A later full migration can turn an existing index into the same permanent gap.
        (repo / "observatory.md").write_bytes(b"Unrelated temporary checkout revision.\n")
        version[0] = "integrity-storage-stub-v3"
        store = Store(root / "data", repo)
        output["migration_while_cited_hash_unavailable"] = state(store, sources)
        (repo / "observatory.md").write_bytes(CONTENT)
        store = Store(root / "data", repo)
        output["migration_gap_after_restore_restart"] = state(store, sources)
        assert output["migration_gap_after_restore_restart"]["current_validation"][0] == "validated"
        assert output["migration_gap_after_restore_restart"]["counts"]["source_chunks"] == 0

        # Failure halfway through a push rolls back all SQL rows; the orphan blob is benign.
        second = trail.model_copy(update={"id": "b" * 32})
        before = state(store, sources)["counts"]
        with patch.object(module, "embed_passages", side_effect=RuntimeError("synthetic indexing failure")):
            try:
                store.push(second, grant)
            except RuntimeError as exc:
                output["failed_push_error"] = str(exc)
        after = state(store, sources)["counts"]
        assert before == after
        output["failed_push_sql_rollback_passed"] = True
        output["retry_after_failed_push"] = store.push(second, grant)
        output["after_failed_push_retry"] = state(store, sources)
        assert output["after_failed_push_retry"]["counts"]["trails"] == 2
        output["ungranted_namespace_evidence"] = store.find_evidence(
            "How long does the observatory exposure timer wait?", ["other-team"], 604800, query_vector=VECTOR)
        output["expired_evidence"] = store.find_evidence(
            "How long does the observatory exposure timer wait?", ["team"], -1, query_vector=VECTOR)
        assert output["ungranted_namespace_evidence"] is None and output["expired_evidence"] is None
        output["legitimate_zero_chunk_controls"] = []
        for name, data in [("empty", b""), ("binary", b"\xff\xfe\x00\x81")]:
            ref = name + ".dat"
            (repo / ref).write_bytes(data)
            control_sources = [Source(ref=ref, content_hash=hashlib.sha256(data).hexdigest())]
            status, checks = validate(repo, control_sources)
            chunks = source_chunks(repo, control_sources)
            assert status == "validated" and not chunks
            output["legitimate_zero_chunk_controls"].append(dict(name=name, validation=status, checks=checks, chunks=chunks))
    output["rank_invocations"] = rank_calls
    (DIRECTORY / "results.json").write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
