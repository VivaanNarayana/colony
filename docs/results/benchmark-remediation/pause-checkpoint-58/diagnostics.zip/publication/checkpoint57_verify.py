import hashlib
import json
import subprocess
from pathlib import Path

def run(*args):
    return subprocess.check_output(args)

sha = run("git", "rev-parse", "HEAD").decode().strip()
directory = "docs/results/benchmark-remediation/investigation-57"
def blob(path):
    return run("git", "show", f"{sha}:{path}")

manifest = json.loads(blob(directory + "/sha256.json"))
for name, digest in manifest.items():
    assert hashlib.sha256(blob(directory + "/" + name)).hexdigest() == digest, name
assert not run("git", "diff", "3917fa1be692165976dbf67f3bd4dfbe34206497", "--", "scripts", *[f"docs/results/benchmark-remediation/attempt-{n}" for n in range(1,56)], "docs/results/benchmark-remediation/investigation-56")
rules = json.loads(run("gh", "api", "repos/VivaanNarayana/colony/rulesets/25440133"))
checks = next(r["parameters"] for r in rules["rules"] if r["type"] == "required_status_checks")
assert len(checks["required_status_checks"]) == 8 and checks["strict_required_status_checks_policy"] and not rules["bypass_actors"] and rules["enforcement"] == "active" and rules["current_user_can_bypass"] == "never"
for check in checks["required_status_checks"]:
    payload = {"state": "failure", "context": check["context"], "description": "Current source unmeasured; known test failure; no inherited greens", "target_url": f"https://github.com/VivaanNarayana/colony/blob/{sha}/{directory}/README.md"}
    path = Path("work/current-status-57.json")
    path.write_text(json.dumps(payload), encoding="utf-8")
    subprocess.run(["gh", "api", f"repos/VivaanNarayana/colony/statuses/{sha}", "--input", str(path)], check=True, stdout=subprocess.DEVNULL)
pr = json.loads(run("gh", "pr", "view", "3", "--json", "isDraft,state,mergedAt,autoMergeRequest,headRefOid,headRefName"))
assert pr["isDraft"] and pr["state"] == "OPEN" and pr["mergedAt"] is None and pr["autoMergeRequest"] is None and pr["headRefOid"] == sha
report = {"head": sha, "manifest_entries_verified": len(manifest), "history1through55_investigation56_harness_unchanged": True, "required_checks": 8, "strict_no_bypass": True, "current_conservative_failures": 8, "current_eight_gate_verdict": None, "last_complete_comparison": "55:3/8 on8380724", "pr": pr}
Path("work/checkpoint57-integrity.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
print(json.dumps(report))
