"""Fixed delimiter/paragraph fixtures; exact context calls, zero inference."""

import hashlib
import json
import tempfile
from pathlib import Path
from unittest.mock import patch

from colony import context
from colony.validation import snapshot

DIRECTORY = Path(__file__).parent
FACT = "Available operations: `preview()` and `render()`; neither changes stored assets."
FIXTURES = [
    ("ordinary-triple-control", "# Manual\n\n## Inventory\n\n```python\n# Example heading\npreview()\n```\n\n" + FACT + "\n"),
    ("consecutive-code-prose-control", "# Manual\n\n## Inventory\n\n```python\npreview()\n```\nUse the following call for the output.\n```python\nrender()\n```\n\n" + FACT + "\n"),
    ("longer-envelope", "# Manual\n\n## Inventory\n\n````markdown\n```python\n# Example heading\npreview()\n```\n````\n\n" + FACT + "\n"),
    ("different-delimiter-envelope", "# Manual\n\n## Inventory\n\n~~~markdown\n```python\n# Example heading\npreview()\n```\n~~~\n\n" + FACT + "\n"),
    ("closer-with-info-is-content", "# Manual\n\n## Inventory\n\n```text\n```example-literal\n# Example heading\npreview()\n```\n\n" + FACT + "\n"),
    ("indented-marker-is-code", "# Manual\n\n    ```python\n    # Indented example\n\n## Inventory\n\n" + FACT + "\n"),
]


def main():
    records = []
    inputs = [dict(name=name, content=content, fact=FACT, expected_heading="Section: Manual > Inventory")
              for name, content in FIXTURES]
    archived = Path("../benchmark-remediation-live-49-runtime/feat/repo/README.md").read_text()
    actual_fact = "Tools: `ask(question, namespace?)` and `push(namespace, question, content, sources?, tainted?)`."
    inputs.append(dict(name="archived-motivating-readme", content=archived, fact=actual_fact,
                       expected_heading="Section: Colony > Agent integration (MCP)"))
    payload = (json.dumps(inputs, indent=2) + "\n").encode()
    (DIRECTORY / "inputs.json").write_bytes(payload)
    digest = hashlib.sha256(payload).hexdigest()
    (DIRECTORY / "inputs.sha256").write_text(digest + "\n")
    with tempfile.TemporaryDirectory(prefix="colony-markdown-boundaries-58-") as temp, patch.object(
        context, "rank", side_effect=AssertionError("No inference authorized")
    ):
        root = Path(temp)
        for case in inputs:
            path = root / "manual.md"
            path.write_text(case["content"], encoding="utf-8")
            source = snapshot(root, "manual.md")
            lines = case["content"].splitlines()
            fact_line = lines.index(case["fact"]) + 1
            chunks = context.source_chunks(root, [source], strict=True)
            selected = next(text for ref, line, text in chunks if line == fact_line)
            displayed = context.excerpts(root, [source], "Inventory operations", preferred=[("manual.md", fact_line)],
                                         section_context=True, strict_sources=True)
            heading = selected.splitlines()[0]
            exact_source = all(item["text"] == "\n".join(lines[item["line"]-1:item["line"]-1+len(item["text"].splitlines())])
                               for item in displayed)
            records.append(dict(name=case["name"], fact_line=fact_line, expected_heading=case["expected_heading"],
                                actual_heading=heading, heading_correct=heading == case["expected_heading"],
                                fact_preserved=case["fact"] in selected,
                                indexed=selected, displayed=displayed, display_exact_source=exact_source,
                                source_sha256=source.content_hash, candidate_count=len(chunks)))
    output = dict(inputs_sha256=digest, inference_calls=0, production_edits=False, rows=records,
                  limitation="Parser/representation correctness only; no retrieval admission or precision/recall measurement. Synthetic controls do not explain the motivating miss.")
    (DIRECTORY / "results.json").write_text(json.dumps(output, indent=2) + "\n")
    for row in records:
        print(json.dumps({key:row[key] for key in ["name","fact_line","expected_heading","actual_heading","heading_correct","fact_preserved","display_exact_source"]}))
    print(json.dumps(dict(incorrect_headings=sum(not row["heading_correct"] for row in records),
                          dropped_facts=sum(not row["fact_preserved"] for row in records), inference_calls=0)))


if __name__ == "__main__":
    main()
