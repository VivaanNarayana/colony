"""Preregistered same-query answer-token projection; score only, no runtime changes."""

import hashlib
import json
import re
import sys
import time
from pathlib import Path

BASE = Path.cwd()
DIRECTORY = Path(__file__).parent
EXAMPLES = [
    ("How long is a parcel locker collection code valid?",
     "A parcel locker collection code expires eighteen hours after delivery. It cannot reopen the compartment after that deadline.",
     "Is a parcel locker collection code usable after a full day?",
     "Does a parcel locker collection code reveal the sender's home address?"),
    ("What happens to an insect trap's counts when its lid is opened?",
     "Opening the insect trap stops new observations until the lid is shut. Earlier counts remain in the log and are never cleared by opening it.",
     "Does opening an insect trap erase earlier counts?",
     "Does opening an insect trap send a warning to a mobile phone?"),
    ("How does audiobook playback speed affect the stored recording?",
     "Changing audiobook playback speed alters only the live output. The downloaded recording stays unchanged and occupies the same storage space.",
     "Will slower audiobook playback consume additional storage?",
     "Will slower audiobook playback translate a foreign language?"),
    ("What does the projection lamp warranty cover?",
     "A failed projection lamp is replaced without charge during the first thirty days after purchase. Accidental breakage is excluded from this promise.",
     "Is a broken projection lamp replaced if it was accidentally dropped?",
     "Does the projection lamp warranty promise waterproof operation?"),
    ("What happens when the water-feed controller loses its sensor?",
     "The water-feed controller stops the pump immediately when sensor contact is lost. It remains stopped after reconnection until an operator resets it.",
     "Will a water-feed controller resume automatically when its sensor reconnects?",
     "Will a water-feed controller encrypt its maintenance records?"),
    ("How many adults may use a single hiking permit?",
     "Each hiking permit covers its named holder and one accompanying adult. Additional adults need separate permits, even if they arrive together.",
     "May one hiking permit cover a pair of adults?",
     "May one hiking permit authorize overnight use of a private cabin?"),
    ("When must telescope mount alignment be repeated?",
     "Alignment stays valid while the telescope mount remains in place. Moving its base invalidates that alignment, so the operator must repeat the procedure afterward.",
     "Must telescope mount alignment be repeated after moving its base?",
     "Does telescope mount alignment reveal a satellite's encryption key?"),
    ("What happens while a print queue is paused?",
     "Pending print jobs stay in the queue while it is paused. They resume in their original order when processing is enabled again.",
     "Does pausing a print queue discard the waiting jobs?",
     "Does pausing a print queue revoke another person's account?"),
    ("Which controls does the soil monitor provide?",
     "The soil monitor reports moisture readings only. It has no output capable of driving a sprinkler valve and cannot activate irrigation.",
     "Can a soil monitor operate sprinkler valves?",
     "Can a soil monitor identify soil-borne bacteria?"),
    ("Which language combinations are supported by lecture transcription?",
     "Lecture transcription accepts English or Spanish speech. Each recording must use one language throughout; mixed-language recordings are rejected.",
     "Can one lecture transcription recording contain both English and Spanish?",
     "Can lecture transcription verify who owns a recorded voice?"),
]


def freeze(name, value):
    payload = (json.dumps(value, indent=2) + "\n").encode()
    (DIRECTORY / f"{name}.json").write_bytes(payload)
    digest = hashlib.sha256(payload).hexdigest()
    (DIRECTORY / f"{name}.sha256").write_text(digest + "\n")
    return digest


def prepare():
    rows = []
    for index, (saved, answer, positive, negative) in enumerate(EXAMPLES, 1):
        for supported, query in [(True, positive), (False, negative)]:
            rows.append(dict(id=f"P{index:02d}-{'positive' if supported else 'negative'}",
                             origin="fresh-preregistered", expected_supported=supported,
                             saved_question=saved, content=answer, question=query))
    design = dict(
        projection="Original answer word tokens [A-Za-z][A-Za-z0-9'-]* with terms intersecting incoming-query terms, excluding STOP_WORDS; preserve case, order, and occurrences; join with spaces",
        application="Existing positive semantic branch only, nonliteral/nonexact/nonprocedural; nonempty projection shorter than original answer word-token sequence",
        additional_guard="Existing guards AND original answer raw logit strictly above projection raw logit, same incoming query",
        outcomes="Report semantic guards separately from unchanged dense/question-cosine/relevance eligibility; no Store admission/source/fallback claims",
        rejection="Any fresh supported loss rejects; known red still passing rejects as insufficient; no follow-on variant or retuning",
    )
    fresh = freeze("fresh-inputs", dict(design=design, rows=rows))
    cases = json.loads((BASE / "work/floor-calibration-56/calibration-cases.json").read_text())
    labels = {r["id"]:r for r in json.loads((BASE / "work/floor-calibration-56/calibration-labels.json").read_text())}
    for case in cases:
        if case["id"] in {"C03", "C06", "C16"}:
            assert len(case["records"]) == 1
            record = case["records"][0]
            rows.append(dict(id=case["id"], origin="known-nonindependent", expected_supported=labels[case["id"]]["positive"],
                             saved_question=record["question"], content=record["answer"], question=case["question"]))
    rows.append(dict(id="exact-red-lifetime", origin="known-nonindependent", expected_supported=False,
                     saved_question="What is the lifetime of a login session?",
                     content="After thirty minutes, the login session expires. Users must authenticate again before continuing. The expiry interval applies to each newly created session.",
                     question="Does a login session permit deleting other users?"))
    combined = freeze("inputs", dict(design=design, fresh_sha256=fresh, rows=rows))
    manifest = dict(fresh_sha256=fresh, inputs_sha256=combined, script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                    retrieval_source_sha256=hashlib.sha256((BASE / "src/colony/retrieval.py").read_bytes()).hexdigest(),
                    embed_model="BAAI/bge-small-en-v1.5", rank_model="Xenova/ms-marco-MiniLM-L-6-v2",
                    model_changes=False, fresh=20, known=4, frozen_before_scores=True)
    freeze("manifest", manifest)
    print(json.dumps(manifest))


def measure():
    import numpy as np

    from colony.retrieval import (
        STOP_WORDS,
        embed,
        fused_score,
        local_term_support,
        passage,
        procedural_text,
        rank,
        requires_procedure,
        terms,
    )

    data = (DIRECTORY / "inputs.json").read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    assert digest == (DIRECTORY / "inputs.sha256").read_text().strip()
    cost = dict(rank_invocations=0, pair_entries=0, unique_pair_entries=0, diagnostic_projection_pairs=0,
                hypothetical_runtime_extra_pairs=0, embedding_calls=0, providers=0)

    def cosine(a,b):
        a,b = np.frombuffer(a,np.float32),np.frombuffer(b,np.float32)
        return float(a@b/(np.linalg.norm(a)*np.linalg.norm(b)))

    def counted_embed(text, *, query=False):
        cost["embedding_calls"] += 1
        return embed(text, query=query)

    rows = []
    started = time.perf_counter()
    for case in json.loads(data)["rows"]:
        question, saved, answer = case["question"],case["saved_question"],case["content"]
        tokens = re.findall(r"[A-Za-z][A-Za-z0-9'-]*",answer)
        selected = [token for token in tokens if token.casefold() not in STOP_WORDS and terms(token) & terms(question)]
        projection = " ".join(selected)
        proper = bool(selected) and len(selected) < len(tokens)
        documents = [answer[:4000],saved,projection]
        full, control, projected = rank(question, documents)
        cost["rank_invocations"] += 1
        cost["pair_entries"] += len(documents)
        cost["unique_pair_entries"] += len(set(documents))
        cost["diagnostic_projection_pairs"] += 1
        literal = local_term_support(terms(question),answer[:4000])
        exact = question.strip().casefold() == saved.strip().casefold()
        procedure = requires_procedure(question)
        procedural_eligible = not procedure or procedural_text(answer) or exact
        old_semantic = literal or exact or procedure or full > max(0,control)
        applies = old_semantic and not (literal or exact or procedure) and proper
        revised = old_semantic and (not applies or full > projected)
        query = counted_embed(question,query=True)
        qcos = cosine(query,counted_embed(saved,query=True))
        acos = cosine(query,counted_embed(passage(saved,answer)))
        relevance = fused_score(max(qcos,acos),full)
        eligibility = max(qcos,acos)>=.55 and (qcos >= (.70 if procedure else .65) or exact)
        eligibility = eligibility and procedural_eligible and (relevance >= .60 or exact)
        cost["hypothetical_runtime_extra_pairs"] += int(applies and eligibility)
        row = dict(**case, original_answer_tokens=tokens, selected_projection_tokens=selected, projection=projection,
                   proper_projection=proper, full_answer_logit=full, saved_question_logit=control, projection_logit=projected,
                   literal_support=literal, exact=exact, procedure=procedure, query_question_cosine=qcos,
                   query_answer_cosine=acos, fused_relevance=relevance, unchanged_eligibility=eligibility,
                   old_semantic_guard=old_semantic, new_semantic_guard=revised, additional_guard_applied=applies,
                   old_eligible_guard=eligibility and old_semantic,new_eligible_guard=eligibility and revised,
                   fresh_supported_semantic_loss=case["origin"]=="fresh-preregistered" and case["expected_supported"] and old_semantic and not revised,
                   fresh_supported_eligible_loss=case["origin"]=="fresh-preregistered" and case["expected_supported"] and eligibility and old_semantic and not revised,
                   remaining_unsupported_eligible=not case["expected_supported"] and eligibility and revised)
        rows.append(row)
        print(json.dumps({k:row[k] for k in ["id","expected_supported","projection","full_answer_logit","saved_question_logit","projection_logit","literal_support","unchanged_eligibility","additional_guard_applied","old_semantic_guard","new_semantic_guard","fresh_supported_semantic_loss","fresh_supported_eligible_loss","remaining_unsupported_eligible"]}))
    cost["elapsed_seconds"] = time.perf_counter()-started
    summary = dict(cases=len(rows), fresh_supported_semantic_losses=sum(r["fresh_supported_semantic_loss"] for r in rows),
                   fresh_supported_eligible_losses=sum(r["fresh_supported_eligible_loss"] for r in rows),
                   remaining_unsupported_eligible=sum(r["remaining_unsupported_eligible"] for r in rows),
                   known_red_still_eligible=next(r["new_eligible_guard"] for r in rows if r["id"]=="exact-red-lifetime"))
    (DIRECTORY / "results.json").write_text(json.dumps(dict(inputs_sha256=digest,cost=cost,summary=summary,rows=rows),indent=2)+"\n")
    print(json.dumps(dict(summary=summary,cost=cost)))


if __name__ == "__main__":
    prepare() if sys.argv[1:] == ["--prepare"] else measure()
