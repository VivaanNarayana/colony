"""Actual SQLite age-candidate ordering; all neural work explicitly stubbed."""

import hashlib
import json
import math
from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace

import sqlite_vec

import colony.context as context
import colony.retrieval as retrieval
import colony.store as implementation
from colony.models import Grant, Scope, Trail
from colony.validation import snapshot


ROOT = Path(__file__).resolve().parent
NOW = 2_000_000_000.0
MAX_AGE = 1000
QUESTION = "Which spindle tolerance applies?"
calls = []
model_attempts = []


def forbid_models(*args, **kwargs):
    model_attempts.append(True)
    raise AssertionError("This diagnostic must not initialize or call neural models")


def vector(cosine):
    return sqlite_vec.serialize_float32([cosine, math.sqrt(1 - cosine * cosine)] + [0.0] * 382)


def embed_stub(text, **kwargs):
    calls.append({"operation": "embed_stub", "query": kwargs.get("query", False)})
    return vector(1.0)


def rank_stub(question, passages):
    # Explicit isolation stub: every spindle-answer paragraph receives the same
    # score regardless of age, vector distance or identity. Unrelated prose and
    # question-only controls receive zero. SQLite, not this stub, orders vectors.
    scores = [10.0 if "Spindle tolerance is" in text else 0.0 for text in passages]
    calls.append({"operation": "rank_stub", "passages": passages, "scores": scores})
    return scores


retrieval.models = forbid_models
implementation.models = lambda: None
implementation.index_version = lambda: "deterministic-384-age-crowding-only"
implementation.embed = embed_stub
implementation.embed_passages = lambda texts: [vector(1.0) for _ in texts]
implementation.rank = context.rank = rank_stub
implementation.time = SimpleNamespace(time=lambda: NOW)


def summarize(receipt):
    return {key: receipt.get(key) for key in ["hit", "id", "namespace", "status", "age_flag", "match_kind", "reason", "content"]}


def run_case(name, specifications, namespaces=("public",)):
    directory = ROOT / "private-runtime" / name
    assert not directory.exists(), "No identical-run retries"
    repo = directory / "repo"
    repo.mkdir(parents=True)
    store = implementation.Store(directory / "data", repo)
    grant = Grant(member_id="diagnostic", name="Deterministic diagnostic", server="http://127.0.0.1", expires_at=4102444800, scopes=[Scope(namespace="public", push=True, pull=True), Scope(namespace="private", push=True, pull=True)])
    identities = {}
    for index, spec in enumerate(specifications):
        label, cosine, age, relevant, namespace = spec
        identifier = hashlib.sha256(f"{name}:{label}".encode()).hexdigest()[:32]
        identities[identifier] = label
        ref = f"policy-{index}.txt"
        amount = "0.03" if label.startswith("fresh") or label.startswith("boundary") else "0.07"
        answer = f"Spindle tolerance is {amount} millimeters." if relevant else "Quartz inventory boxes are blue."
        # A real hash-backed, semantically synonymous source. It intentionally
        # lacks the query's lexical terms, so ordinary evidence fallback need
        # not rescue an excluded saved answer. No source rule is stubbed.
        source = f"The shaft's allowable radial runout is {amount} millimeters." if relevant else "Quartz inventory boxes are blue."
        (repo / ref).write_text(source + "\n", encoding="utf-8")
        trail = Trail(id=identifier, namespace=namespace, question=f"Spindle tolerance note {label}" if relevant else "Which color identifies quartz inventory boxes?", content=answer, sources=[snapshot(repo, ref)])
        store.push(trail, grant)
        with store.connect() as db:
            rowid = db.execute("SELECT rowid FROM trails WHERE id=?", (identifier,)).fetchone()[0]
            db.execute("UPDATE trail_vectors SET embedding=? WHERE rowid=?", (vector(cosine), rowid))
            db.execute("UPDATE trail_questions SET embedding=? WHERE rowid=?", (vector(cosine), rowid))
            db.execute("UPDATE trails SET created_at=? WHERE id=?", (NOW - age, identifier))
    with store.connect() as db:
        before = dict(db.execute("SELECT id,created_at FROM trails").fetchall())
        marks = ",".join("?" for _ in namespaces)
        ordered = db.execute(f"""SELECT t.id,t.namespace,t.created_at,
            min(vec_distance_cosine(v.embedding,?),vec_distance_cosine(q.embedding,?)) AS distance
            FROM trails t JOIN trail_vectors v ON t.rowid=v.rowid
            JOIN trail_questions q ON t.rowid=q.rowid
            WHERE t.namespace IN ({marks}) ORDER BY distance,t.created_at DESC""", [vector(1.0),vector(1.0),*namespaces]).fetchall() if namespaces else []
    sql = []
    original_connect = store.connect

    @contextmanager
    def traced():
        with original_connect() as db:
            db.set_trace_callback(sql.append)
            yield db

    store.connect = traced
    start = len(calls)
    direct = store.find_answer(QUESTION, list(namespaces), MAX_AGE, 0.60)
    direct_calls = calls[start:]
    start = len(calls)
    combined = store.ask(QUESTION, list(namespaces), MAX_AGE, 0.60)
    ask_calls = calls[start:]
    with store.connect() as db:
        after = dict(db.execute("SELECT id,created_at FROM trails").fetchall())
    assert before == after, "Diagnostic queries must not refresh creation timestamps"
    for receipt in [direct, combined]:
        assert not receipt.get("namespace") or receipt["namespace"] in namespaces
    return {"case": name, "vector_dimension": 384, "ordered_sql_rows": [{"label": identities[row["id"]], "namespace": row["namespace"], "distance": row["distance"], "age": NOW-row["created_at"], "aged": NOW-row["created_at"] > MAX_AGE} for row in ordered], "initial_limit_members": [identities[row["id"]] for row in ordered[:implementation.CANDIDATES]], "find_answer": summarize(direct), "find_answer_label": identities.get(direct.get("id")), "ask": summarize(combined), "ask_label": identities.get(combined.get("id")), "direct_stub_calls": direct_calls, "ask_stub_calls": ask_calls, "created_at_unchanged": before == after, "sql_trace": sql}


expired = [(f"expired-{index:02d}", 0.99-index*0.0005, MAX_AGE+10+index, True, "public") for index in range(13)]
fresh = ("fresh-relevant", 0.80, MAX_AGE-1, True, "public")
unrelated = ("unrelated-fresh", 0.90, MAX_AGE-1, False, "public")
private = ("private-nearest", 1.0, 0, True, "private")
cases = [
    ("fresh-only", [fresh], ("public",)),
    ("crowded", [*expired, fresh], ("public",)),
    ("aged-only", expired, ("public",)),
    ("unrelated-fresh-with-aged", [*expired, unrelated], ("public",)),
    ("unrelated-fresh-only", [unrelated], ("public",)),
    ("crowded-with-unrelated-and-private", [*expired, unrelated, fresh, private], ("public",)),
    ("denied-nearest", [private, fresh], ("public",)),
    ("empty-scope", [private, fresh], ()),
    ("boundary-exact", [("boundary-exact", 0.80, MAX_AGE, True, "public")], ("public",)),
    ("boundary-older", [("boundary-older", 0.80, MAX_AGE+0.001, True, "public")], ("public",)),
]
results = []
for name, specs, namespaces in cases:
    row = run_case(name, specs, namespaces)
    results.append(row)
    with (ROOT / "raw-results.jsonl").open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(row) + "\n")
    print(json.dumps({"case": name, "find_answer": row["find_answer"], "ask": row["ask"], "selected_label": row["ask_label"]}), flush=True)
assert not model_attempts
by_name = {row["case"]: row for row in results}
assert by_name["fresh-only"]["ask"]["status"] == "validated"
assert by_name["crowded"]["find_answer"]["status"] == "unverified"
assert by_name["crowded"]["ask"]["status"] == "unverified"
assert by_name["aged-only"]["ask"]["age_flag"] is True
assert by_name["unrelated-fresh-with-aged"]["ask"]["age_flag"] is True
assert by_name["unrelated-fresh-only"]["ask"]["hit"] is False
assert by_name["denied-nearest"]["ask_label"] == "fresh-relevant"
assert by_name["empty-scope"]["ask"]["reason"] == "no_pull_scope"
assert not by_name["empty-scope"]["ask_stub_calls"]
assert by_name["boundary-exact"]["ask"]["status"] == "validated"
assert by_name["boundary-older"]["ask"]["age_flag"] is True
report = {"source_store_sha256": hashlib.sha256(Path(implementation.__file__).read_bytes()).hexdigest(), "models_called": len(model_attempts), "cases": len(results), "diagnostic_assertions_passed": True, "max_first_rerank_passages": max((len(call["scores"]) for row in results for call in row["direct_stub_calls"] if call["operation"] == "rank_stub"), default=0), "created_at_unchanged_all_cases": all(row["created_at_unchanged"] for row in results), "stub_disclosure": "All embeddings are explicit384-dimensional unit vectors; real sqlite-vec computes cosine ordering. Explicit10/0 rank stub isolates candidate SQL; no semantic model validity claim. Actual source hashing, age checks, context and fallback are unchanged.", "private_artifacts": "Do not publish private-runtime database or generated storage.key files."}
(ROOT / "report.json").write_text(json.dumps(report, indent=2)+"\n", encoding="utf-8")
print(json.dumps(report), flush=True)
