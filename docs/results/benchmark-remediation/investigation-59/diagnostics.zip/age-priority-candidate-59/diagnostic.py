"""Single fresh-first SQL candidate, with explicit zero-model Store stubs."""

import ast
import difflib
import hashlib
import json
import sys
import time
import types
from pathlib import Path


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
ORIGINAL = ROOT.parent / "age-crowding-59"
original_files = {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in ORIGINAL.iterdir() if path.is_file()}
source_path = REPO / "src" / "colony" / "store.py"
baseline_source = source_path.read_text(encoding="utf-8")
old_sql = "WHERE t.namespace IN ({placeholders}) ORDER BY distance, t.created_at DESC LIMIT ?"
new_sql = "WHERE t.namespace IN ({placeholders}) ORDER BY (t.created_at >= ?) DESC, distance, t.created_at DESC LIMIT ?"
old_bindings = "[vector, vector, vector, *namespaces, CANDIDATES]"
new_bindings = "[vector, vector, vector, *namespaces, time.time() - max_age, CANDIDATES]"
assert baseline_source.count(old_sql) == baseline_source.count(old_bindings) == 1
candidate_source = baseline_source.replace(old_sql, new_sql).replace(old_bindings, new_bindings)
(ROOT / "candidate-store.py").write_text(candidate_source, encoding="utf-8")
(ROOT / "candidate.diff").write_text("".join(difflib.unified_diff(baseline_source.splitlines(keepends=True), candidate_source.splitlines(keepends=True), fromfile="baseline/store.py", tofile="candidate/store.py")), encoding="utf-8")

# Reuse only the frozen deterministic fixture/stub definitions and case data,
# stopping before the original runner. Never execute or alter the old output run.
old_tree = ast.parse((ORIGINAL / "reproduce.py").read_text(encoding="utf-8"))
prefix = []
for node in old_tree.body:
    if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == "results" for target in node.targets):
        break
    prefix.append(node)
namespace = {"__file__": str(ROOT / "diagnostic.py")}
exec(compile(ast.Module(body=prefix, type_ignores=[]), str(ORIGINAL / "reproduce.py"), "exec"), namespace)
baseline_module = namespace["implementation"]
candidate = types.ModuleType("fresh_first_sql_diagnostic")
candidate.__file__ = str(ROOT / "candidate-store.py")
sys.modules[candidate.__name__] = candidate
exec(compile(candidate_source, candidate.__file__, "exec"), candidate.__dict__)
for attribute in ["models", "index_version", "embed", "embed_passages", "rank", "time"]:
    setattr(candidate, attribute, getattr(baseline_module, attribute))

# Diagnostic pool-display SELECT only: match the candidate's age bucket without
# changing the actual production selector beyond the exported two-line diff.
run_node = next(node for node in prefix if isinstance(node, ast.FunctionDef) and node.name == "run_case")
run_source = ast.unparse(run_node)
probe = "ORDER BY distance,t.created_at DESC"
assert run_source.count(probe) == 1
candidate_run_source = run_source.replace(probe, "ORDER BY (t.created_at>={NOW-MAX_AGE}) DESC,distance,t.created_at DESC")
candidate_namespace = dict(namespace)
exec(compile(candidate_run_source, "candidate-fixture-display", "exec"), candidate_namespace)
candidate_namespace["implementation"] = candidate

cases = namespace["cases"] + [("twelve-unrelated-fresh-with-aged", [*namespace["expired"], *[(f"fresh-irrelevant-{index:02d}", 0.90-index*0.0001, namespace["MAX_AGE"]-1, False, "public") for index in range(12)]], ("public",))]
all_results = {}
started = time.perf_counter()
for label, engine in [("baseline", namespace), ("candidate", candidate_namespace)]:
    engine["ROOT"] = ROOT / label
    engine["calls"] = namespace["calls"]
    rows = []
    for name, specifications, permitted in cases:
        row = engine["run_case"](name, specifications, permitted)
        row["engine"] = label
        row["first_answer_rerank_count"] = next((len(call["scores"]) for call in row["direct_stub_calls"] if call["operation"] == "rank_stub"), 0)
        assert row["first_answer_rerank_count"] <= 12
        rows.append(row)
        with (ROOT / "raw-results.jsonl").open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(row) + "\n")
        print(json.dumps({"engine": label, "case": name, "pool": row["initial_limit_members"], "selected": row["ask_label"], "ask": row["ask"], "scored_candidates": row["first_answer_rerank_count"]}), flush=True)
    all_results[label] = {row["case"]: row for row in rows}

baseline = all_results["baseline"]
changed = all_results["candidate"]
# These assert the observed regression and recovery, not that the candidate is safe.
assert baseline["crowded"]["ask"]["status"] == "unverified"
assert changed["crowded"]["ask"]["status"] == "validated"
assert baseline["twelve-unrelated-fresh-with-aged"]["ask"]["age_flag"] is True
assert changed["twelve-unrelated-fresh-with-aged"]["ask"]["hit"] is False
for name in ["aged-only", "unrelated-fresh-with-aged", "boundary-exact", "boundary-older", "denied-nearest", "empty-scope"]:
    before, after = baseline[name], changed[name]
    assert (before["ask_label"], before["ask"]) == (after["ask_label"], after["ask"]), name
assert not namespace["model_attempts"]
assert all(hashlib.sha256((ORIGINAL / name).read_bytes()).hexdigest() == digest for name, digest in original_files.items())
assert hashlib.sha256(source_path.read_bytes()).hexdigest() == hashlib.sha256(baseline_source.encode()).hexdigest()
report = {"recommendation": "Reject fresh-first candidate: it removes an existing expired diagnostic in the twelve-unrelated-fresh counterexample.", "source_store_sha256": hashlib.sha256(baseline_source.encode()).hexdigest(), "candidate_store_sha256": hashlib.sha256(candidate_source.encode()).hexdigest(), "model_calls": 0, "case_pairs": len(cases), "actual_store_method_calls": len(cases)*4, "observed_crowded_recovery": True, "observed_diagnostic_regression": True, "max_first_answer_rerank_candidates": max(row["first_answer_rerank_count"] for rows in all_results.values() for row in rows.values()), "created_at_unchanged": all(row["created_at_unchanged"] for rows in all_results.values() for row in rows.values()), "seconds": time.perf_counter()-started, "previous_reproduction_files_unchanged": True, "production_source_unchanged": True, "selection_time": "The SQL cutoff is bound once per selection; the existing deterministic clock is identical for age buckets and final age checks. No clock or final check change in candidate source.", "private_artifacts": "Do not publish baseline/candidate/private-runtime databases or generated storage.key files."}
(ROOT / "report.json").write_text(json.dumps(report, indent=2)+"\n", encoding="utf-8")
print(json.dumps(report), flush=True)
