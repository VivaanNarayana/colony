"""Model-free old/new comparison on the retained trial55 repository corpora."""
import hashlib
import json
import subprocess
import types
from pathlib import Path

import colony.context as current
from colony.validation import snapshot

old = types.ModuleType("before_matched_fences")
old_code = subprocess.check_output(["git", "show", "bde1af1cafc391cad0dda0b0356486013fe2083f:src/colony/context.py"])
exec(compile(old_code, "bde1af1:context.py", "exec"), old.__dict__)

def forbidden(*args, **kwargs):
    raise AssertionError("No inference authorized in structural corpus comparison")

old.rank = current.rank = forbidden
root = Path.cwd()
rows = []
for arm in ["main", "feat"]:
    repo = root.parent / "benchmark-remediation-live-55-runtime" / arm / "repo"
    for path in sorted(repo.rglob("*")):
        if not path.is_file() or path.suffix not in {".md", ".markdown", ".py", ".toml"}:
            continue
        ref = path.relative_to(repo).as_posix()
        proof = snapshot(repo, ref)
        before = old.source_chunks(repo, [proof], strict=True)
        after = current.source_chunks(repo, [proof], strict=True)
        comparisons = []
        lines = current.source_lines(repo, proof, strict=True)
        for _, line, text in before:
            span = text.count("\n") + 1
            for section in [False, True]:
                options = {"preferred": [(ref, line)], "section_context": section, "strict_sources": True}
                first = old.excerpts(repo, [proof], "Neutral structural comparison", **options)
                second = current.excerpts(repo, [proof], "Neutral structural comparison", **options)
                comparisons.append({"line": line, "section_context": section, "packets_identical": first == second,
                                    "windows_identical": old.context_window(ref, lines, line, span) == current.context_window(ref, lines, line, span)})
        rows.append({"arm": arm, "ref": ref, "sha256": proof.content_hash, "chunks": len(before),
                     "descriptors_identical": before == after, "comparisons": comparisons})
report = {"scope": "Available retained trial55 repository files, not a subject run or all quality labels",
          "before_commit": "bde1af1cafc391cad0dda0b0356486013fe2083f",
          "before_context_sha256": hashlib.sha256(old_code).hexdigest(),
          "after_context_sha256": hashlib.sha256(Path(current.__file__).read_bytes()).hexdigest(),
          "files": len(rows), "packet_comparisons": sum(len(row["comparisons"]) for row in rows),
          "changed_descriptors": sum(not row["descriptors_identical"] for row in rows),
          "changed_packets": sum(not c["packets_identical"] for row in rows for c in row["comparisons"]),
          "changed_windows": sum(not c["windows_identical"] for row in rows for c in row["comparisons"]),
          "inference_calls": 0, "rows": rows,
          "conclusion": "No workload-specific structural-input benefit established; no native comparison justified by parser correction alone"}
Path("work/fence-corpus59.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
assert not report["changed_descriptors"] and not report["changed_packets"] and not report["changed_windows"]
print(json.dumps({key: value for key, value in report.items() if key != "rows"}))
