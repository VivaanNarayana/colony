"""Fixed residual-query pooled-cosine diagnostic; score only, no product edits."""

import hashlib
import json
import re
import sys
import time
from pathlib import Path

BASE = Path.cwd()
DIRECTORY = Path(__file__).parent
EXAMPLES = [
    ("How long does a campsite lantern run on one charge?",
     "At low brightness, a charged campsite lantern supplies light for nine hours. At full brightness its battery lasts only three hours.",
     "Will a campsite lantern stay lit through an eight-hour night at its dimmest setting?",
     "Can a campsite lantern repel mosquitoes?"),
    ("What happens to source files during photo scanning?",
     "The photo scanner opens source files read-only and writes separate output copies. Scanning never deletes or overwrites those originals.",
     "Does photo scanning destroy the original images?",
     "Which encryption algorithm protects photo scanning outputs?"),
    ("How do greenhouse vents respond to electrical failure?",
     "Loss of power releases the greenhouse vents. Counterweights then pull them open, allowing air to flow even while the motor is stopped.",
     "Does a power outage leave greenhouse vents shut?",
     "Can greenhouse vents identify pesticide contamination?"),
    ("What is the folding kayak passenger capacity?",
     "A folding kayak has seats for two adults. Their combined weight must be no more than one hundred sixty kilograms.",
     "How many grown passengers can a folding kayak carry?",
     "Which satellite navigation system does the folding kayak include?"),
    ("How many audio channels can a conference headset receive at once?",
     "Each conference headset plays one selected channel at a time. Switching channels replaces the current stream; it never mixes two streams.",
     "May one conference headset listen to two talks simultaneously?",
     "Can a conference headset identify a speaker from their voice?"),
    ("Who may enter using a climbing gym pass?",
     "The climbing gym pass admits its named member only. Guests require their own paid admission and cannot enter on that member's pass.",
     "Can a companion enter on a climbing gym pass?",
     "Does a climbing gym pass insure damage to personal property?"),
    ("How often does the river gauge record measurements?",
     "It takes one reading every twenty seconds. The river gauge keeps this interval during normal operation, including overnight.",
     "How much time separates consecutive river gauge observations?",
     "Which transmission protocol encrypts river gauge observations?"),
    ("What happens when a player skips a card-game turn?",
     "Skipping a card-game turn leaves the player's earned points unchanged. The following player acts next, and no earned points are removed.",
     "How does skipping card-game turns affect the accumulated tally?",
     "Can skipping a card-game turn expose an opponent's hidden hand?"),
]


def freeze(name, value):
    data = (json.dumps(value, indent=2) + "\n").encode()
    (DIRECTORY / f"{name}.json").write_bytes(data)
    digest = hashlib.sha256(data).hexdigest()
    (DIRECTORY / f"{name}.sha256").write_text(digest + "\n")
    return digest


def prepare():
    rows = []
    for index, (saved, content, positive, negative) in enumerate(EXAMPLES,1):
        for supported, question in [(True,positive),(False,negative)]:
            rows.append(dict(id=f"R{index:02d}-{'positive' if supported else 'negative'}", origin="fresh-preregistered",
                             expected_supported=supported, saved_question=saved, content=content, question=question))
    design = dict(
        subtraction="Exact residual_support_diagnostic.py rule: re.sub [A-Za-z][A-Za-z0-9_-]* removes tokens whose terms intersect saved-question terms, then collapse whitespace and spaces before [?.!,;:]",
        support="cos(query_embed(residual), passage_embed(passage(saved_question,answer))) strictly greater than cos(query_embed(residual), query_embed(saved_question))",
        application="AND original admission; only old positive nonliteral/nonexact/nonprocedural branch with meaningful residual terms",
        modes="Unchanged BGE query and passage embed modes and full-query vectors; no new stored vectors; cache exact (text,mode)",
        rejection="Reject on any newly lost accepted fresh positive or exact red still passing; no cutoff/variant tuning or Store claims",
        cost="At most 12 distinct residual query embeddings for 12 different saved questions, deduplicated by exact text/mode; count every diagnostic embedding and CE pair",
    )
    fresh = freeze("fresh-inputs",dict(design=design,rows=rows))
    cases = json.loads((BASE / "work/floor-calibration-56/calibration-cases.json").read_text())
    labels = {r["id"]:r for r in json.loads((BASE / "work/floor-calibration-56/calibration-labels.json").read_text())}
    for case in cases:
        if case["id"] in {"C03","C06","C16"}:
            assert len(case["records"]) == 1
            record = case["records"][0]
            rows.append(dict(id=case["id"],origin="known-nonindependent",expected_supported=labels[case["id"]]["positive"],
                             saved_question=record["question"],content=record["answer"],question=case["question"]))
    rows.append(dict(id="exact-red-lifetime",origin="known-nonindependent",expected_supported=False,
                     saved_question="What is the lifetime of a login session?",
                     content="After thirty minutes, the login session expires. Users must authenticate again before continuing. The expiry interval applies to each newly created session.",
                     question="Does a login session permit deleting other users?"))
    old = json.loads((BASE / "work/retrieval-50/residual-support-diagnostic.json").read_text())
    for index, case in enumerate(old):
        if case["expected_supported"] and case["original_gate"] and not case["tightening_only_gate"]:
            rows.append(dict(id=f"old-residual-CE-loss-{index}",origin="known-residual-CE-loss-nonindependent",
                             expected_supported=True, **{k:case[k] for k in ["saved_question","content","question"]}))
    combined = freeze("inputs",dict(design=design,fresh_sha256=fresh,rows=rows))
    manifest = dict(fresh_sha256=fresh,inputs_sha256=combined,fresh=16,known=len(rows)-16,
                    script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                    retrieval_sha256=hashlib.sha256((BASE / "src/colony/retrieval.py").read_bytes()).hexdigest(),
                    model_changes=False, frozen_before_scores=True)
    freeze("manifest",manifest)
    print(json.dumps(manifest))


def measure():
    import numpy as np

    from colony.retrieval import (
        embed,
        fused_score,
        local_term_support,
        passage,
        procedural_text,
        rank,
        requires_procedure,
        terms,
    )

    data = (DIRECTORY / "inputs.json").read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    assert digest == (DIRECTORY / "inputs.sha256").read_text().strip()
    cache = {}
    embedding_log = []
    cost = dict(embedding_requests=0, embedding_calls=0, cache_hits=0, rank_calls=0,
                ce_pair_entries=0, ce_unique_pair_entries=0, provider_calls=0)

    def vector(text, *, query=False):
        cost["embedding_requests"] += 1
        key = (text,query)
        if key not in cache:
            cache[key] = embed(text,query=query)
            cost["embedding_calls"] += 1
            embedding_log.append(dict(text=text,mode="query" if query else "passage",
                                      vector_sha256=hashlib.sha256(cache[key]).hexdigest()))
        else:
            cost["cache_hits"] += 1
        return cache[key]

    def cosine(a,b):
        a,b = np.frombuffer(a,np.float32),np.frombuffer(b,np.float32)
        return float(a@b/(np.linalg.norm(a)*np.linalg.norm(b)))

    rows = []
    started = time.perf_counter()
    for case in json.loads(data)["rows"]:
        question,saved,answer = case["question"],case["saved_question"],case["content"]
        topic = terms(saved)
        removed = []

        def subtract(match, topic=topic, removed=removed):
            token = match[0]
            if terms(token) & topic:
                removed.append(token)
                return ""
            return token

        residual = re.sub(r"[A-Za-z][A-Za-z0-9_-]*",subtract,question)
        residual = re.sub(r"\s+"," ",residual).strip()
        residual = re.sub(r"\s+([?.!,;:])",r"\1",residual)
        meaningful = bool(terms(residual))
        documents = [answer[:4000],saved]
        full,control = rank(question,documents)
        cost["rank_calls"] += 1
        cost["ce_pair_entries"] += len(documents)
        cost["ce_unique_pair_entries"] += len(set(documents))
        query = vector(question,query=True)
        saved_vector = vector(saved,query=True)
        answer_vector = vector(passage(saved,answer))
        qcos,acos = cosine(query,saved_vector),cosine(query,answer_vector)
        if meaningful:
            residual_vector = vector(residual,query=True)
            r_answer,r_saved = cosine(residual_vector,answer_vector),cosine(residual_vector,saved_vector)
            gain = r_answer-r_saved
        else:
            r_answer=r_saved=gain=None
        exact = question.strip().casefold() == saved.strip().casefold()
        procedure = requires_procedure(question)
        literal = local_term_support(terms(question),answer[:4000])
        old_semantic = literal or exact or procedure or full>max(0.0,control)
        applied = old_semantic and not (literal or exact or procedure) and meaningful
        revised = old_semantic and (not applied or r_answer>r_saved)
        relevance = fused_score(max(qcos,acos),full)
        eligible = max(qcos,acos)>=.55 and (qcos >= (.70 if procedure else .65) or exact)
        eligible = eligible and (not procedure or procedural_text(answer) or exact) and (relevance>=.60 or exact)
        row = dict(**case,residual_query=residual,removed_query_tokens=removed,residual_terms=sorted(terms(residual)),
                   full_answer_logit=full,saved_question_logit=control,query_question_cosine=qcos,query_answer_cosine=acos,
                   residual_answer_cosine=r_answer,residual_saved_question_cosine=r_saved,residual_cosine_gain=gain,
                   literal_support=literal,exact=exact,procedure=procedure,fused_relevance=relevance,
                   unchanged_eligibility=eligible,old_semantic_guard=old_semantic,new_semantic_guard=revised,
                   additional_guard_applied=applied,old_eligible_guard=eligible and old_semantic,new_eligible_guard=eligible and revised,
                   fresh_supported_semantic_loss=case["origin"]=="fresh-preregistered" and case["expected_supported"] and old_semantic and not revised,
                   fresh_supported_eligible_loss=case["origin"]=="fresh-preregistered" and case["expected_supported"] and eligible and old_semantic and not revised,
                   supported_eligible_loss=case["expected_supported"] and eligible and old_semantic and not revised,
                   remaining_unsupported_eligible=not case["expected_supported"] and eligible and revised)
        rows.append(row)
        print(json.dumps({k:row[k] for k in ["id","expected_supported","residual_query","residual_answer_cosine","residual_saved_question_cosine","residual_cosine_gain","literal_support","unchanged_eligibility","additional_guard_applied","old_eligible_guard","new_eligible_guard","supported_eligible_loss","remaining_unsupported_eligible"]}))
    cost["elapsed_seconds"] = time.perf_counter()-started
    active = [r for r in rows if r["additional_guard_applied"] and r["unchanged_eligibility"]]
    cost["hypothetical_active_residual_pairs"] = len(active)
    cost["hypothetical_distinct_residual_embeddings"] = len({r["residual_query"] for r in active})
    cost["worst_case_residual_embeddings_per_incoming_question"] = 12
    summary = dict(cases=len(rows),fresh_supported_semantic_losses=sum(r["fresh_supported_semantic_loss"] for r in rows),
                   fresh_supported_eligible_losses=sum(r["fresh_supported_eligible_loss"] for r in rows),
                   supported_eligible_losses=sum(r["supported_eligible_loss"] for r in rows),
                   remaining_unsupported_eligible=sum(r["remaining_unsupported_eligible"] for r in rows),
                   known_red_still_eligible=next(r["new_eligible_guard"] for r in rows if r["id"]=="exact-red-lifetime"))
    (DIRECTORY / "results.json").write_text(json.dumps(dict(inputs_sha256=digest,cost=cost,summary=summary,rows=rows,embedding_log=embedding_log),indent=2)+"\n")
    print(json.dumps(dict(summary=summary,cost=cost)))


if __name__ == "__main__":
    prepare() if sys.argv[1:] == ["--prepare"] else measure()
